

import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JLabel;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class Ex2 extends JFrame {
	
	public Ex2() {
		showFrame();
	}
	
	public void showFrame() {
		setBounds(600, 400, 300, 200);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		// 텍스트 1줄 출력이 가능한 컴포넌트 : JLabel
		JLabel lblNewLabel = new JLabel("이름을 입력하세요");
		getContentPane().add(lblNewLabel, BorderLayout.NORTH);
		
		
		// 텍스트 1줄 입력이 가능한 컴포넌트 : JTextField
		JTextField tf = new JTextField();
		// JTextField 컴포넌트 CENTER 영역에 부착
		getContentPane().add(tf, BorderLayout.CENTER);
		
		// OK 버튼 SOUTH 영역에 부착
		JButton btnOk = new JButton("OK");
		getContentPane().add(btnOk, BorderLayout.SOUTH);
		
		
		// OK 버튼 리스너 연결 - 5단계
		btnOk.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// JTextField 컴포넌트에 입력된 텍스트 가져와서 출력
				String str = tf.getText();
				System.out.println("입력 데이터 : " + str);
				
				// 입력 데이터 출력 후 텍스트필드 초기화 => 널스트링("")으로 설정
				tf.setText("");
			}
		});
		
		// JTextField 컴포넌트에 ActionListener 연결 시 
		// 텍스트 입력 후 엔터키로 입력 완료 수행이 가능하다! = OK 버튼 역할과 동일
		tf.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// JTextField 컴포넌트에 입력된 텍스트 가져와서 출력
				String str = tf.getText();
				System.out.println("입력 데이터 : " + str);
				
				// 입력 데이터 출력 후 텍스트필드 초기화 => 널스트링("")으로 설정
				tf.setText("");
			}
		});
		
		// 텍스트 필드에 입력되는 키에 대한 이벤트 처리 - KeyListener 사용
		tf.addKeyListener(new KeyAdapter() {

			@Override
			public void keyReleased(KeyEvent e) {
				System.out.println(e.getKeyCode() + ", " + e.getKeyChar());
			}
			
		});
		
		setVisible(true);
		
	}

	public static void main(String[] args) {
		new Ex2();
	}

}

















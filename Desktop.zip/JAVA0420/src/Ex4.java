

import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JLabel;
import javax.swing.JPanel;

import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

public class Ex4 extends JFrame {
	
	public Ex4() {
		showFrame();
	}
	
	public void showFrame() {
		setBounds(600, 400, 300, 200);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		/*
		 * JPanel
		 * - 여러개의 컴포넌트를 부착할 수 있는 경량 컨테이너
		 * - 별도의 설정이 없을 경우 기본 레이아웃은 FlowLayout
		 *   => 컴포넌트를 좌 -> 우, 상 -> 하 방향으로 자연스럽게 배치
		 *      (프레임 크기가 변경되면 컴포넌트 크기는 유지되고, 배치 위치가 변경됨)
		 */
		
		// JPanel 객체 생성
		JPanel p = new JPanel();
		// JFrame 객체의 CENTER 영역에 JPanel 객체 부착
		getContentPane().add(p, BorderLayout.CENTER);
		
		// JPanel 에 JButton 컴포넌트를 모두 배치
		JButton btnCenter = new JButton("CENTER");
		p.add(btnCenter);
		
		JButton btnEast = new JButton("EAST");
		p.add(btnEast);
		
		JButton btnWest = new JButton("WEST");
		p.add(btnWest);
		
		JButton btnNorth = new JButton("NORTH");
		p.add(btnNorth);
		
		JButton btnSouth = new JButton("SOUTH");
		p.add(btnSouth);
		
		JPanel panel = new JPanel();
		getContentPane().add(panel, BorderLayout.SOUTH);
		
		JButton btnNewButton = new JButton("OK");
		panel.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("CANCEL");
		panel.add(btnNewButton_1);
		
		
		setVisible(true);
		
	}

	public static void main(String[] args) {
		new Ex4();
	}

}

















package event_handling;

import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

import javax.swing.JFrame;

public class Ex_Stage_1 extends JFrame {
	/*
	 * 이벤트(Event)
	 * - 컴포넌트(버튼 등)에서 사용자에 의해 어떤 상호작용이 일어나는 것
	 *   ex) 버튼 클릭, 라디오버튼 선택 등
	 * - 이벤트가 발생했을 때 어떤 동작을 수행하기 위해서는
	 *   컴포넌트와 이벤트 리스너를 서로 연결해야함
	 *   => 컴포넌트 객체의 addXXXListener() 메서드를 호출하여 리스너 객체 전달
	 *      ex) btn.addActionListener(리스너 객체);
	 * 
	 * 이벤트 처리(Event Handling)
	 * - 컴포넌트에 특정 이벤트가 발생했을 때 수행할 동작을 지정하여 처리하는 것 
	 * - 리스너(Listener) 내에 수행할 동작을 명시
	 *   => 주로 XXXListener 인터페이스 또는 XXXAdapter 클래스가 제공됨
	 * - 리스너 객체를 직접 구현하거나 별도의 핸들러 클래스를 사용하여 상속받아 구현 
	 * - 리스너 인터페이스는 주로 java.awt.event 패키지 내에 위치함 
	 */
	
	public Ex_Stage_1() {
		showFrame();
	}
	
	public void showFrame() {
		setTitle("이벤트 처리 - 1단계");
		setBounds(600, 400, 300, 200);
//		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		// 이벤트 처리 1단계. 리스너를 구현한 핸들러 클래스를 정의
		// 현재 프레임(JFrame 객체)에 WindowListener 인터페이스를 구현한 핸들러 연결
		// 1. 핸들러 객체 생성
		MyWindowListener listener = new MyWindowListener();
		// 2. 대상 컨테이너 또는 컴포넌트에 addXXXListener() 메서드를 호출하여
		//    핸들러 객체를 전달하면 대상과 이벤트 핸들러 객체의 연결 완료됨
		// => addXXXListener 의 XXXListener 부분은 구현한 대상 인터페이스명 사용
		// JFrame 객체 내의 addWindowListener() 메서드 호출하여 리스너 전달
		addWindowListener(listener);
		
		setVisible(true);
	}
	
	public static void main(String[] args) {
		new Ex_Stage_1();
	}

}

// 이벤트 처리 1단계. 
// 이벤트 처리를 위해 리스너 인터페이스를 구현하는 핸들러 클래스 정의
class MyWindowListener implements WindowListener {
	// 리스너 인터페이스를 상속받아 추상메서드 오버라이딩
	// => 이벤트 발생 시 각 동작에 맞는 메서드가 자동으로 호출됨
	@Override
	public void windowActivated(WindowEvent e) {
		System.out.println("windowActivated");
	}

	@Override
	public void windowClosed(WindowEvent e) {
		System.out.println("windowClosed");
	}

	@Override
	public void windowClosing(WindowEvent e) {
		// 창 닫기 버튼 클릭 시 호출되는 메서드
		System.out.println("windowClosing");
		System.exit(0); // 프로그램 종료
	}

	@Override
	public void windowDeactivated(WindowEvent e) {
		System.out.println("windowDeactivated");
	}

	@Override
	public void windowDeiconified(WindowEvent e) {
		System.out.println("windowDeiconified");
	}

	@Override
	public void windowIconified(WindowEvent e) {
		System.out.println("windowIconified");
	}

	@Override
	public void windowOpened(WindowEvent e) {
		System.out.println("windowOpened");
	}
	
}





















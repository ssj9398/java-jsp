package event_handling;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

import javax.swing.JFrame;

public class Ex_Stage_2 extends JFrame {
	
	public Ex_Stage_2() {
		showFrame();
	}
	
	public void showFrame() {
		setTitle("이벤트 처리 - 2단계");
		setBounds(600, 400, 300, 200);

		// 이벤트 처리 2단계. XXXListener 인터페이스 대신 XXXAdapter 클래스 사용
		// 1. 핸들러 객체 생성
		MyWindowAdapter listener = new MyWindowAdapter();
		// 2. 대상 컨테이너 또는 컴포넌트에 addXXXListener() 메서드를 호출하여
		//    핸들러 객체를 전달하면 대상과 이벤트 핸들러 객체의 연결 완료됨
		// => addXXXListener 의 XXXListener 부분은 구현한 대상 인터페이스명 사용
		// JFrame 객체 내의 addWindowListener() 메서드 호출하여 리스너 전달
		addWindowListener(listener);
		
		setVisible(true);
	}
	
	public static void main(String[] args) {
		new Ex_Stage_2();
	}

}

// 이벤트 처리 2단계. 
// Listener 인터페이스 대신 Adapter 클래스를 상속받아 구현
// => 단, 추상메서드가 2개 이상인 리스너만 어댑터 클래스가 제공됨
class MyWindowAdapter extends WindowAdapter {
	// 추상클래스로 제공되는 어댑터 클래스에는 추상메서드가 구현되어 있으므로
	// 필요한 메서드만 상속받아 정의하면 됨 => 코드가 짧아짐
	@Override
	public void windowClosing(WindowEvent e) {
		// 창 닫기 버튼 클릭 시 호출되는 메서드
		System.out.println("windowClosing");
		System.exit(0); // 프로그램 종료
	}
	
}





















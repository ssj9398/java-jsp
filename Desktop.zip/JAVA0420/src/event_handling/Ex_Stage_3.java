package event_handling;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

import javax.swing.JFrame;

public class Ex_Stage_3 extends JFrame {
	
	public Ex_Stage_3() {
		showFrame();
	}
	
	public void showFrame() {
		setTitle("이벤트 처리 - 3단계");
		setBounds(600, 400, 300, 200);

		// 이벤트 처리 3단계. 내부 클래스 사용
		MyInnerWindowAdapter listener = new MyInnerWindowAdapter();
		addWindowListener(listener);
		
		setVisible(true);
	}
	
	public static void main(String[] args) {
		new Ex_Stage_3();
	}
	
	// 이벤트 처리 3단계.
	// Listener 인터페이스 또는 Adapter 클래스를 상속받는 서브클래스를
	// 내부클래스(Inner Class) 형태로 정의하여 사용
	// => 내부클래스에서는 외부클래스(Ex_Stage_3)의 멤버에 자유롭게 접근 가능
	// => 컴파일 결과로 "외부클래스명$내부클래스명.class" 파일이 생성됨
	//    ex) Ex_Stage_3$MyInnerWindowAdapter.class
	class MyInnerWindowAdapter extends WindowAdapter  {
		@Override
		public void windowClosing(WindowEvent e) {
			// 창 닫기 버튼 클릭 시 호출되는 메서드
			System.out.println("windowClosing");
			System.exit(0); // 프로그램 종료
		}
	}

}






















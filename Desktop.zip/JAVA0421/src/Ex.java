import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Ex extends JFrame {
	
	public Ex() {
		showFrame();
	}
	
	public void showFrame() {
		setBounds(600, 400, 300, 200);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JPanel p = new JPanel();
		getContentPane().add(p, BorderLayout.CENTER);
		
		// JPanel 에 JTextField 를 부착하는 경우 생성자에 컬럼길이 명시해야함
		JTextField tf = new JTextField(10);
		p.add(tf);
		
		// JPanel 에 JButton("OK") 부착
		JButton btn = new JButton("OK");
		p.add(btn);
		
		// JButton 이벤트 처리 - 5단계
		// => OK 버튼 클릭 시 텍스트필드에 입력된 텍스트를 콘솔에 출력
		btn.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				System.out.println(tf.getText());
				tf.setText(""); // 텍스트필드 내용 초기화
				tf.requestFocus(); // 텍스트필드에 커서 요청
			}
		});
		
		
		setVisible(true);
	}

	public static void main(String[] args) {
		new Ex();
	}

}

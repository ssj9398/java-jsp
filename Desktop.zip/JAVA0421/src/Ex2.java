import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Ex2 extends JFrame {
	private JTextField tfBirth;
	
	public Ex2() {
		showFrame();
	}
	
	public void showFrame() {
		setBounds(600, 400, 300, 200);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		// 여러개의 패널 활용
		// 1. NORTH 영역에 패널을 부착하여 이름 입력받기
		JPanel pNorth = new JPanel();
		getContentPane().add(pNorth, BorderLayout.NORTH);
		
		JLabel lblName = new JLabel("이름");
		pNorth.add(lblName);
		JTextField tfName = new JTextField(10);
		pNorth.add(tfName);
		
		
		// 2. CENTER 영역에 패널을 부착하여 나이 입력받기
		JPanel pCenter = new JPanel();
		add(pCenter, BorderLayout.CENTER);
		
		JLabel lblAge = new JLabel("나이");
		pCenter.add(lblAge);
		JTextField tfAge = new JTextField(10);
		pCenter.add(tfAge);
		
		
		// 3. SOUTH 영역에 패널을 부착하여 생년월일 입력받기
		JPanel pSouth = new JPanel();
		getContentPane().add(pSouth, BorderLayout.SOUTH);
		
		JLabel lblBirth = new JLabel("생년월일");
		pSouth.add(lblBirth);
		
		tfBirth = new JTextField();
		pSouth.add(tfBirth);
		tfBirth.setColumns(10);
		
		
		// 4. EAST 영역에 버튼("확인")을 부착하여 클릭 이벤트 처리
		// => 확인 버튼 클릭 시 이름, 나이, 생년월일 입력 데이터를 콘솔에 출력
		JButton btn = new JButton("확인");
		add(btn, BorderLayout.EAST);
		
		btn.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				System.out.println("이름 : " + tfName.getText());
				System.out.println("나이 : " + tfAge.getText());
				System.out.println("생년월일 : " + tfBirth.getText());
			}
		});
		
		
		setVisible(true);
	}

	public static void main(String[] args) {
		new Ex2();
	}

}

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.GridLayout;

public class Ex3 extends JFrame {
	
	public Ex3() {
		showFrame();
	}
	
	public void showFrame() {
		setBounds(600, 400, 300, 200);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		// 컨테이너의 레이아웃 변경
		// 1. 해당 컨테이너 객체 생성 시 생성자에 레이아웃 변경 코드 사용
		// => new XXXLayout([옵션]);
//		JPanel p = new JPanel(new BorderLayout()); // JPanel 을 BorderLayout 으로 변경
		
		// 2. 해당 컨테이너 객체 생성 후 setLayout() 메서드를 사용하여 변경
//		JPanel p = new JPanel();
//		p.setLayout(new BorderLayout());// JPanel 을 BorderLayout 으로 변경
//		
//		getContentPane().add(p, BorderLayout.CENTER);
		
		
		/*
		 * GridLayout
		 * - 행, 열로 구성된 레이아웃
		 * - 균등한 크기로 셀을 분할하여 컴포넌트를 차례대로 배치
		 * - new GridLayout(행크기,열크기,열간격,행간격)
		 */
		JPanel p = new JPanel();
		getContentPane().add(p, BorderLayout.CENTER);
		p.setLayout(new GridLayout(3, 1, 0, 5));
		
		JButton btnNewButton = new JButton("New button");
		p.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("New button");
		p.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("New button");
		p.add(btnNewButton_2);
		
		
		setVisible(true);
	}

	public static void main(String[] args) {
		new Ex3();
	}

}

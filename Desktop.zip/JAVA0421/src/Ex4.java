import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.GridLayout;

public class Ex4 extends JFrame {
	
	public Ex4() {
		showFrame();
	}
	
	public void showFrame() {
		setBounds(600, 400, 300, 200);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		
		// GridLayout 4행 2열로 패널 생성
//		JPanel p = new JPanel(new GridLayout(4, 2));
//		add(p, BorderLayout.CENTER);
		
//		JLabel lblName = new JLabel("이름");
//		p.add(lblName);
//		JTextField tfName = new JTextField(10);
//		p.add(tfName);
//		
//		JLabel lblAge = new JLabel("나이");
//		p.add(lblAge);
//		JTextField tfAge = new JTextField(10);
//		p.add(tfAge);
//		
//		JLabel lblBirth = new JLabel("생년월일");
//		p.add(lblBirth);
//		JTextField tfBirth = new JTextField();
//		p.add(tfBirth);
//		
//		JButton btnOk = new JButton("확인");
//		p.add(btnOk);
//		
//		JButton btnCancel = new JButton("취소");
//		p.add(btnCancel);
		
		
		// GridLayout 4행 1열로 패널 생성
		JPanel p = new JPanel(new GridLayout(4, 1));
		add(p, BorderLayout.CENTER);
		
		// 각 행에 들어갈 패널을 생성하여 JLabel 과 JTextField 를 함께 부착
		// ------------------ 이름 --------------------
		JPanel pName = new JPanel();
		p.add(pName);
		
		JLabel lblName = new JLabel("이름");
		pName.add(lblName);
		JTextField tfName = new JTextField(10);
		pName.add(tfName);

		// ------------------ 나이 --------------------
		JPanel pAge = new JPanel();
		p.add(pAge);
		
		JLabel lblAge = new JLabel("나이");
		pAge.add(lblAge);
		JTextField tfAge = new JTextField(10);
		pAge.add(tfAge);
		
		// ------------------ 생년월일 --------------------
		JPanel pBirth = new JPanel();
		p.add(pBirth);
		
		JLabel lblBirth = new JLabel("생년월일");
		pBirth.add(lblBirth);
		JTextField tfBirth = new JTextField(10);
		pBirth.add(tfBirth);
		
		// ------------------ 버튼 --------------------
		JPanel pButton = new JPanel();
		p.add(pButton);
		
		JButton btnOk = new JButton("확인");
		pButton.add(btnOk);
		
		JButton btnCancel = new JButton("취소");
		pButton.add(btnCancel);
		
		
		
		setVisible(true);
	}

	public static void main(String[] args) {
		new Ex4();
	}

}

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.GridLayout;
import java.awt.Font;
import javax.swing.SwingConstants;
import java.awt.Color;

public class Test4 extends JFrame {
	
	public Test4() {
		showFrame();
	}
	
	public void showFrame() {
		setBounds(600, 400, 300, 300);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		// -----------     << 계산기 >>    -----------
		// ----------- 상단 숫자 표시 패널 -----------
//		JPanel pNorth = new JPanel();
//		getContentPane().add(pNorth, BorderLayout.NORTH);
		
		JTextField tfNum = new JTextField(12);
		tfNum.setEditable(false);
		tfNum.setHorizontalAlignment(SwingConstants.RIGHT);
		tfNum.setFont(new Font("굴림", Font.BOLD, 25));
		tfNum.setText("0");
		add(tfNum, BorderLayout.NORTH);
		
		
		// ----------- 중앙 숫자 버튼 패널 -----------
		JPanel pCenter = new JPanel(new GridLayout(5, 4));
		getContentPane().add(pCenter, BorderLayout.CENTER);
		
		JButton btnCE = new JButton("CE");
		btnCE.setFont(new Font("굴림", Font.BOLD, 18));
		btnCE.setBackground(Color.LIGHT_GRAY);
		pCenter.add(btnCE);

		JButton btnC = new JButton("C");
		btnC.setFont(new Font("굴림", Font.BOLD, 18));
		btnC.setBackground(Color.LIGHT_GRAY);
		pCenter.add(btnC);

		JButton btnDel = new JButton("←");
		btnDel.setFont(new Font("굴림", Font.BOLD, 18));
		btnDel.setBackground(Color.LIGHT_GRAY);
		pCenter.add(btnDel);

		JButton btnDiv = new JButton("÷");
		btnDiv.setFont(new Font("굴림", Font.BOLD, 18));
		btnDiv.setBackground(Color.LIGHT_GRAY);
		pCenter.add(btnDiv);

		JButton btnNum7 = new JButton("7");
		btnNum7.setFont(new Font("굴림", Font.BOLD, 18));
		btnNum7.setBackground(Color.WHITE);
		pCenter.add(btnNum7);

		JButton btnNum8 = new JButton("8");
		btnNum8.setFont(new Font("굴림", Font.BOLD, 18));
		btnNum8.setBackground(Color.WHITE);
		pCenter.add(btnNum8);

		JButton btnNum9 = new JButton("9");
		btnNum9.setFont(new Font("굴림", Font.BOLD, 18));
		btnNum9.setBackground(Color.WHITE);
		pCenter.add(btnNum9);

		JButton btnMul = new JButton("×");
		btnMul.setFont(new Font("굴림", Font.BOLD, 18));
		btnMul.setBackground(Color.LIGHT_GRAY);
		btnMul.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		pCenter.add(btnMul);

		JButton btnNum4 = new JButton("4");
		btnNum4.setFont(new Font("굴림", Font.BOLD, 18));
		btnNum4.setBackground(Color.WHITE);
		pCenter.add(btnNum4);

		JButton btnNum5 = new JButton("5");
		btnNum5.setFont(new Font("굴림", Font.BOLD, 18));
		btnNum5.setBackground(Color.WHITE);
		pCenter.add(btnNum5);

		JButton btnNum6 = new JButton("6");
		btnNum6.setFont(new Font("굴림", Font.BOLD, 18));
		btnNum6.setBackground(Color.WHITE);
		pCenter.add(btnNum6);

		JButton btnSub = new JButton("-");
		btnSub.setFont(new Font("굴림", Font.BOLD, 18));
		btnSub.setBackground(Color.LIGHT_GRAY);
		pCenter.add(btnSub);

		JButton btnNum1 = new JButton("1");
		btnNum1.setFont(new Font("굴림", Font.BOLD, 18));
		btnNum1.setBackground(Color.WHITE);
		pCenter.add(btnNum1);

		JButton btnNum2 = new JButton("2");
		btnNum2.setFont(new Font("굴림", Font.BOLD, 18));
		btnNum2.setBackground(Color.WHITE);
		pCenter.add(btnNum2);

		JButton btnNum3 = new JButton("3");
		btnNum3.setFont(new Font("굴림", Font.BOLD, 18));
		btnNum3.setBackground(Color.WHITE);
		pCenter.add(btnNum3);

		JButton btnAdd = new JButton("+");
		btnAdd.setFont(new Font("굴림", Font.BOLD, 18));
		btnAdd.setBackground(Color.LIGHT_GRAY);
		pCenter.add(btnAdd);

		JButton btnSign = new JButton("±");
		btnSign.setFont(new Font("굴림", Font.BOLD, 18));
		btnSign.setBackground(Color.LIGHT_GRAY);
		pCenter.add(btnSign);

		JButton btnNum0 = new JButton("0");
		btnNum0.setFont(new Font("굴림", Font.BOLD, 18));
		btnNum0.setBackground(Color.WHITE);
		pCenter.add(btnNum0);

		JButton btnDot = new JButton(".");
		btnDot.setFont(new Font("굴림", Font.BOLD, 18));
		btnDot.setBackground(Color.LIGHT_GRAY);
		pCenter.add(btnDot);

		JButton btnEqual = new JButton("=");
		btnEqual.setFont(new Font("굴림", Font.BOLD, 18));
		pCenter.add(btnEqual);
		
		// 버튼 이벤트 처리 - 4단계
		ActionListener listener = new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// 숫자0 ~ 숫자9 버튼 판별하여 각 숫자 콘솔에 출력
//				if(btnNum0.equals(e.getSource())) {
//					System.out.println("숫자0");
//				} else if(btnNum1.equals(e.getSource())) {
//					System.out.println("숫자1");
//				}
				
//				System.out.println(e.getActionCommand());
				
				// e.getActionCommand() 로 리턴된 문자열이 0 ~ 9 사이인지 판별해야함
				// e.getActionCommand().charAt(0) : 문자열 첫 글자를 char 타입 리턴
//				System.out.println(e.getActionCommand().charAt(0)); 
//				if(e.getActionCommand().charAt(0) >= '0' && 
//						e.getActionCommand().charAt(0) <= '9') {
//					System.out.println("숫자 : " + e.getActionCommand());
//				}
				
				// Character 클래스를 활용하여 동일한 판별 가능
				if(Character.isDigit(e.getActionCommand().charAt(0))) {
//					System.out.println("숫자 : " + e.getActionCommand());
					// 기존에 입력된 숫자와 클릭된 버튼의 숫자 결합하여 출력
					tfNum.setText(tfNum.getText() + e.getActionCommand());
				}
					
			}
		};
		
		// 숫자 버튼에 대한 이벤트 연결 - 4단계
		btnNum0.addActionListener(listener);
		btnNum1.addActionListener(listener);
		btnNum2.addActionListener(listener);
		btnNum3.addActionListener(listener);
		btnNum4.addActionListener(listener);
		btnNum5.addActionListener(listener);
		btnNum6.addActionListener(listener);
		btnNum7.addActionListener(listener);
		btnNum8.addActionListener(listener);
		btnNum9.addActionListener(listener);
		btnAdd.addActionListener(listener);
		btnSub.addActionListener(listener);
		btnMul.addActionListener(listener);
		btnDiv.addActionListener(listener);
		btnSign.addActionListener(listener);
		btnDot.addActionListener(listener);
		btnEqual.addActionListener(listener);
		btnCE.addActionListener(listener);
		btnC.addActionListener(listener);
		btnDel.addActionListener(listener);
		
		
		setVisible(true);
	}
	
	

	public static void main(String[] args) {
		new Test4();
	}

}
























import javax.swing.JFrame;
import javax.swing.JPasswordField;
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;

public class Ex extends JFrame {
	private JPasswordField passwordField;
	
	public Ex() {
		showFrame();
	}
	
	public void showFrame() {
		setBounds(600, 400, 300, 200);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JLabel lblNewLabel = new JLabel("패스워드 입력");
		getContentPane().add(lblNewLabel, BorderLayout.NORTH);
		
		passwordField = new JPasswordField();
		passwordField.setEchoChar('*');
		getContentPane().add(passwordField, BorderLayout.CENTER);
		
		JButton btnNewButton = new JButton("확인");
		getContentPane().add(btnNewButton, BorderLayout.SOUTH);
		
		btnNewButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// JPasswordField 에 입력된 텍스트 가져오기
				// => getPassword() 메서드 리턴타입이 char[] 타입
				// => char[] 타입으로 리턴받거나 String 객체 생성 파라미터로 전달
//				char[] chArr = passwordField.getPassword();
				String password = new String(passwordField.getPassword());
				System.out.println("입력된 패스워드 : " + password);
				
				// 정규표현식을 활용은 패스워드 입력값 검증 등 추가적인 작업 수행
			}
		});
		
		
		setVisible(true);
	}

	public static void main(String[] args) {
		new Ex();
	}

}

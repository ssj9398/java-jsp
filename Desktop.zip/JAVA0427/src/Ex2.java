import javax.swing.JFrame;
import javax.swing.JPasswordField;
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Arrays;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class Ex2 extends JFrame {
	private JTextField textField;
	
	public Ex2() {
		showFrame();
	}
	
	public void showFrame() {
		setBounds(600, 400, 300, 200);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JButton btnNewButton = new JButton("확인");
		getContentPane().add(btnNewButton, BorderLayout.SOUTH);
		
		JComboBox<String> comboBox = new JComboBox<String>();
		
		// String[] 타입을 사용하여 표시할 항목을 생성 => 배열이므로 생성 후 크기 고정
//		comboBox.setModel(new DefaultComboBoxModel(new String[] {"과목 선택", "JAVA", "JSP", "ANDROID"}));
		
		// Vector 타입을 사용하여 표시할 항목을 생성 
		// => 컬렉션이므로 생성 후에도 크기(항목) 변경 가능
//		Vector<String> list = new Vector<String>();
//		list.add("과목 선택");
//		list.add("JAVA");
//		list.add("JSP");
//		list.add("ANDROID");
		// Vector 객체 생성 시 데이터를 한꺼번에 추가하는 방법
		Vector<String> list = new Vector<String>(
				Arrays.asList("과목 선택", "JAVA", "JSP", "ANDROID"));
		// 별도의 항목을 추가 가능
		list.add("ORACLE");
		
		comboBox.setModel(new DefaultComboBoxModel<String>(list));
		
		
		getContentPane().add(comboBox, BorderLayout.CENTER);
		
		JPanel panel = new JPanel();
		getContentPane().add(panel, BorderLayout.NORTH);
		
		textField = new JTextField();
		panel.add(textField);
		textField.setColumns(10);
		
		JButton btnAdd = new JButton("추가");
		panel.add(btnAdd);
		
		
		btnNewButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				System.out.println("인덱스 : " + comboBox.getSelectedIndex());
				System.out.println("아이템 : " + comboBox.getSelectedItem());
			}
		});
		
		// JComboBox 객체에 ActionListener 직접 적용 가능
		comboBox.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				System.out.println("인덱스 : " + comboBox.getSelectedIndex());
				System.out.println("아이템 : " + comboBox.getSelectedItem());
			}
		});
		
		
		// 추가 버튼 클릭 시 텍스트필드에 입력된 항목을 JComboBox 에 동적으로 추가
		btnAdd.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
//				System.out.println(textField.getText());
				// JComboBox 에 입력된 텍스트 내용 추가
				// 1. JComboBox 객체로부터 Model 객체 가져오기
				DefaultComboBoxModel<String> model = 
						(DefaultComboBoxModel<String>) comboBox.getModel();
				// 2. Model 객체의 addElement() 메서드 호출하여 항목 추가
				model.addElement(textField.getText());
				
			}
		});
		
		
		
		setVisible(true);
	}

	public static void main(String[] args) {
		new Ex2();
	}

}

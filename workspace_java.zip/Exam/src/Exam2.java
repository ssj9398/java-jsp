
public class Exam2 {

    public static void main(String[] args) {
        /*
         * [2-1] 다음 표의 빈 칸에 8개의 기본형(primitive type)을 알맞은 자리에 넣으시오.
         *   종 류 / 크 기  1 byte    2 byte    4 byte    8 byte
         *  -------------------------------------------------------
         *  논리형          boolean
         *  문자형                    char
         *  정수형            byte    short     int       long
         *  실수형                              float     double
         *
         *
         *  [2-2] 주민등록번호를 숫자로 저장하고자 한다. 이 값을 저장하기 위해서는 어떤 자료형
         *  (data type)을 선택해야 할까? regNo라는 이름의 변수를 선언하고 자신의 주민등록번호로
         *  초기화 하는 한 줄의 코드를 적으시오.
         *  
         *  long regNo = 9010101234567L;
         *  // => 13자리 정수는 int형으로 표현 불가능하므로 long 타입 L 표시
         *  //    long 타입 변수에 저장해야한다!
    	
        /*
         * [2-3] 다음의 문장에서 리터럴, 변수, 상수, 키워드를 적으시오.
         * int i = 100;
         * long l =100L;
         * final float PI = 3.14f;
         * - 리터럴(실제 사용하는 데이터) : 100, 100L, 3.14f
         * - 변수 : i, l  (PI 는 상수형 변수)
         * - 키워드 : int, long, final, float
         * - 상수(변수 앞에 final 키워드가 붙은 것) : PI
         */
        int i = 100;
        long l = 100L;
        final float PI = 3.14f;
        
        /*
         * [2-4] 다음 중 기본형(primitive type)이 아닌 것은?   ( B )
         * a. int
         * b. Byte => 소문자 byte 는 기본형이지만 Byte 는 아니다!
         * c. double
         * d. boolean
         */
        
        // [2-5] 다음 문장들의 출력결과를 적으세요. 오류가 있는 문장의 경우, 
        //       괄호 안에 '오류'라고 적으시오.
        System.out.println("1" + "2"); // "12"
        System.out.println(true + ""); // "true" => 어떤데이터와 널스트링("")을 결합하면 문자열로 변환됨
        
        
        System.out.println('A' + 'B'); // 131 => 'A'(65) + 'B'(66) = 131 (주의사항! 정수로 출력됨)
                                       // => char + char = int 가 되어 정수가 출
        
        System.out.println('1' + 2); // 51 => '1'(49) + 2 = 51 (주의사항! 정수로 출력됨)
        System.out.println((char)('1' + 2)); // 연산결과(51)를 char 로 변환하면 '3' 출력됨
        
        System.out.println('1' + '2'); // 99 => '1'(49) + '2'(50) = 99 (주의사항! 정수로 출력됨)
        System.out.println((char)('1' + '2')); // 연산결과(99)를 char 로 변환하면 'c' 출력됨
        
        
        System.out.println('J' + "ava"); // "Java" => char 타입과 문자열 결합 시 그대로 문자 상태로 결합됨
//        System.out.println(true + null); // 오류! 
        
        /*
         * [2-6] 다음 중 키워드가 아닌 것은? (모두 고르시오) ( B, C, D, E )
         * a. if
         * b. True
         * c. NULL
         * d. Class
         * e. System
         */
        
        /*
         * [2-7] 다음 중 변수의 이름으로 사용할 수 있는 것은? (모두 고르시오) 
         *       => ( A, D, E, G )
         * a. $ystem    => (O) : 특수문자 $ 와 _ 사용 가능
         * b. channel#5 => (X) : 특수문자 # 사용 불가
         * c. 7eleven   => (X) : 숫자로 시작 불가
         * d. If        => (O) : 만약 소문자 if일 경우 키워드이므로 사용 불가
         * e. 자바      => (O) : 한글 사용 가능
         * f. new       => (X) : 키워드 사용 불가
         * g. $MAX_NUM  => (O) : 특수문자 $ 와 _ 사용 가능, 대문자 사용 가능
         * h. hello@com => (X) : 특수문자 @ 사용 불가
         * 
         * 
         * [2-8] 참조형 변수(reference type)와 같은 크기의 기본형(primitive type)은? 
         *       (모두 고르시오)  => ( A, D )
         *       => 참조형 변수는 모두 4Byte 크기를 갖는다!
         * a. int    (4Byte)  (O)
         * b. long   (8Byte)
         * c. short  (2Byte)
         * d. float  (4Byte)  (O)
         * e. double (8Byte)
         * 
         * 
         * [2-9] 다음 중 형변환을 생략할 수 있는 것은? (모두 고르시오)
         * byte b = 10;
         * char ch = 'A';
         * int i = 100;
         * long l = 1000L;
         * 
         * a. b = (byte)i;
         * b. ch = (char)b;
         * c. short s = (short)ch;
         * d. float f = (float)l;
         * e. i = (int)ch;
         */
        byte b = 10;
        char ch = 'A';
        int ii = 100;
        long ll = 1000L;
         
//        b = ii; // 형변환 생략 불가
//        ch = b; // 형변환 생략 불가
//        short s = ch; // 형변환 생략 불가
//        float f = ll; // 생략 가능
//        ii = ch; // 생략 가능
        
        /*
         * [2-10] char 타입의 변수에 저장될 수 있는 정수 값의 범위는? (10진수로 적으시오)
         *  => 2^16 = 65536 = 0 ~ 65535
         * 
         * 
         * [2-11] 다음중 변수를 잘못 초기화 한 것은? (모두 고르시오) ( A, B, C, D )
         * a. byte b = 256; // (X) byte 타입 표현 범위 : -128 ~ 127 이므로 불가!
         * b. char c = ''; // (X) 반드시 한 글자 필수!
         * c. char answer = 'no'; // (X) 반드시 한 글자 필수!
         * d. float f = 3.14; // (X) 3.14 뒤에 접미사 f 필수!
         * e. double d = 1.4e3f; // (O) 1.4e3f 는 지수 표현법이므로 1.4 * 10^3 f와 동일하며
         *                       // float 타입 리터럴은 double 타입 변수에 저장 가능
         */
        
        
    }

}
















public class Exam3_10 {

	public static void main(String[] args) {
		/*
		 * [3-10] 다음은 대문자를 소문자로 변경하는 코드인데 
		 * 문자에 저장된 문자가 대문자인 경우에만 소문자로 변경한다. 
		 * 문자코드는 소문자가 대문자보다 32 만큼 더 크다.
		 * 예를 들어 'A'의 코드 65는 이고 'a'의 코드는 97이다. 
		 * (1) ~ (2)에 알맞은 코드를 넣으시오.
		 */
		char ch = 'r';
		
		// 대문자일 경우 소문자로 변환하고, 그렇지 않으면 그대로 사용
		// => 소문자로 변환 시 char + int = int 이므로 char 타입 형변환 필수!
//		char lowerCase = (대문자) ? (소문자로 변환) : ch;
		char lowerCase = (ch >= 'A' && ch <= 'Z') ? (char)(ch + 32) : ch;
		
		System.out.println("ch = " + ch);
		System.out.println("ch to lowerCase = " + lowerCase);
	}

}

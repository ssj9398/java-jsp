
public class Exam3_8 {

    public static void main(String[] args) {
        /*
         * [3-8] 아래 코드의 문제점을 수정해서 실행결과와 같은 결과를 얻도록 하시오.
         * c = 30
         * ch = C
         * f = 1.5
         * l = 27000000000
         * result = true
         */
        byte a = 10;
        byte b = 20;
//        byte c = a + b; // byte + byte = int 이므로 형변환 필수!
        byte c = (byte)(a + b); // 연산 결과를 byte 타입으로 형변환
        
        char ch = 'A';
//        ch = ch + 2; // char + int = int 이므로 형변환 필수!
//        ch = (char)(ch + 2); // 연산 결과를 char 타입으로 형변환하거나
        ch += 2; // 확장 대입연산자를 통해 형변환 없이 연산을 수행하면 된다.
        
//        float f = 3 / 2; // int / int = int 이므로 소수점 연산 불가 => 형변환 필요
//        float f = 3 / (float)2; // 형변환 연산자를 사용하거나
        float f = 3 / 2f; // 접미사 f 를 사용하여 float 타입으로 표현하여 연산을 수행
        
//        long l = 3000 * 3000 * 3000; // 27000000000 이어야하지만 이상한 결과가 출력됨
        // => 기본 정수형은 int 형이므로 270억 수치데이터 표현 시 오버플로우 발생함
        // => 따라서, 최소한 하나의 데이터를 long 타입으로 표현해야함
        long l = 3000 * 3000 * 3000L; // 접미사 L 을 사용하여 long 타입으로 표현
        
        float f2 = 0.1f;
        double d = 0.1;
//        boolean result = d == f2;
        // 실수 표현 시 근사치 표현 방식에 의해 float 타입, double 타입 간의 불일치 발생
        // => double 타입을 float 타입으로 일치시킨 후 비교 수행
        boolean result = (float)d == f2;
        
        System.out.println("c = " + c);
        System.out.println("ch = " + ch);
        System.out.println("f = " + f);
        System.out.println("l = " + l);
        System.out.println("result = " + result);
        
    }

}

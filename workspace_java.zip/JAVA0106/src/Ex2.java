
public class Ex2 {

	public static void main(String[] args) {
		/*
		 * 형변환(Type Casting)
		 * - 데이터타입 간의 변환이 일어나는 것
		 * - 기본형 끼리의 형변환과 참조형 끼리의 형변환으로 구분
		 * 
		 * 1. 묵시적 형변환(= 암시적 형변환 = 자동 형변환)
		 * - 작은 데이터타입에서 큰 데이터타입으로 변환하는 경우
		 *   별도의 형변환 연산자를 사용하지 않아도 자동으로 변환됨
		 * - 따라서, 오류가 발생하지 않으며 원본 데이터 그대로 변환됨
		 * 
		 * 2. 명시적 형변환(= 강제 형변환)
		 * - 큰 데이터타입에서 작은 데이터타입으로 변환하는 경우
		 *   반드시 형변환 연산자를 사용하여 우변의 데이터 앞에 작은 데이터타입명을 명시
		 * - 이 때, 강제 변환 과정에서 원본 데이터의 넘침(Overflow, 오버플로우) 이 발생하여 
		 *   원본 데이터가 아닌 다른 데이터가 저장될 수 있다.
		 *   
		 *   < 형변환 연산자 사용 문법 >
		 *   (데이터타입)데이터; // 명시적 형변환의 경우 작은 데이터타입을 명시한다!
		 *   
		 */
		
		int a1 = 128;
		byte a2 = 127;
		
		System.out.println("변환 전 a1(int) : " + a1 + ", a2(byte) : " + a2);
		
		// 묵시적 형변환 : 작은 데이터타입 -> 큰 데이터타입으로 변환
		a1 = a2; // byte 타입(작은) 데이터를 int 타입(큰) 변수에 저장
//		a1 = (int)a2; // 형변환 연산자를 사용해도 되지만, 생략함
		System.out.println("변환 후 a1(int) : " + a1 + ", a2(byte) : " + a2);
		System.out.println(); // 엔터키 역할을 수행하는 문장으로 사용됨
		
		
		int b1 = 128;
		byte b2 = 127;
		
		System.out.println("변환 전 b1(int) : " + b1 + ", b2(byte) : " + b2);
		
//		b2 = b1; // 오류 발생! Type mismatch: cannot convert from int to byte
		// int 타입(큰) 데이터를 byte 타입(작은) 변수에 저장하려 할 경우
		// 큰 타입 데이터가 저장될 때 오버플로우가 발생할 우려가 있으므로 변환되지 않는다!
		// => 반드시 형변환(캐스팅) 연산자 사용 필수!
		b2 = (byte)b1; // 우변 데이터 앞에 좌변(작은) 데이터타입 이름을 () 사이에 명시한다.
		System.out.println("변환 후 b1(int) : " + b1 + ", b2(byte) : " + b2);
		// 변환에 성공하더라도 오버플로우(Overflow)에 의해 
		// 원본 데이터가 아닌 다른 데이터로 변형될 수 있다!
		
		
		// 강제 형변환 후에도 오버플로우가 발생하지 않는 경우
		// => 작은 데이터타입에 저장 가능한 데이터 범위인 경우 오버플로우 발생 X
		int c1 = 10;
		byte c2 = 0;
		
		System.out.println("변환 전 c1(int) : " + c1 + ", c2(byte) : " + c2);
		
		c2 = (byte)c1; // 우변 데이터 앞에 좌변(작은) 데이터타입 이름을 () 사이에 명시한다.
		System.out.println("변환 후 c1(int) : " + c1 + ", b2(byte) : " + c2);
		
		
		// char 타입의 경우 표현 가능한 데이터 범위 : 정수 0 ~ 65535 까지 표현
		// => 음수가 없다!
		//    따라서, byte 또는 short 타입과 char 타입은 무조건 명시적 형변환 필수!
		//    (음수 표현 가능 여부에 따라 표현 범위가 서로 다르기 때문)
		byte b = 65;
		short s = 100;
		
		// ----- byte <-> char -----
//		char ch1 = b; // byte -> char 변환 시 형변환 연산자 필수!
		char ch1 = (char)b;
		System.out.println(ch1);
		
//		b = ch1; // char -> byte 변환 시 형변환 연산자 필수!
		b = (byte)ch1;
		System.out.println(b);
		
		// ----- short <-> char -----
//		char ch2 = s; // short -> char 변환 시 형변환 연산자 필수!
		char ch2 = (char)s;
		System.out.println(ch2);
		
//		s = ch2; // char -> short 변환 시 형변환 연산자 필수!
		s = (short)ch2;
		System.out.println(s);
		
	}

}














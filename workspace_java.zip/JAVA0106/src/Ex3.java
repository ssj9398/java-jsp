
public class Ex3 {

	public static void main(String[] args) {
		/*
		 * print(), println(), printf()
		 * 1. print() 와 println() 은 출력 후 줄바꿈 여부의 차이
		 *    => print() 메서드는 아무 데이터도 없으면 출력 불가능
		 *    
		 * 2. printf()
		 *    - 출력할 형식을 미리 지정하여 원하는 형태로 데이터 출력
		 *      (printf 메서드의 f 는 format 의 약자)
		 *    - 출력할 형식은 "" 큰따옴표 안에 형식 지정문자를 사용하여 형식을 지정한 뒤
		 *      큰따옴표("") 우측에 콤마(,) 를 붙이고 실제 데이터를 지정 
		 *   
		 */
		
		System.out.println("Java"); // "Java" 문자열 출력 후 줄바꿈 수행
		System.out.println("Programming"); // 새로운 라인에 "Programming" 문자열 출력됨
		
		System.out.println("-----------------");
		
		System.out.print("Java"); // "Java" 문자열 출력 후 줄바꿈 수행 X
		System.out.println("Programming"); // "Java" 문자열 뒤에 "Programming" 문자열 출력됨
		
		System.out.println("-----------------");
		
		System.out.printf("1234567890"); // print() 메서드와 마찬가지로 줄바꿈 X
		System.out.printf("1234567890 \n"); // \n 사용하여 줄바꿈 필요
		
		// %d 또는 %Xd : 10진수 출력(X 부분에 옵션)
		System.out.printf("%d$ \n", 12345); // 10진수 출력
		System.out.printf("%10d$ \n", 12345); // 10진수 10자리 확보 후 출력(오른쪽 정렬)
		System.out.printf("%-10d$ \n", 12345); // 10진수 10자리 확보 후 출력(왼쪽 정렬)
		
		System.out.printf("현재잔고 : %,d원 \n", 100000000); // 세 자리마다 콤마(,) 출력
		
		// %f 또는 %Xf : 10진수 실수 출력(X 부분 옵션)
		System.out.printf("%f \n", 3.141592);
		System.out.printf("%2f \n", 3.141592);
		System.out.printf("%.2f \n", 3.141592); // .xf 에서 x 자리만큼 소수점 표시(반올림 처리)
		
		
		// 10진수, 8진수, 16진수 출력
		System.out.printf("%d \n", 255); // 10진수(Decimal)
		System.out.printf("%o \n", 255); // 8진수(Octal)
		System.out.printf("%x \n", 255); // 16진수(heXa decimal)
		
		// 8진수 정수 표기법 : 숫자 앞에 접두어 0 붙임
		System.out.println(0777); // 8진수 표현법(출력문에 사용 시 자동으로 10진수로 변환됨)
//		System.out.println(0888); // 오류 발생! 8진수는 0 ~ 7 까지 숫자 조합
		System.out.printf("8진수 %o = 10진수 %d \n", 014, 014);
		
		// 16진수 정수 표기법 : 숫자 앞에 접두어 0x
		System.out.println(0xA); // 16진수 표현법(A -> 10진수로 변환하여 10 출력됨)
//		System.out.println(0xGGG); // 오류 발생! 16진수는 0 ~ 9 와 A ~ F 까지 조합
		System.out.printf("16진수 %x = 10진수 %d \n", 0xA, 0xA); // A ~ F 를 소문자로 출력
		System.out.printf("16진수 %X = 10진수 %d \n", 0xA, 0xA); // A ~ F 를 대문자로 출력
		
		
		
		// %c : 문자 1개 지정
		System.out.printf("%c %c %c\n", 'A', 65, '\u0041');
		
		
		// %s 또는 %Xs : 문자열 지정(X 는 옵션)
		System.out.printf("%s \n", "Korea"); // 문자열 출력
		System.out.printf("%10s \n", "Korea"); // 문자열 10자리 확보 후 우측 정렬 출력
		System.out.printf("%10.3s \n", "Korea"); // 문자열 10자리 확보, 3글자만 우측 정렬 출력
		System.out.printf("%10.3S \n", "Korea"); // 문자열 모두 대문자로 출력
		
		
		String str = "Java Programming";
		System.out.printf("%S \n", str); // 변수도 사용 가능
		
	}

}











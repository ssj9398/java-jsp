
public class Test3 {

	public static void main(String[] args) {
		/*
		 * 구구단 2단을 다음과 같이 출력 => printf() 메서드 사용
		 * 
		 *  < 2단 >
		 * 2 * 1 = 2
		 * 2 * 2 = 4
		 * 2 * 3 = 6
		 * 2 * 4 = 8
		 * 2 * 5 = 10
		 * 2 * 6 = 12
		 * 2 * 7 = 14
		 * 2 * 8 = 16
		 * 2 * 9 = 18
		 */
		int dan = 2;
		
		System.out.printf(" < %d단 > \n", dan);
		System.out.printf("%d * %d = %d \n", dan, 1, 2);
		System.out.printf("%d * %d = %d \n", dan, 2, 4);
		System.out.printf("%d * %d = %d \n", dan, 3, 6);
		System.out.printf("%d * %d = %d \n", dan, 4, 8);
		System.out.printf("%d * %d = %d \n", dan, 5, 10);
		System.out.printf("%d * %d = %d \n", dan, 6, 12);
		System.out.printf("%d * %d = %d \n", dan, 7, 14);
		System.out.printf("%d * %d = %d \n", dan, 8, 16);
		System.out.printf("%d * %d = %d \n", dan, 9, 18);
		
		System.out.println("----------------------------");
		
		System.out.println(" < " + dan + "단 >");
		System.out.println(dan + " * " + 1 + " = " + 2);
		System.out.println(dan + " * " + 2 + " = " + 4);
		System.out.println(dan + " * " + 3 + " = " + 6);
		System.out.println(dan + " * " + 4 + " = " + 8);
		System.out.println(dan + " * " + 5 + " = " + 10);
		System.out.println(dan + " * " + 6 + " = " + 12);
		System.out.println(dan + " * " + 7 + " = " + 14);
		System.out.println(dan + " * " + 8 + " = " + 16);
		System.out.println(dan + " * " + 9 + " = " + 18);
		
		
	}

}








public class Ex {

	public static void main(String[] args) {
		/*
		 * 산술 연산자(+, -, *, /, %)
		 * - 일반 사칙연산과 동일
		 * - % 연산자 : 나머지 연산자(퍼센트 연산자)라고 하며, 나눗셈 결과의 나머지 계산  
		 */
		
		System.out.println(10 + 2);
		System.out.println(10 - 2);
		System.out.println(10 * 2);
		System.out.println(10 / 2); // 10 을 2로 나눈 몫 계산(5)
		System.out.println(10 % 2); // 10 을 2로 나눈 나머지 계산(0)
		
		
		int a = 10, b = 3, c;
		
		c = a + b;
		System.out.println(a + " + " + b + " = " + c);
		System.out.printf("%d + %d = %d \n", a, b, c);
		
		c = a - b;
		System.out.println(a + " - " + b + " = " + c);
		System.out.printf("%d - %d = %d \n", a, b, c);
		
		c = a * b;
		System.out.println(a + " * " + b + " = " + c);
		System.out.printf("%d * %d = %d \n", a, b, c);
		
		c = a / b;
		System.out.println(a + " / " + b + " = " + c);
		System.out.printf("%d / %d = %d \n", a, b, c);
		
		c = a % b;
		System.out.println(a + " % " + b + " = " + c);
		System.out.printf("%d %% %d = %d \n", a, b, c);
		// => printf() 메서드에서 % 출력을 위해서는 %% 형태로 지정해야한다!
		
		System.out.println("-------------------------------");
		
		/*
		 * 산술 연산 시 자동 형변환
		 * - 산술 연산을 수행하기 전 피연산자끼리의 데이터타입을 일치시킨 후 연산 수행
		 * - 규칙1. int 타입보다 작은 타입끼리의 연산은 모두 int 타입으로 변환 후 연산 수행
		 *          => 따라서, 결과값이 무조건 int 타입이 됨
		 *   ex) byte + byte = (int)byte + (int)byte 로 변환되어 연산 수행 = 결과가 int 타입
		 *   ex2) char + int = (int)char + int = int
		 * - 규칙2. int 타입보다 큰 타입과의 연산은 큰 타입으로 변환 후 연산 수행
		 *   ex) int + long = (long)int + long = long
		 *   ex2) int + double = (double)int + double = double
		 *   
		 */
		
		byte b1 = 10, b2 = 20, b3;
		System.out.println(b1 + b2);
		
//		b3 = b1 + b2; // 오류 발생! byte + byte = int 이므로 byte 타입 변수에 저장 불가!
		b3 = (byte)(b1 + b2); // 연산 결과에 형변환 연산자를 적용하여 byte 타입으로 변환
		System.out.println(b3);
		
		char ch = 'A';
//		char ch2 = (ch + 2); // Type mismatch: cannot convert from int to char
		char ch2 = (char) (ch + 2); // char + int = int 이므로 char 타입 변수에 저장 불가!
		// => 연산 결과에 형변환 연산자를 적용하여 char 타입으로 변환
		System.out.println(ch2);
		System.out.println(ch + 2); // ch + 2 = int 이므로 문자 'C' 가 아닌 67 출력됨
		
		
		int i = 100;
		long l = 200;
//		int i2 = i + l; // int + long = long 이므로 int 타입 변수에 저장 불가!
		int i2 = (int)(i + l); // 연산 결과를 int 타입으로 형변환 후 저장
		System.out.println(i2);
		
		float f = 3.14f;
		System.out.println(l + f); // long + float = float 
		long l2 = (long) (l + f);
		
		
		System.out.println(10 / 3); // 몫을 계산하므로 3 출력
		// => int / int = int 이므로 정수 결과로 출력됨
		//    최소한 하나의 피연산자를 실수형으로 변환 후 연산하면 소수점까지 계산됨
		System.out.println(10 / (double)3); // int / double = double(잘 사용하지 않는 방법)
		System.out.println(10 / 3.0); // int / double = double(실제 사용하는 방법!!)
		// => 수치데이터는 .0 을 붙여서 실수로 표현하고
		//    변수를 사용할 경우 형변환 연산자를 사용하여 실수로 변환함
		System.out.println(10 / 3f);
		
		float f1 = 0.1f;
		double d1 = 0.1;
		System.out.println(f1 + d1); // float + double = float -> double 로 변환 후 연산
		// 이 때, 근사치 표현에 의해 잘못된 결과가 발생할 수 있다!
		// 따라서, double -> float 타입으로 강제형변환 후 연산 수행해야 한다!
		System.out.println(f1 + (float)d1);
		
		
		
		byte b4 = 10 + 20; // 리터럴끼리의 연산은 형변환이 발생하지 않는다!
//		byte b5 = 100 + 28; // 리터럴끼리의 연산이더라도 범위를 초과하면 오류 발생!
		
	}

}




















public class Ex2 {

	public static void main(String[] args) {
		/*
		 * 대입연산자(=)
		 * - 우변의 데이터를 좌변의 변수에 대입(저장)
		 *   => 연산 방향이 우 -> 좌로 진행됨
		 *      ex) x = y = 3 의 경우 y에 3을 대입하고 x 에 y를 대입
		 * - 모든 연산자 중에서 우선순위가 가장 낮다
		 * 
		 * 확장 대입연산자(복합 대입연산자)(+=, -=, *=, /=, %=)
		 * - 대입연산자와 산술연산자를 조합한 연산자
		 * - 좌변과 우변의 데이터끼리 산술연산을 먼저 수행한 후 결과값을 좌변에 대입 
		 */
		
		int a = 10, b;
		
		b = a; // 변수 a의 값을 b 에 대입
		System.out.println(b);
		
		// b + a 의 결과를 다시 변수 b 에 저장 => b 에 a 값을 누적하는 것과 동일
		b += a; // b = b + a 와 동일 (10 + 10 = 20)
		System.out.println(b);
		
		// b = b - a
		b -= a; // b = b + a 와 동일 (20 - 10 = 10) 
		System.out.println(b);
		
		// b = b * a
		b *= a; // b = b + a 와 동일 (10 * 10 = 100)
		System.out.println(b);
		
		// b = b / a
		b /= a; // b = b + a 와 동일 (100 / 10 = 10)
		System.out.println(b);
		
		// b = b % a 
		b %= a; // b = b + a 와 동일 (10 % 10 = 0)
		System.out.println(b);
	}

}


















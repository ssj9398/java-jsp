
public class Test2 {

	public static void main(String[] args) {
		// 정수 num 에 대한 양수, 음수, 0 판별
		int num = -3;
		System.out.println(num > 0 ? "양수" : num < 0 ? "음수" : "0");
		
		System.out.println("----------------------------------------");
		
		// 문자 ch 대해 "대문자" 와 "소문자" 판별, 나머지는 "기타문자" 출력
		char ch = '1';
		System.out.println(ch >= 'A' && ch <= 'Z' ? "대문자" : 
								ch >= 'a' && ch <= 'z' ? "소문자" : "기타문자");
		
	}

}

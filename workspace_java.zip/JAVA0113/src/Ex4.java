
public class Ex4 {

	public static void main(String[] args) {
		/*
		 * 중첩 if문
		 * - if문 블록 내에서 또 다른 if 문을 기술하는 것
		 *   (else 블록 내에서 기술해도 됨)
		 * 
		 * < 기본 문법 >
		 * if(조건식1) {
		 * 		// 조건식1 이 true 일 때 실행할 문장들...
		 * 		if(조건식 1-2) {
		 * 			// 조건식 1이 true 이고, 조건식 1-2 가 true 일 때 실행할 문장들...	
		 * 		} else {
		 * 			// 조건식 1이 true 이고, 조건식 1-2 가 false 일 때 실행할 문장들...
		 * 		}
		 * } else {
		 * 		// 조건식 1이 false 일 때 실행할 문장들...(if문 추가 가능)
		 * }
		 */
		int score = 98; // 점수
		String grade = ""; // 학점
		
		// 점수(score) 0에서 100 사이일 때만 학점 계산하고
		// 아니면 "점수 입력 오류" 를 출력
		if(score >= 0 && score <= 100) {
			if(score >= 90) { // 상위 if문에서 100 이하를 판별했으므로 90 이상만 판별하면 됨
				grade = "A";
			} else if(score >= 80) {
				grade = "B";
			} else if(score >= 70) {
				grade = "C";
			} else if(score >= 60) {
				grade = "D";
			} else { 
				grade = "F";
			}
			
			System.out.println(score + "점의 학점 : " + grade);
		} else {
			System.out.println(score + "점 : 점수 입력 오류!");
		}
		
	}

}


public class Test {

	public static void main(String[] args) {
		// 정수형 변수 num 에 대한 절대값 계산하여 출력
		// => ex) 변수 num 이 5일 때 => "변수 num = 5"
		//    ex2) 변수 num 이 -5 일 때 => 음수를 양수로 절대값 변환 후 "변수 num = 5" 출력
		
		// 문장1. 변수 num 선언 및 초기화
		int num = -5;
		
		// 조건식 판별을 통해 변수 num 이 음수일 때 양수로 변환(절대값 계산) - 문장2
		if(num < 0) { // 조건식
			// 문장2
			System.out.println("num = " + num + " 이므로 양수로 변환!");
			num = -num; // 음수 -> 양수 변환
		}
		
		// 문장3. "변수 num = X" 출력
		System.out.println("변수 num = " + num);
		
		System.out.println("===============================");
		
		// 문자 ch 가 대문자일 때 소문자로 변환하여 출력
		char ch = 'r'; // 문장1
		
		if(ch >= 'A' && ch <= 'Z') { // 조건식
			ch += 32; // 문장2(소문자로 변환)
		}
		
		System.out.println("ch = " + ch); // 문장3
		
		
		
	}

}

























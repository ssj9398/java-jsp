
public class Test2 {

	public static void main(String[] args) {
		int num = 10;
		
		// 정수형 변수 num 에 대한 양수, 음수 판별(0은 양수에 포함시킴)
		if(num >= 0) {
			System.out.println(num + " : 양수!");
		} else {
			System.out.println(num + " : 음수!");
		}
		
		System.out.println("==========================================");
		// 정수형 변수 num 에 대한 홀수, 짝수 판별(0은 짝수에 포함시킴)
		if(num % 2 == 1) {
			System.out.println(num + " : 홀수!");
		} else {
			System.out.println(num + " : 짝수!");
		}
		
		System.out.println("==========================================");
		
		// 문자 ch 가 대문자이면 소문자로 변환, 아니면 대문자로 변환
		char ch = 'A';
		
		if(ch >= 'A' && ch <= 'Z') {
			ch += 32;
			System.out.println("대문자이므로 소문자로 변환!");
		} else {
			ch -= 32;
			System.out.println("소문자이므로 대문자로 변환!");
		}
		
		System.out.println("ch = " + ch);
		
		
	}

}


















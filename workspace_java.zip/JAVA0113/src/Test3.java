
public class Test3 {

	public static void main(String[] args) {
		// 정수형 변수 num 에 대한 양수, 음수, 0 판별
		int num = 0;
		
		if(num > 0) {
			System.out.println(num + " : 양수!");
		} else if(num < 0) {
			System.out.println(num + " : 음수!");
		} else {
			System.out.println(num + " : 0!");
		}
		
		System.out.println("==========================================");
		
		// 정수형 변수 num 에 대한 홀수, 짝수, 0 판별(짝수보다 0이 먼저 판별되어야 함)
		if(num % 2 == 1) {
			System.out.println(num + " : 홀수!");
		} else if(num == 0) {
			System.out.println(num + " : 0!");
		} else {
			System.out.println(num + " : 짝수!");
		}
		
		System.out.println("==========================================");
		
		// 문자 ch 가 대문자일 경우 소문자로 변환, 소문자일 경우 대문자로 변환
		// 아니면 "ch 는 영문자가 아닙니다!" 출력
		// ch 출력
		char ch = '@';
		
		if(ch >= 'A' && ch <= 'Z') {
			ch += 32;
			System.out.println("대문자이므로 소문자로 변환!");
		} else if(ch >= 'a' && ch <= 'z') {
			ch -= 32;
			System.out.println("소문자이므로 대문자로 변환!");
		} else {
			System.out.println("ch 는 영문자가 아닙니다!");
		}
		
		System.out.println("ch = " + ch);
		
		System.out.println("==========================================");
		/*
		 * 학생 점수(score) 에 대한 학점(grade) 판별
		 * A학점 : 90 ~ 100점
		 * B학점 : 80 ~ 89점
		 * C학점 : 70 ~ 79점
		 * D학점 : 60 ~ 69점
		 * F학점 : 0 ~ 59점 
		 * 그 외 : "점수 입력 오류!"
		 */
		int score = 188; // 점수
		String grade = ""; // 학점
		
		if(score >= 90 && score <= 100) {
			grade = "A";
		} else if(score >= 80 && score <= 89) {
			grade = "B";
		} else if(score >= 70 && score <= 79) {
			grade = "C";
		} else if(score >= 60 && score <= 69) {
			grade = "D";
		} else if(score >= 0 && score <= 59) {
			grade = "F";
		} else {
			grade = "점수 입력 오류!";
		}
		
		System.out.println(score + "점의 학점 : " + grade);
		
	}

}

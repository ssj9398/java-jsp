
public class Test4 {

	public static void main(String[] args) {
		// 문자 ch 에 대한 대<->소문자 변환 후 출력
		// 단, ch 가 영문자가 아닐 경우 "입력 오류!" 출력
		char ch = 'R';
		
		if((ch >= 'A' && ch <= 'Z') || (ch >= 'a' && ch <= 'z')) { // 영문자 = 대문자 or 소문자
			// 대문자와 소문자를 구별하여 변환 수행
			if(ch >= 'A' && ch <= 'Z') {
				System.out.println(ch + " : 대문자이므로 소문자로 변환!");
				ch += 32;
			} else {
				System.out.println(ch + " : 소문자이므로 대문자로 변환!");
				ch -= 32;
			}
			
			System.out.println("변환 결과 : " + ch);
		} else {
			System.out.println(ch + " : 입력 오류!");
		}
	}

}

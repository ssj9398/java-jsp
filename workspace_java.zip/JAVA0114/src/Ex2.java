
public class Ex2 {

	public static void main(String[] args) {
		/*
		 * 학생 점수(score) 에 대한 학점(grade) 판별
		 * A학점 : 90 ~ 100점
		 * B학점 : 80 ~ 89점
		 * C학점 : 70 ~ 79점
		 * D학점 : 60 ~ 69점
		 * F학점 : 0 ~ 59점 
		 * 그 외 : "점수 입력 오류!"
		 */
		int score = 88; // 점수
		String grade = ""; // 학점
		
//		if(score >= 90 && score <= 100) {
//			grade = "A";
//		} else if(score >= 80 && score <= 89) {
//			grade = "B";
//		} else if(score >= 70 && score <= 79) {
//			grade = "C";
//		} else if(score >= 60 && score <= 69) {
//			grade = "D";
//		} else if(score >= 0 && score <= 59) {
//			grade = "F";
//		} else {
//			grade = "점수 입력 오류!";
//		}
		
		// switch ~ case 문을 사용하여 학점 계산을 수행할 경우
		// => case 문에서 값 지정 시 범위 지정이 불가능
		score = 188;
		
		switch(score) {
			// 판별에 필요한 값들을 하나하나 비교해야함
			case 100 : grade = "A"; break;
			case 99 : grade = "A"; break;
			case 98 : grade = "A"; break;
			// .... 생략 ...
			case 89 : grade = "B"; break;
			case 88 : grade = "B"; break;
			// .... 생략 ....
			case 0 : grade = "F"; break;
			default : grade = "점수 입력 오류!";
		}
		
		
		System.out.println(score + "점의 학점 : " + grade);
	}

}

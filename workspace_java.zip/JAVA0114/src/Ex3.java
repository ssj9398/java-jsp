
public class Ex3 {

	public static void main(String[] args) {
		/*
		 * 반복(loop)문
		 * - 특정 조건에 따라 문장 또는 블럭을 반복 실행하는 문
		 * - for문, while문 으로 구분됨
		 *   => for문은 주로 반복횟수가 정해져 있는 반복문에 사용되며,
		 *      while문은 주로 반복횟수가 정해져 있지 않은 반복문에 사용됨
		 * - 초기식, 조건식, 증감식, 실행문(블록)으로 구성됨
		 * 
		 * 1. for문
		 * - 초기식, 조건식, 증감식의 위치가 정해져 있는 반복문(초심자에게 유리)
		 * 
		 * < 기본 문법 >
		 * for(초기식; 조건식; 증감식) {
		 * 		// 조건식 결과가 true 일 때 반복 실행할 문장들...
		 * }
		 */
		System.out.println("1 : Hello, World!");
		System.out.println("2 : Hello, World!");
		System.out.println("3 : Hello, World!");
		System.out.println("4 : Hello, World!");
		System.out.println("5 : Hello, World!");
		System.out.println("6 : Hello, World!");
		System.out.println("7 : Hello, World!");
		System.out.println("8 : Hello, World!");
		System.out.println("9 : Hello, World!");
		System.out.println("10 : Hello, World!");
		
		// for문을 사용하여 "Hello, World!" 문자열 10번 반복 출력
		// => 제어변수 i가 1부터 10까지 1씩 증가하면서 "Hello, World" 문자열 반복 출력
		for(int i = 1; i <= 10; i++) {
			// 초기식 int i = 1 : 반복 횟수를 제어할 제어변수 i 값을 1로 설정
			// 조건식 i <= 10 : 초기식에서 설정한 제어변수가 10 이하일 동안 반복
			//                  => 조건식 i <= 10 결과가 true 일 동안 반복
			// 증감식 i++ : 조건식 결과가 true 일 때 반복할 문장을 실행한 후
			//              다음 조건 판별 전 제어변수를 증감(변화)시키는 문장
//			System.out.println("Hello, World!"); // 반복 실행할 문장
			System.out.println(i + " : Hello, World!"); // 반복 실행할 문장
		}
		
//		System.out.println("for문 종료 후의 제어변수 i값 : " + i);
		
		/*
		 * 위의 for문에 대한 디버깅(Debugging) 작업
		 * 제어변수(i)  조건식(i <= 10)  실행결과(i + " : Hello, World!")  증감식(i++)
		 * ---------------------------------------------------------------------------
		 *      1           true            "1 : Hello, World!" 출력           2
		 *      2           true            "2 : Hello, World!" 출력           3
		 *      3           true            "3 : Hello, World!" 출력           4
		 *      4           true            "4 : Hello, World!" 출력           5
		 *      5           true            "5 : Hello, World!" 출력           6
		 *      6           true            "6 : Hello, World!" 출력           7
		 *      7           true            "7 : Hello, World!" 출력           8
		 *      8           true            "8 : Hello, World!" 출력           9
		 *      9           true            "9 : Hello, World!" 출력          10
		 *     10           true           "10 : Hello, World!" 출력          11
		 *     11           false            for문을 빠져나감(종료)
		 */
		
		System.out.println("---------------------------------");
		
		int i = 1;
		
		// i값이 1 ~ 10까지 1씩 증가하면서 i값 출력 : 1 2 3 4 5 6 7 8 9 10
		for(i = 1; i <= 10; i++) {
			System.out.print(i + " ");
		}
		System.out.println(); // 줄바꿈
		System.out.println("for문 종료 후의 제어변수 i값 : " + i);
		
		System.out.println("---------------------------------");
		
		// i값이 1 ~ 10까지 2씩 증가하면서 i값 출력 : 1 3 5 7 9
		for(i = 1; i <= 10; i += 2) { // 증감식을 i++ -> i+=2 로 변경
			System.out.print(i + " ");
		}
		System.out.println(); // 줄바꿈
		System.out.println("for문 종료 후의 제어변수 i값 : " + i);
		System.out.println("---------------------------------");
		
		// i값이 2 ~ 10까지 2씩 증가하면서 i값 출력 : 2 4 6 8 10
		for(i = 2; i <= 10; i += 2) {
			System.out.print(i + " ");
		}
		System.out.println(); // 줄바꿈
		System.out.println("for문 종료 후의 제어변수 i값 : " + i);
		System.out.println("---------------------------------");
		
		// i값이 10 ~ 1까지 1씩 감소하면서 i값 출력 : 10 9 8 7 6 5 4 3 2 1
		for(i = 10; i >= 1; i--) {
			System.out.print(i + " ");
		}
		System.out.println(); // 줄바꿈
		System.out.println("for문 종료 후의 제어변수 i값 : " + i);
		
		
		
	}

}



















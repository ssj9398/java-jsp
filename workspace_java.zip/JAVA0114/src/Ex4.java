
public class Ex4 {

	public static void main(String[] args) {
		/*
		 * 반복문을 사용한 연산의 누적
		 * - 연산(합계 등)을 누적할 변수를 하나 선언하여
		 *   반복문 내에서 해당 변수에 특정 연산 결과를 누적하여 적용
		 * - 주의사항!
		 *   누적 변수를 선언하는 위치는 반드시 반복문보다 윗쪽(앞쪽)에 위치해야한다!
		 *   또한, 반드시 초기화 필수!
		 */
		
		// 1 ~ 10까지 합 계산 = 55
		int num = 1;
		int total = 0; // 합계를 누적할 변수(누적 변수)
		
//		total += num; num++;
//		total += num; num++;
//		total += num; num++;
//		total += num; num++;
//		total += num; num++;
//		total += num; num++;
//		total += num; num++;
//		total += num; num++;
//		total += num; num++;
//		total += num; num++;
		
		// num 값을 1 ~ 10까지 1씩 증가하면서 누적변수 total 에 num 값을 더함(누적)
		for(num = 1; num <= 10; num++) {
			total += num;
		}
		
		System.out.println("1 ~ 10까지 합 : " + total);
		System.out.println("현재 num 값 : " + num);
		
		
		
	}

}

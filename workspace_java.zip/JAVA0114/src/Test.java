
public class Test {

	public static void main(String[] args) {
		/*
		 * 등급을 정수형 변수로 관리하여
		 * 해당 등급에 따른 할인 금액을 계산
		 * - 등급 : 1(일반 회원), 2(VIP 회원), 3(VVIP 회원)
		 * - 할인율 : 일반 회원(5%), VIP 회원(15%), VVIP 회원(30%)
		 */
		int grade = 3;
		int pee = 50000;
		
		// if문을 사용하여 등급에 따른 할인율 적용하여 결제 금액 계산 후 출력
//		if(grade == 1) { // 일반 회원
//			System.out.println("일반 회원이므로 5% 할인 적용!");
//			pee *= 0.95;
//		} else if(grade == 2) { // VIP 회원
//			System.out.println("VIP 회원이므로 15% 할인 적용!");
//			pee *= 0.85;
//		} else if(grade == 3) { // VVIP 회원
//			System.out.println("VVIP 회원이므로 30% 할인 적용!");
//			pee *= 0.7;
//		} else {
//			System.out.println("회원 등급 오류!");
//		}
		
		// switch ~ case 문을 사용하여 위와 동일한 작업 수행
		switch (grade) {
			case 1:
				System.out.println("일반 회원이므로 5% 할인 적용!");
				pee *= 0.95;
				break;
			case 2:
				System.out.println("VIP 회원이므로 15% 할인 적용!");
				pee *= 0.85;
				break;
			case 3:
				System.out.println("VVIP 회원이므로 30% 할인 적용!");
				pee *= 0.7;
				break;
			default:
				System.out.println("회원 등급 오류!");
		}
		
		System.out.println("결제 금액 : " + pee + "원");
	}

}

















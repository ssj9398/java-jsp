
public class Test2 {

	public static void main(String[] args) {
		int score = 30; // 점수
		String grade = ""; // 학점
		
//		switch(score / 10) { // switch 문 조건식에 연산식도 활용 가능(결과가 정수이므로)
//			case 10 : //grade = "A"; break; // break 문이 없으므로 case 9 의 문장 실행
//			case 9 : grade = "A"; break; // case 10 과 동일하므로 한 문장으로 처리 가능
//			case 8 : grade = "B"; break;
//			case 7 : grade = "C"; break;
//			case 6 : grade = "D"; break;
//			case 5 : //grade = "F"; break;
//			case 4 : //grade = "F"; break;
//			case 3 : //grade = "F"; break;
//			case 2 : //grade = "F"; break;
//			case 1 : //grade = "F"; break;
//			case 0 : grade = "F"; break; // case 0 ~ 5 까지 한 문장으로 처리 가능
//			default : grade = "점수 입력 오류!";
//		}
		
		// ------------------------------------------------------------------------
		// if문과 switch ~ case 문 조합 가능
		score = 38; // 108 점의 경우 점수 입력 오류가 아닌 A 학점이 출력되므로
		// if문을 사용하여 사전에 정상 점수 범위 판별한 후 true 일 때 switch 문 실행
		if(score >= 0 && score <= 100) { // 정상 점수 범위(0 ~ 100) 판별
			switch(score / 10) { // switch 문 조건식에 연산식도 활용 가능(결과가 정수이므로)
				case 10 : 
				case 9 : grade = "A"; break; 
				case 8 : grade = "B"; break;
				case 7 : grade = "C"; break;
				case 6 : grade = "D"; break;
				default : grade = "F";
			}
			System.out.println(score + "점의 학점 : " + grade);
		} else {
			System.out.println(score + "점 : 점수 입력 오류!");
		}
		
		
	}

}

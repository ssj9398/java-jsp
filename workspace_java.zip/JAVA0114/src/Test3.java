
public class Test3 {

	public static void main(String[] args) {
		/*
		 *  구구단 출력
		 *  정수형 변수 dan 이 2일 경우 구구단 2단 출력
		 *  
		 *  < 2단 >
		 * 2 * 1 = 2 
		 * 2 * 2 = 4
		 * 2 * 3 = 6
		 * 2 * 4 = 8
		 * 2 * 5 = 10
		 * 2 * 6 = 12
		 * 2 * 7 = 14
		 * 2 * 8 = 16
		 * 2 * 9 = 18
		 */
		int dan = 2;
		int i = 1;
		
		System.out.println(" < " + dan + "단 >");
//		System.out.println(dan + " * " + 1 + " = " + (dan * 1));
//		System.out.println(dan + " * " + 2 + " = " + (dan * 2));
//		System.out.println(dan + " * " + 3 + " = " + (dan * 3));
//		System.out.println(dan + " * " + 4 + " = " + (dan * 4));
//		System.out.println(dan + " * " + 5 + " = " + (dan * 5));
//		System.out.println(dan + " * " + 6 + " = " + (dan * 6));
//		System.out.println(dan + " * " + 7 + " = " + (dan * 7));
//		System.out.println(dan + " * " + 8 + " = " + (dan * 8));
//		System.out.println(dan + " * " + 9 + " = " + (dan * 9));

//		System.out.println(dan + " * " + i + " = " + (dan * i)); i++;
//		System.out.println(dan + " * " + i + " = " + (dan * i)); i++;
//		System.out.println(dan + " * " + i + " = " + (dan * i)); i++;
//		System.out.println(dan + " * " + i + " = " + (dan * i)); i++;
//		System.out.println(dan + " * " + i + " = " + (dan * i)); i++;
//		System.out.println(dan + " * " + i + " = " + (dan * i)); i++;
//		System.out.println(dan + " * " + i + " = " + (dan * i)); i++;
//		System.out.println(dan + " * " + i + " = " + (dan * i)); i++;
//		System.out.println(dan + " * " + i + " = " + (dan * i)); i++;
		
		// for 문을 사용하여 특정 단에 해당하는 구구단 출력
		dan = 9;
		
		// 구구단 : 특정 단을 1 ~ 9 까지 1씩 증가하면서 계산 수행
		for(i = 1; i <= 9; i++) {
			System.out.println(dan + " * " + i + " = " + (dan * i)); 
		}
		
		System.out.println("for문 종료 후의 제어변수 i값 : " + i);
		
	}

}





















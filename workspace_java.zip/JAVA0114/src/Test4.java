
public class Test4 {

	public static void main(String[] args) {
		// 정수 num 의 값이 1 ~ 10 까지 1씩 증가하면서 합계(total)를 계산
		int total = 0;
		
		for(int num = 1; num <= 10; num++) {
			total += num;
		}
		
		System.out.println("1 ~ 10까지 합 : " + total);
		
		System.out.println("---------------------------");
		
		// 정수 i 의 값이 1 ~ 10 까지 1씩 증가하면서 홀수 합계(oddTotal)를 계산
		int oddTotal = 0; // 홀수 합계를 저장할 변수
		
		for(int i = 1; i <= 10; i++) { // 총 반복 횟수 : 10회
			// i가 홀수일 때만 합계를 누적
			if(i % 2 == 1) {
				// i값이 1, 3, 5, 7, 9 일 때만 실행하는 문장 : 반복 횟수 5회
				System.out.println("홀수 : " + i);
				oddTotal += i;
			}
		}
		
		System.out.println("1 ~ 10 까지 홀수 합 : " + oddTotal);
		
		System.out.println("---------------------------");
		
		// 정수 i 의 값이 1 ~ 10 까지 1씩 증가하면서 짝수 합계(evenTotal)를 계산
		int evenTotal = 0; // 홀수 합계를 저장할 변수
		
		for(int i = 1; i <= 10; i++) { // 총 반복 횟수 : 10회
			if(i % 2 == 0) {
				// i값이 2, 4, 6, 8, 10 일 때만 실행하는 문장 : 반복 횟수 5회
				System.out.println("짝수 : " + i);
				evenTotal += i;
			}
		}
		
		System.out.println("1 ~ 10 까지 짝수 합 : " + evenTotal);
		
		
		
	}

}













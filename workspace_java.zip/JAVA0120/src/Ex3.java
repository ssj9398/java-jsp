
public class Ex3 {

	public static void main(String[] args) {
		/*
		 * 중첩 for문에서 연산의 누적
		 * - 단일 for문에서의 연산 누적과 동작 원리는 동일하나
		 *   연산의 반복 횟수가 더 많아진다.
		 */
		
		// 주사위 2개 조합 경우의 수 출력 후 주사위 2개의 눈금 합계 계산
		int sum = 0;
		
		for(int dice1 = 1; dice1 <= 6; dice1++) { // 주사위1
			
			for(int dice2 = 1; dice2 <= 6; dice2++) { // 주사위2
				
				System.out.println(dice1 + " & " + dice2);
				sum += dice1 + dice2;
				
			}
			
		}
		
		System.out.println("주사위 2개 조합 눈금의 합 : " + sum);
		
		
	}

}

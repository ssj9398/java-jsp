
public class Test {

	public static void main(String[] args) {
		/*
		 * 정수 1 ~ 100 사이에서
		 * 입력받은 두 숫자(num1, num2)의 공배수를 출력하고 합계 계산
		 * ex) num1 = 5, num2 = 10 일 때
		 *     공배수 : 10, 20, 30, 40, 50, 60, 70, 80, 90, 100
		 *     합계 : 550
		 */
		
		// x의 배수란? 어떤 수를 x로 나눈 나머지가 0인 수
		// num1과 num2 의 공배수란? num1 의 배수이면서, num2 의 배수인 수
		// => num1 으로 나눈 나머지가 0이고 num2 로 나눈 나머지도 0인 수
		int num1 = 5, num2 = 10;
		int sum = 0; // 합계를 누적할 변수
		
		for(int i = 1; i <= 100; i++) { // 1 ~ 100 까지 1씩 증가하면서 반복
			if(i % num1 == 0 && i % num2 == 0) { // num1, num2 의 공배수 판별
				System.out.print(i + " ");
				sum += i; // 공배수의 합계 계산
			}
		}
		
		System.out.println();
		System.out.println("합계 : " + sum);
		
		
	}

}

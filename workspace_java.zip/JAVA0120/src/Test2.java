
public class Test2 {

	public static void main(String[] args) {
		/*
		 * 중첩 for문을 사용한 시계의 분(min)침과 초(sec)침 구현
		 * 
		 * < 출력 예시 >
		 * 00분 00초
		 * 00분 01초
		 * 00분 02초
		 * ... 생략 ...
		 * 00분 59초
		 * 01분 00초
		 * 01분 01초
		 * ... 생략 ...
		 * 59분 58초
		 * 59분 59초
		 */
		
		for(int min = 0; min <= 59; min++) {
			
			for(int sec = 0; sec <= 59; sec++) {
//				System.out.println(min + "분 " + sec + "초");
				System.out.printf("%02d분 %02d초\n", min, sec);
			}
			
		}
		
		System.out.println("--------------------------------------");
		
		/*
		 * 중첩 for문을 사용하여 구구단 2단 ~ 9단까지 모두 출력
		 * 
		 * < 출력 결과 >
		 *  < 2단 >
		 * 2 * 1 = 2
		 * 2 * 2 = 4
		 * ...생략...
		 * 2 * 9 = 18
		 * 
		 *  < 3단 >
		 * 3 * 1 = 3
		 * ...생략...
		 * 3 * 9 = 27
		 * 
		 *  < 4단 >
		 * ...생략...
		 * 
		 *  < 9단 >
		 * ...생략...
		 * 9 * 9 = 81
		 * 
		 * ==> 단(바깥쪽 for문 2 ~ 9), 곱해지는 수(안쪽 for문 1 ~ 9)
		 */
		
		for(int dan = 2; dan <= 9; dan++) { // 2단 ~ 9단
			System.out.println(" < " + dan + "단 >");
			
			for(int i = 1; i <= 9; i++) { // 1 ~ 9
				System.out.println(dan + " * " + i + " = " + (dan * i));
			}
			
			System.out.println();
			
		}
		
		
	}

}



















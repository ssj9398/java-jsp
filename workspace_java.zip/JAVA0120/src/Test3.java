
public class Test3 {

	public static void main(String[] args) {
		/*
		 * 2개의 주사위를 던졌을 때 눈금이 합이 6이 되는 경우의 수 모두 출력
		 */
		for(int dice1 = 1; dice1 <= 6; dice1++) { // 주사위1
			
			for(int dice2 = 1; dice2 <= 6; dice2++) { // 주사위2
				// dice1 과 dice2 의 합이 6일 때만 출력 실행
				if(dice1 + dice2 == 6) {
					System.out.println(dice1 + " + " + dice2 + " = " + (dice1 + dice2));
				}
				
			}
			
		}
		
		/*
		 * 방정식 2x + 4y = 10의 모든 해를 구하시오. 
		 * 단, x와 y는 정수이고 각각의 범위는 0 <= x <= 10, 0 <= y <= 10 이다.
		 */
		for(int x = 0; x <= 10; x++) { // x 범위 0 <= x <= 10 
			
			for(int y = 0; y <= 10; y++) { // y 범위 0 <= y <= 10
				
				if(2 * x + 4 * y == 10) { // 2x + 4y = 10 일 때
					
					System.out.println("x = " + x + ", y = " + y);
					
				}
			}
		}
		
	}

}










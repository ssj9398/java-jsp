
public class Ex2 {

	public static void main(String[] args) {
		/*
		 * 중첩 while문
		 * - while 문 내에 또 다른 while 문을 기술하는 것
		 * 
		 * < 기본 문법 >
		 * 초기식1;
		 * 
		 * while(조건식1) { // 바깥쪽 while 문
		 * 		
		 * 		초기식2; // 바깥쪽 while 문 1번 반복할 때, 안쪽 while 문 초기식 초기화
		 * 
		 *      while(조건식2) {
		 *			// 조건식2 의 판별 결과가 true 일 때 실행할 문장들...
		 *			증감식2;      
		 *      }			
		 * 
		 *		// 안쪽 while 문 반복이 끝난 후 바깥쪽 while 문 제어변수를 증감시킴			
		 * 		증감식1;
		 * }
		 * 
		 */
		
		// i가 1 ~ 3 까지 반복할 동안 i 반복 1회 당 j가 1 ~ 5까지 반복
		int i = 1;
		
		while(i <= 3) {
			System.out.println("i = " + i);
			
			int j = 1;
			
			while(j <= 5) {
				System.out.println("----------------- j = " + j);
				j++;
			}
			
			i++;
		}
		
		
		
	}

}






















public class Ex3 {

	public static void main(String[] args) {
		/*
		 * do ~ while 문
		 * - while 문과 달리 일단 문장을 한 번 실행한 후
		 *   반복문의 마지막에서 조건식을 판별하는 while 문
		 * - while 문은 조건식 판별 결과에 따라 문장이 단 한 번도 실행되지 않을 수 있지만,
		 *   do ~ while 문은 조건식 판별 여부와 관계없이 문장이 무조건 한 번은 실행됨
		 *   
		 * < 기본 문법 >
		 * 초기식;
		 * 
		 * do {
		 * 		// 반복 실행할 문장들...
		 * 		증감식;
		 * } while(조건식); // 주의!! 마지막에 세미콜론(;) 필수!
		 * 
		 */
		
		int num = 5;
		
		// while 문을 사용할 경우
		while(num < 3) { // num 이 5일 때 조건식 결과가 false 이므로 반복문 실행 X
			System.out.println("while 문 : " + num);
			num++;
		}
		
		// do ~ while 문을 사용할 경우
		num = 5;
		
		do { // 무조건 반복문을 실행
			System.out.println("do ~ while 문 : " + num);
			num++;
		} while(num < 3); // 반복문 실행 후 조건식 판별
		// => num 이 5일 때 조건식 판별 결과가 false 라 하더라도
		//    조건식 판별 전에 이미 한 번은 반복문이 실행된 후 조건을 판별함
		
		
	}

}
















public class Ex4 {

	public static void main(String[] args) {
		/*
		 * break 문 vs continue 문
		 * - 반복문을 종료하거나 문장 실행을 생략하는데 사용되는 제어문
		 * 
		 * 1. break 문
		 * - 현재 실행 중인 반복문을 종료하고 중괄호{} 를 빠져나가는 문
		 * - 주로 반복문 내에서 if문을 통해 조건 판별 후 반복을 종료할 때 조합하여 사용
		 * 
		 * 2. continue 문
		 * - 현재 실행 중인 반복문 내에서 continue 문 아래쪽에 위치하는 
		 *   모든 문장의 실행을 생략하고 다음 반복을 진행하는 제어문
		 * - 주로 반복문 내에서 특정 문장 실행을 생략할 때 사용
		 */
		
		// 1 ~ 100 까지 합계를 누적
		// 단, 합계(sum) 가 100을 초과할 때 누적을 중단한 후, i값 출력
		int sum = 0;
		int i;
		
		for(i = 1; i <= 100; i++) {
			System.out.print(i + " ");
			sum += i;
			
			if(sum > 100) { // 합계(sum) 가 100을 초과할 경우
				break; // for문을 종료하고 for문 아래쪽 실행문으로 빠져나감
			}
		}
		
		// break 문을 만나면 실행할 문장 위치
		System.out.println();
		System.out.println("합계 : " + sum);
		System.out.println("1 ~ 100 까지 합계 누적 중 100을 초과할 때 i값 : " + i);
		
		System.out.println("--------------------------------------------");
		
		sum = 0;
		
		for(i = 1; i <= 10; i++) {
			if(i == 5) {
//				break; // i가 5이면 현재 반복문 종료(1 ~ 4 까지의 합 계산 후 종료)
				continue; // i가 5이면 아래쪽 반복 문장 생략 후 증감식으로 이동
				          // (1 + 2 + 3 + 4 + 6 + 7 + 8 + 9 + 10 합 계산 = 5 제외)
			}
			
			System.out.print(i + " ");
			sum += i;
		}
		System.out.println();
		System.out.println("합계 : " + sum);
		
	}

}


















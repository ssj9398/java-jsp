
public class Ex5 {

	public static void main(String[] args) {
		
		EXIT_FOR_I: // LABEL(레이블) - i에 대한 반복문(for문)에 적용되는 레이블
		for(int i = 1; i < 10; i++) {
//			if(i == 5) {
////				break; // i가 5일 때 바깥쪽 for문을 빠져나감
//				continue; // i가 5일 때 아래쪽 문장을 생략하고, 다음 반복 i++ 로 이동
//			}
			
			System.out.println("i = " + i);
			
			EXIT_FOR_J: // LABEL(레이블) - j에 대한 반복문(for문)에 적용되는 레이블
			for(int j = 1; j < 10; j++) {
//				if(i == 5) {
////					break; // i가 5일 때 안쪽 for문을 빠져나감
//					continue; // i가 5일 때 아래쪽 문장을 생략하고, 다음 반복 j++ 로 이동
//				}
				
				if(j == 5) {
//					break; // j가 5일 때 안쪽 for문을 빠져나감(j가 1 ~ 4 일 때만 실행)
//					continue; // j가 5일 때 출력을 생략함(j가 1 ~ 4, 6 ~ 9 일 때 실행)
					
					// 레이블을 적용한 break 와 continue
//					break EXIT_FOR_I; // 레이블이 적용된 바깥쪽 for문을 빠져나감
					continue EXIT_FOR_I; // 레이블이 적용된 바깥쪽 for문 다음 반복 실행
				}
				
				System.out.println("-------------- j = " + j);
			}
			
			System.out.println("안쪽 for문 종료!");
		}
		
		System.out.println("바깥쪽 for문 종료!");
		
	}

}

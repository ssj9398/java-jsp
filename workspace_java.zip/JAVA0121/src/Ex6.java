
public class Ex6 {

	public static void main(String[] args) {
		/*
		 * i = 1 일 때 1 2 3 4 5
		 * i = 2 일 때 1 2 3 4 5
		 * i = 3 일 때 1 2 3 4 5
		 * i = 4 일 때 1 2 3 4 5
		 * i = 5 일 때 1 2 3 4 5
		 */
		for(int i = 1; i <= 5; i++) {
			System.out.print("i = " + i + " 일 때 ");
			
			for(int j = 1; j <= 5; j++) {
				System.out.print(j + " ");
			}
			
			System.out.println();
		}
		
		System.out.println("---------------------");
		
		
		/*
		 * 한 줄에 * 기호 5개씩 5줄 출력
		 *  *****
		 *  *****
		 *  *****
		 *  *****
		 *  ***** 
		 */
		for(int i = 1; i <= 5; i++) {
			
			for(int j = 1; j <= 5; j++) {
				System.out.print("*");
			}
			
			System.out.println();
		}
		System.out.println("---------------------");
		
		/*
		 * i = 1 일 때 1
		 * i = 2 일 때 1 2
		 * i = 3 일 때 1 2 3
		 * i = 4 일 때 1 2 3 4
		 * i = 5 일 때 1 2 3 4 5
		 * => i 값과 j의 종료값(조건)이 같다!
		 *    따라서, j의 조건식에 i값을 사용하면 j의 값을 변화시킬 수 있다!
		 */
		for(int i = 1; i <= 5; i++) {
			System.out.print("i = " + i + " 일 때 ");
			
			for(int j = 1; j <= i; j++) {
				System.out.print(j + " ");
			}
			
			System.out.println();
		}
		
		System.out.println("---------------------");
		
		/*
		 *  다음과 같이 출력
		 *  *
		 *  **
		 *  ***
		 *  ****
		 *  ***** 
		 */
		for(int i = 1; i <= 5; i++) {
			
			for(int j = 1; j <= i; j++) {
				System.out.print("*");
			}
			
			System.out.println();
		}
		
		System.out.println("---------------------");
		
		/*
		 *  다음과 같이 출력
		 *  *****
		 *  ****
		 *  ***
		 *  **
		 *  * 
		 */
//		for(int i = 1; i <= 5; i++) {
//			
//			for(int j = 5; j >= i; j--) {
////				System.out.print(j + " ");
//				System.out.print("*");
//			}
//			
//			System.out.println();
//		}

		for(int i = 5; i >= 1; i--) {
			
			for(int j = 1; j <= i; j++) {
//				System.out.print(j + " ");
				System.out.print("*");
			}
			
			System.out.println();
		}
		
	}

}












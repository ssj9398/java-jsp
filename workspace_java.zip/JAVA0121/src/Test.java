
public class Test {

	public static void main(String[] args) {
		// while 문을 사용하여 구구단의 특정 단을 출력
		int dan = 2;
		
		int i = 1; // 초기식
		
		System.out.println(" < " + dan + "단 >");
		
		while(i <= 9) { // 조건식
			System.out.println(dan + " * " + i + " = " + (dan * i));
			i++; // 증감식
		}
		
		System.out.println("---------------------------------");
		
		// while 문과 if문을 조합하여 1 ~ 10 까지 짝수의 합, 홀수의 합을 계산하여 출력
		int oddTotal = 0; // 홀수 합(25)
		int evenTotal = 0; // 짝수 합(30)
		
		i = 1;
		
		while(i <= 10) {
			if(i % 2 == 1) { // 홀수
				oddTotal += i; // 홀수 누적
			} else { // 짝수
				evenTotal += i; // 짝수 누적
			}
			
			i++;
		}
		
		System.out.println("1 ~ 10 까지 홀수 합 : " + oddTotal);
		System.out.println("1 ~ 10 까지 짝수 합 : " + evenTotal);
		
		
		
		
	}

}






















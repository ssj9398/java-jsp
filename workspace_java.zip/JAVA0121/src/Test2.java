
public class Test2 {

	public static void main(String[] args) {
		// 중첩 while 문을 사용한 구구단 출력(2단 ~ 9단)
		int dan = 2;
		
		while(dan <= 9) {
			System.out.println(" < " + dan + "단 >");
			
			int i = 1;
			
			while(i <= 9) {
				System.out.println(dan + " * " + i + " = " + (dan * i));
				i++;
			}
			
			dan++;
			System.out.println(); // 줄바꿈
		}
		
		
	}

}

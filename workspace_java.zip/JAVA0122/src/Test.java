
public class Test {

	public static void main(String[] args) {
		// 정수 10개를 저장하는 배열 arr 생성하고
		// 1 ~ 10 까지 초기화 한 후 출력
		int[] arr = new int[10];
		arr[0] = 1; arr[1] = 2; arr[2] = 3; arr[3] = 4; arr[4] = 5; 
		arr[5] = 6; arr[6] = 7; arr[7] = 8; arr[8] = 9; arr[9] = 10; 
		
//		for(int i = 0; i < arr.length; i++) {
//			System.out.println(arr[i]);
//		}
		
		// 배열 10개에 저장된 정수의 합을 계산하여 출력
		int sum = 0 ;
		
		for(int i = 0; i < arr.length; i++) {
			// 모든 정수의 합을 누적
			sum += arr[i]; // i번 배열 데이터를 꺼내서 변수 sum 에 누적
		}
		
		System.out.println("합 : " + sum);
		
		System.out.println("--------------------------------");
		
		/*
		 * 학생 5명의 점수를 배열(score)에 저장하고
		 * 총점(total)과 평균(avg)을 계산하여 점수와 함께 출력
		 * ex) 100, 80, 77, 50, 90 점수를 저장할 경우 출력 결과
		 *     1번 학생 : 100점
		 *     2번 학생 : 80점
		 *     3번 학생 : 77점
		 *     4번 학생 : 50점
		 *     5번 학생 : 90점
		 *     ---------------------
		 *     총점 : 397점
		 *     평균 : 79.4점
		 */
		
		int[] score = {100, 80, 77, 50, 90};
		int total = 0;
		double avg = 0;
		
//		for(int i = 0; i < score.length; i++) {
//			System.out.println((i + 1) + "번 학생 : " + score[i] + "점"); // 점수 출력
//			total += score[i]; // 합계 누적
//		}
		
		// 학생 5명의 이름을 저장하는 names 배열 생성
		String[] names = {"홍길동", "이순신", "강감찬", "김태희", "정우성"};
		
		for(int i = 0; i < score.length; i++) {
			System.out.println(names[i] + " : " + score[i] + "점"); // 점수 출력
			total += score[i]; // 합계 누적
		}
		
		avg = total / (double)score.length; // 평균 계산(총점 / 인원)
		// => int / int = int 이므로 피연산자를 double 타입으로 형변환 필요
		
		System.out.println("----------------");
		System.out.println("총점 : " + total + "점");
		System.out.println("평균 : " + avg + "점");
		
	}

}













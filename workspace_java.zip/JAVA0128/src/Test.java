
public class Test {

	public static void main(String[] args) {
		/*
		 * 학생 이름과 점수를 출력
		 * - 이름 저장할 배열(names) => "홍길동", "이순신", "강감찬", "김태희", "정우성"
		 * - 점수 저장할 배열(score) => 80, 60, 70, 100, 90
		 * 
		 * < 출력 결과 >
		 * 홍길동 : 80점
		 * 이순신 : 60점
		 * 강감찬 : 70점
		 * 김태희 : 100점
		 * 정우성 : 90점
		 */
		
		String[] names = {"홍길동", "이순신", "강감찬", "김태희", "정우성"};
		int[] score = {80, 60, 70, 100, 90};
		
		// names 또는 score 중 아무 변수를 통해 배열명.length 로 배열 크기 활용
		for(int i = 0; i < names.length; i++) {
			System.out.println(names[i] + " : " + score[i] + "점");
		}
		
	}

}




















public class Test2 {

	public static void main(String[] args) {
		/*
		 * 학생 5명의 3과목에 대한 점수 관리
		 * - 2차원 배열 score 생성
		 * - 1차원 배열 names 생성
		 * - 데이터를 다음과 같이 초기화 한 후 출력
		 * - 학생별 총점을 1차원 배열 studentTotal 에 저장 후 출력
		 * - 과목별 총점을 1차원 배열 subjectTotal 에 저장 후 출력
		 * 
		 * < 출력 형태 >
		 *  이름   국어 영어 수학
		 * -----------------------
		 * 홍길동   100   80   60
		 * 이순신    50   50   50
		 * 강감찬    80   77   90
		 * 김태희   100  100  100
		 * 정우성    60   60   60
		 * -----------------------
		 * 학생별 총점
		 * 홍길동 : 240점
		 * 이순신 : 150점
		 * 강감찬 : 247점
		 * 김태희 : 300점
		 * 정우성 : 180점
		 * -----------------------
		 * 과목별 총점
		 * 국어 : 390점
		 * 영어 : 367점
		 * 수학 : 360점
		 */
		
		int[][] score = new int[5][3];
		
		score[0][0] = 100; score[0][1] = 80; score[0][2] = 60;
		score[1][0] = 50; score[1][1] = 50; score[1][2] = 50;
		score[2][0] = 80; score[2][1] = 77; score[2][2] = 90;
		score[3][0] = 100; score[3][1] = 100; score[3][2] = 100;
		score[4][0] = 60; score[4][1] = 60; score[4][2] = 60;
		
		String[] names = {"홍길동", "이순신", "강감찬", "김태희", "정우성"};
		
		
		System.out.println(" 이름  국어  영어  수학");
		System.out.println("-----------------------");
		
		for(int i = 0; i < score.length; i++) { // 행 반복
			// 이름 출력
			System.out.print(names[i]);
			
			for(int j = 0; j < score[i].length; j++) { // 열 반복
				// 점수 출력
//				System.out.print(score[i][j] + " ");
				System.out.printf("  %3d ", score[i][j]);
			}
			System.out.println(); // 줄바꿈
		}
		
		System.out.println("------------------------");
		
		// 학생별 총점을 저장할 1차원 배열 studentTotal 생성
		int[] studentTotal = new int[5];
		
		// 과목별 총점을 저장할 1차원 배열 subjectTotal 생성
		String[] subjectNames = {"국어", "영어", "수학"}; // 과목명
		int[] subjectTotal = new int[3];
		
		/*
		 * 학생별 총점 계산
		 * 홍길동   100(0,0)   80(0,1)   60(0,2) => studentTotal[0] 에 누적
		 * 이순신    50(1,0)   50(1,1)   50(1,2) => studentTotal[1] 에 누적
		 * 강감찬    80(2,0)   77(2,1)   90(2,2) => studentTotal[2] 에 누적
		 * 김태희   100(3,0)  100(3,1)  100(3,2) => studentTotal[3] 에 누적
		 * 정우성    60(4,0)   60(4,1)   60(4,2) => studentTotal[4] 에 누적
		 *           과목[0]   과목[1]   과목[2] 에 누적
		 * => 각 학생의 점수는 studentTotal 의 행번호와 동일한 위치에 누적
		 * => 각 과목의 점수는 subjectTotal 의 열번호와 동일한 위치에 누적
		 */
		
		for(int i = 0; i < score.length; i++) {
			for(int j = 0; j < score[i].length; j++) {
//				System.out.print(i + "," + j + "  => studentTotal[" + i + "] 번에 저장 ");
				// 각 학생별 점수를 1차원 배열 studentTotal 에 누적
				studentTotal[i] += score[i][j];
				
				// 각 과목별 점수를 1차원 배열 subjectTotal 에 누적
				subjectTotal[j] += score[i][j];
			}
			
//			System.out.println();
		}
		
		// 1차원 배열 학생 이름과 학생별 총점 출력
		for(int i = 0; i < studentTotal.length; i++) { // names.length 도 동일함
			System.out.println(names[i] + " : " + studentTotal[i] + "점");
		}
		
		System.out.println("-------------------------");
		// 1차원 배열 과목별 총점 출력
		for(int i = 0; i < subjectTotal.length; i++) {
			System.out.println(subjectNames[i] + " : " + subjectTotal[i] + "점");
		}
		
	}

}
























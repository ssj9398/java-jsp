
public class Ex2 {

	public static void main(String[] args) {
		
	}
	
	

}


public class Test {

	public static void main(String[] args) {
		// hello() 메서드 호출
		// => 파라미터가 없으므로 메서드 호출 시 전달할 값이 없다!
		hello();
		
		// gugudan() 메서드 호출
		gugudan();
		
		System.out.println("-------------------");
		
		// sum() 메서드 호출 후 리턴값을 출력
		int result = sum();
		System.out.println("1 ~ 10 까지의 합 : " + result);
		
		System.out.println("-------------------");
		
		// gugudan2() 메서드 호출하여 구구단 출력 => 파라미터로 출력할 단 전달
		gugudan2(5);
		gugudan2(9);
		
//		for(int i = 2; i <= 9; i++) {
//			gugudan2(i);
//		}
		
		// print() 메서드 호출하여 문자열 출력 => 파라미터로 출력할 문자열 전달
		print("Hello, World!");
			
		System.out.println("-------------------");
		
		// sum2() 메서드를 호출하여 정수 1 ~ x 까지 합 리턴받아 출력 => 파라미터 x 전달
		int x = 100;
		int total = sum2(x);
		System.out.println("1 ~ " + x + " 까지 합 : " + total);
		
		System.out.println("-------------------");
		
		// sum3() 메서드를 호출하여 두 숫자의 합 출력 => 파라미터 정수 2개 전달
		sum3(100, 200);
		
	}
	
	// 메서드 정의 연습
	// "Hello, World!" 문자열을 10번 출력하는 메서드 hello() 정의
	// => 1. 매개변수도 없고, 리턴값도 없는 메서드 형태로 정의
	public static void hello() {
		for(int i = 1; i <= 10; i++) {
			System.out.println("Hello, World!");
		}
	}
	
	// 구구단 2단을 출력하는 메서드 gugudan() 정의
	// => 1. 매개변수도 없고, 리턴값도 없는 메서드 형태로 정의
	public static void gugudan() {
		int dan = 2;
		
		for(int i = 1; i <= 9; i++) {
			System.out.println(dan + " * " + i + " = " + (dan * i));
		}
	}
	
	// -----------------------------------------------------
	
	// 정수 1 ~ 10 까지 합을 계산하여 리턴하는 메서드 sum() 정의
	// => 2. 매개변수는 없고, 리턴값만 있는 메서드
	// 1 ~ 10 까지 합을 계산한 후 리턴해야하므로 정수 타입 int 를 리턴타입으로 명시
	public static int sum() {
		int sum = 0;
		
		for(int i = 1; i <= 10; i++) {
			sum += i;
		}
		
		// 리턴타입이 int 이므로 반드시 return 문 뒤에 int형 변수 또는 리터럴 명시
		return sum;
	}
	
	// --------------------------------------------------------
	// 출력할 단을 전달받아 구구단의 해당 단을 출력하는 메서드 gugudan2() 정의
	// => 3. 매개변수만 있고, 리턴값은 없는 메서드 정의
	public static void gugudan2(int dan) {
		System.out.println(" < " + dan + "단 >");
		for(int i = 1; i <= 9; i++) {
			System.out.println(dan + " * " + i + " = " + (dan * i));
		}
	}
	
	// 출력할 문자열을 전달받아 10번 반복 출력하는 메서드 print() 정의
	public static void print(String str) {
		for(int i = 1; i <= 10; i++) {
			System.out.println(str);
		}
	}
	
	// --------------------------------------------------------
	// 정수 x를 전달받아 1 ~ x 까지의 합을 리턴하는 메서드 sum2() 정의
	// => 4. 매개변수도 있고, 리턴값도 있는 메서드 정의
	public static int sum2(int x) {
		int sum = 0;
		
		for(int i = 1; i <= x; i++) { // 1 ~ x 까지 반복
			sum += i;
		}
		
		return sum;		
	}
	
	// --------------------------------------------------------
	// 정수 num1, num2 2개를 전달받아 두 수의 합을 출력하는 메서드 sum3() 정의
	// => 5. 매개변수가 2개 이상인 메서드(3번 형태로 사용)
	public static void sum3(int num1, int num2) {
		int total = num1 + num2;
		System.out.println(num1 + " + " + num2 + " = " + total);
	}
	
	
}

















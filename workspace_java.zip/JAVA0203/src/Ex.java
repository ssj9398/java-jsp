
public class Ex {

	public static void main(String[] args) {
		/*
		 * 클래스의 객체(인스턴스) 생성 = 인스턴스화
		 * - new 키워드를 사용하여 생성할 인스턴스의 클래스명을 명시
		 * - Heap 공간에 생성된 인스턴스 주소를 저장할 참조변수를 선언하고
		 *   해당 인스턴스 생성 후의 주소값을 저장
		 * - 인스턴스 생성 후에는 참조변수를 통해 인스턴스 접근 가능
		 *   => 변수명.멤버변수명 또는 변수명.메서드명() 의 형태로 접근
		 *   => 단, 자신의 클래스 내의 변수 또는 메서드는 참조변수 없이 바로 접근
		 *   
		 * < 클래스 정의 기본 문법 >
		 * [제한자] class 클래스명 {
		 * 		// 멤버변수(인스턴스변수) 선언
		 * 		// 멤버메서드 정의
		 * }
		 *   
		 * < 인스턴스 생성 기본 문법 >
		 * 클래스명 변수명 = new 클래스명();
		 */
		
//		String name = "홍길동";
//		int age = 20;
//		boolean isHungry = false;
//		System.out.println("이름 : " + name);
//		System.out.println("나이 : " + age);
//		System.out.println("배고픔 : " + isHungry);
		
		// Person 클래스 인스턴스 생성
		Person p = new Person();
		// => Person 인스턴스가 생성된 Heap 공간의 주소를 Person 타입 변수 p 에 저장
		
		// Person 인스턴스의 이름, 나이, 배고픔 값 초기화
		// => 참조변수명.멤버변수명 형태로 접근
		p.name = "홍길동";
		p.age = 20;
		
		// Person 인스턴스의 이름, 나이, 배고픔 값 출력
		System.out.println("이름 : " + p.name);
		System.out.println("나이 : " + p.age);
		System.out.println("배고픔 : " + p.isHungry);
		
		// Person 인스턴스의 메서드 work(), eat() 호출
		p.work();
		System.out.println("배고픔 : " + p.isHungry);
		p.eat();
		System.out.println("배고픔 : " + p.isHungry);
		
		System.out.println("---------------------------------");
		
		// 또 다른 Person 클래스의 인스턴스 생성 => 다른 이름의 변수에 주소값 저장
		Person p2 = new Person();
		// p1 과 클래스명(또는 클래스타입)이 Person 으로 같지만
		// new 를 통해 인스턴스 생성을 각각 수행했으므로, 인스턴스(메모리공간)가 다르다!
		// => 즉, 서로 다른 인스턴스는 각각 다른 정보를 관리할 수 있다!
		p2.name = "이순신";
		p2.age = 44;
		System.out.println("이름 : " + p2.name);
		System.out.println("나이 : " + p2.age);
		System.out.println("배고픔 : " + p2.isHungry);
		// p1 과 p2 에 저장된 정보는 각각 다르다!
		System.out.println("이름 : " + p.name);
		System.out.println("나이 : " + p.age);
		System.out.println("배고픔 : " + p.isHungry);
		
		System.out.println("===========================");
		
		// Animal 인스턴스 2개 생성 후 다음과 같이 초기화 및 출력
		// ------ 인스턴스1(ani1) ------
		// "이름 : 멍멍이, 나이 : 2"
		// "동물 울음 소리"
		// ------ 인스턴스2(ani2) ------
		// 이름 : 야옹이, 나이 : 3 
		// "동물 울음 소리"
		Animal ani1 = new Animal();
		ani1.name = "멍멍이";
		ani1.age = 2;
		System.out.println("이름 : " + ani1.name + ", 나이 : " + ani1.age);
		ani1.cry();
		
		Animal ani2 = new Animal();
		ani2.name = "야옹이";
		ani2.age = 3;
		System.out.println("이름 : " + ani2.name + ", 나이 : " + ani2.age);
		ani2.cry();
		
	}

} // Ex 클래스 끝

// 하나의 java 파일(소스 파일) 내에 여러개의 클래스를 정의할 수 있다.
// => 단, 파일명과 동일한 클래스를 제외한 나머지 클래스는 접근제한자를 빼고 정의한다.

// 동물(Animal) 클래스 정의
// 멤버변수 : 이름(name), 나이(age)
// 메서드 : cry() - 파라미터 X, 리턴값 X, "동물 울음 소리!" 출력
class Animal {
	// 멤버변수(인스턴스변수) 선언
	String name;
	int age;
	
	// 멤버메서드 정의
	public void cry() {
		System.out.println("동물 울음 소리!");
	}
	
}



















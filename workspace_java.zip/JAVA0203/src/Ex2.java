
public class Ex2 {

	public static void main(String[] args) {
		Student s1 = new Student();
		s1.name = "홍길동";
		s1.ban = 1;
		s1.kor = 100;
		s1.eng = 60;
		s1.mat = 80;
		s1.studentInfo();
		
		// getTotal() : 총점을 계산하여 리턴받아 정수형 변수 total 에 저장 후 출력
//		int total = s1.getTotal();
//		System.out.println("총점 : " + total);
		
		// getAverage() : 평균을 계산하여 리턴받아 실수형 변수 avg 에 저장 후 출력
		// => 파라미터로 계산된 총점을 전달
//		double avg = s1.getAverage(total);
//		System.out.println("평균 : " + avg);
		
		System.out.println("---------------------");
		
		Student s2 = new Student();
		s2.name = "이순신";
		s2.ban = 2;
		s2.kor = 77;
		s2.eng = 90;
		s2.mat = 70;
		s2.studentInfo();
//		System.out.println("총점 : " + s2.getTotal());
//		System.out.println("평균 : " + s2.getAverage(s2.getTotal()));
		// => s2.getAverage() 메서드의 파라미터로 s2.getTotal() 메서드를 기술하면
		//    s2.getTotal() 메서드 실행 결과인 총점이 계산된 후 
		//    s2.getAverage() 메서드의 파라미터로 전달되게 됨
		//    따라서, s2.getAverage(237) 의 결과와 동일하게 됨
	}

}

/*
 * 학생(Student) 클래스 정의
 * - 이름(name, 문자열), 반(ban, 정수), 국어(kor, 정수), 영어(eng, 정수), 수학(mat, 정수)
 * - 메서드
 *   1) studentInfo() : 이름, 반, 국어, 영어, 수학 점수 출력
 *   2) getTotal() : 파라미터 X, 리턴타입 int => 국어, 영어, 수학 점수의 합 리턴
 *   3) getAverage() :  
 */
class Student {
	String name;
	int ban;
	int kor;
	int eng;
	int mat;
	
	public void studentInfo() {
		System.out.println("이름 : " + name);
		System.out.println("반 : " + ban);
		System.out.println("국어점수 : " + kor);
		System.out.println("영어점수 : " + eng);
		System.out.println("수학점수 : " + mat);
		// 하나의 클래스 내의 메서드에서 또 다른 메서드 호출도 가능
		// => 멤버변수(인스턴스변수) 접근과 동일한 방법으로 다른 메서드 호출
		//    (자신의 클래스 내의 변수 또는 메서드는 참조변수 없이 바로 접근)
		System.out.println("총점 : " + getTotal());
		System.out.println("평균 : " + getAverage(getTotal()));
	}
	
	// 총점 계산
	public int getTotal() {
//		int total = kor + eng + mat;
//		return total;
		return kor + eng + mat;
	}
	
	// 평균 계산
	public double getAverage(int total) {
		return total / 3.0;
	}
	
}



















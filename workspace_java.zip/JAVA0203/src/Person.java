
// Person 클래스 정의
public class Person {
	/*
	 * --- 멤버변수 = 인스턴스변수 ---
	 * => 클래스 내부, 메서드 외부에 선언한 변수
	 * => 해당 클래스 내의 대부분의 메서드에서 공통적으로 사용 가능
	 * 이름(name) - 문자열
	 * 나이(age) - 정수
	 * 배고픔(isHungry) - 논리
	 * 
	 * --- 메서드 ---
	 * 먹는다(eat()) : 파라미터 X, 리턴값 X
	 * 일한다(work()) : 파라미터 X, 리턴값 X
	 */
	// 멤버변수(인스턴스변수) 선언
	String name;
	int age;
	boolean isHungry;
	
	
	// 메서드 정의
	// 1. eat() : 파라미터 X, 리턴값 X, "밥을 먹는다!" 출력, isHungry 변수 false 로 변경
	public void eat() {
		System.out.println("밥을 먹는다!");
		// 인스턴스변수 inHungry 의 값을 false 로 변경
		isHungry = false;
	}
	
	// 2. work() : 파라미터 X, 리턴값 X, "일 한다!" 출력, isHungry 변수 true 로 변경
	public void work() {
		System.out.println("일 한다!");
		isHungry = true;
	}
	
}





















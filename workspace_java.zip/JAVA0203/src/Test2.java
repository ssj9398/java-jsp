
public class Test2 {

	public static void main(String[] args) {
		/*
		 * 은행계좌 개설하여 다음과 같이 초기화 후 출력
		 * 
		 * 계좌번호 : 111-1111-111
		 * 예금주명 : 홍길동
		 * 현재잔고 : 10000원
		 */
		Account acc = new Account();
		acc.accountNo = "111-1111-111";
		acc.ownerName = "홍길동";
		acc.balance = 10000;
//		System.out.println("계좌번호 : " + acc.accountNo);
//		System.out.println("예금주명 : " + acc.ownerName);
//		System.out.println("현재잔고 : " + acc.balance);
		acc.showInfo();
		System.out.println("----------------");
		acc.deposit(5000);
		int myMoney = acc.withdraw(10000);
		System.out.println("출금된 금액 : " + myMoney + "원");
		
		System.out.println("출금된 금액 : " + acc.withdraw(50000) + "원");
		
		System.out.println("===========================");
		
		// 새로운 은행계좌 인스턴스 생성하여 사용해보기
		Account acc2 = new Account();
		acc2.accountNo = "222-2222-222";
		acc2.ownerName = "이순신";
		acc2.balance = 99999;
		acc2.showInfo();
		
		acc2.deposit(100000);
		System.out.println("출금된 금액 : " + acc2.withdraw(50000) + "원");
		System.out.println("출금된 금액 : " + acc.withdraw(5000000) + "원");
	}

}

/*
 * 은행계좌(Account) 클래스
 * - 멤버변수
 *   1. 계좌번호(accountNo) - 문자열("XXX-XXXX-XXX")
 *   2. 예금주명(ownerName) - 문자열("XXX")
 *   3. 현재잔고(balance) - 정수
 *   
 * - 메서드
 *   1. showInfo() 메서드 : 계좌번호, 예금주명, 현재잔고를 출력(파라미터 X, 리턴값 X)
 *   2. deposit() 메서드(파라미터 O, 리턴값 X) : 입금 기능
 *      - 입금할 금액(amount, 정수형)을 파라미터로 전달받아 현재잔고(balance)에 누적
 *      - 입금할 금액과 입금 처리 후의 잔고를 다음과 같이 출력
 *        "입금할 금액 : XXXXX원"
 *        "현재잔고 : XXXXX원"
 *   3. withdraw() 메서드(파라미터 O, 리턴값 O) : 출금 기능
 *      - 출금할 금액(amount, 정수형)을 파라미터로 전달받아 
 *        "출금할 금액 : XXXXX원" 출력
 *      - 출금할 금액과 현재잔고를 비교하여
 *        1) 현재잔고가 출금할 금액보다 작을 경우(balance < amount)
 *           "잔액이 부족하여 출금 불가! (현재잔고 : XXXXX원)" 출력
 *           정수 0 리턴
 *        2) 현재잔고가 출금할 금액과 크거나 같을 경우(balance >= amount)  
 *           현재잔고에서 출금할 금액만큼 차감 후 현재잔고 출력
 *           "현재잔고 : XXXXX원"
 *           출금된 금액을 리턴
 */
class Account {
	String accountNo;
	String ownerName;
	int balance;
	
	public void showInfo() {
		System.out.println("계좌번호 : " + accountNo);
		System.out.println("예금주명 : " + ownerName);
		System.out.println("현재잔고 : " + balance + "원");
	}
	
	public void deposit(int amount) {
		System.out.println("입금 금액 : " + amount + "원");
		// 전달받은 입금금액(amount)을 현재잔고(balance)에 누적
		balance += amount;
		System.out.println("현재잔고 : " + balance + "원");
	}
	
	public int withdraw(int amount) {
		System.out.println("출금할 금액 : " + amount + "원");
		
		// 출금 가능 여부 판별
		// => if문 또는 else 문 수행 시 모든 경우의 수에 따른 리턴 필수!
		if(balance < amount) { // 출금이 불가능한 경우
			System.out.println("잔액이 부족하여 출금 불가! (현재잔고 : " + balance + "원)");
			return 0; // 출금이 불가능하므로 0 리턴
		} else { // 출금이 가능한 경우
			// 입력받은 출금할 금액(amount)만큼 현재잔고(balance)에서 차감 후 금액 리턴
			balance -= amount;
			System.out.println("현재잔고 : " + balance + "원");
			return amount; // 출금이 가능하므로 출금금액만큼 리턴
		}
		
	}
	
}


















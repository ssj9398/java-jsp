
public class Ex {

	public static void main(String[] args) {
		// Car 클래스 인스턴스 생성
		Car car = new Car();
		car.maxSpeed = 200;
		System.out.println("현재속력 : " + car.speed + "km/h, 최대속력 : " + car.maxSpeed + "km/h");
		
		car.speedUp(50);
		car.speedUp(250); // 최대속력이 200km/h 이므로, 300 이 아닌 200으로 고정됨
		car.speedUp(50); // 최대속력이 200km/h 이므로, 250 이 아닌 200으로 고정됨
		
		car.speedDown(100);
		car.speedDown(200);
		
	}

}

/*
 * 자동차(Car) 클래스 정의
 * - 멤버변수
 *   1) 현재속력(speed, 정수형)
 *   2) 최대속력(maxSpeed, 정수형)
 *   
 * - 메서드
 *   1) 속력 증가 : speedUp() 
 *      - 파라미터로 증가할 속력(s) 전달, 리턴값 없음
 *      - 증가할 속력(s)을 전달받아 현재속력(speed)에 누적 및 현재속력을 출력
 *        단, 누적된 속력이 최대 속력(maxSpeed) 보다 클 경우
 *        현재 속력(speed)을 최대 속력(maxSpeed)으로 고정 후 "최대 속력 도달!" 출력
 *        
 *   2) 속력 감소 : speedDown() 
 *      - 파라미터로 감소할 속력(s) 전달, 리턴값 없음
 *      - 증가할 속력(s)을 전달받아 현재속력(speed)에서 차감 및 현재속력을 출력
 *        단, 차감된 속력이 0 보다 작을 경우
 *        현재 속력(speed)을 0 으로 고정 후 "차량 정지!" 출력   
 */

class Car {
	int speed; // 현재 속력
	int maxSpeed; // 최대 속력
	
	// 속력 증가
	public void speedUp(int s) {
		// 전달받은 속력을 현재속력에 누적
		speed += s;
		// 최대 속력 도달 여부 판별
		if(speed >= maxSpeed) {
			System.out.println("최대속력 도달!");
			speed = maxSpeed; // 현재속력을 최대속력으로 고정
		}
		
		System.out.println("현재속력 : " + speed + "km/h");
		
	}
	
	// 속력 감소
	public void speedDown(int s) {
		// 전달받은 속력만큼 현재속력에서 차감
		speed -= s;
		// 최저 속력(0) 도달 여부 판별
		if(speed <= 0) {
			System.out.println("차량 정지!");
			speed = 0; // 현재속력을 0으로 고정
		}
		
		System.out.println("현재속력 : " + speed + "km/h");
		
	}
	
}





















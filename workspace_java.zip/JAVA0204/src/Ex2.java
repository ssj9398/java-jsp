
public class Ex2 {

	public static void main(String[] args) {
		
	}

}

class VariableTypes {
	/*
	 * 변수 선언 위치에 따른 분류
	 * 1. 멤버변수 : 클래스 내부, 메서드 외부에 선언된 변수. 클래스 내에서 접근 가능
	 *    - 인스턴스 멤버 변수 : static 키워드가 없는 멤버변수 
	 *    - 클래스 멤버 변수 : static 키워드가 있는 멤버변수
	 *    => 멤버 변수는 사용 전 초기화를 수행하지 않으면, 자동으로 기본값으로 초기화 됨
	 *    
	 * 2. 로컬변수 : 메서드 내부에 선언된 변수. 해당 메서드 내에서만 접근 가능
	 *    - 로컬 변수 : 메서드 내에서 선언된 변수
	 *    - 파라미터 변수 : 메서드 선언부 파라미터 부분에 선언된 변수
	 *    => 로컬 변수는 반드시 사용 전 초기화 필수!
	 */

	int instanceVariable; // 인스턴스 변수(VariableTypes 클래스 내에서 접근 가능) 
	static int classVariable; // 클래스 변수(VariableTypes 클래스 내에서 접근 가능)
	
	public void m1(int parameterVariable) { // 파라미터 변수(m1() 메서드 내에서 접근 가능)
//		System.out.println(localVariable); // 로컬 변수 선언 전이므로 사용 불가
		
		int localVariable = 10; // 로컬 변수(현재 위치부터 m1() 메서드 내에서 접근 가능)
		int localVariable2; // 로컬 변수(현재 위치부터 m1() 메서드 내에서 접근 가능)
		
		System.out.println(localVariable);
//		System.out.println(localVariable2); // 초기화 되지 않은 로컬 변수는 사용 불가
		
		System.out.println(instanceVariable); // 초기화하지 않아도 인스턴스 변수 접근 가능
		
		for(int i = 0; i < 10; i++) { // 로컬 변수(for문 내에서만 사용 가능)
			System.out.println(i);
		}
		
//		System.out.println(i); // for문 종료 후 로컬변수 i는 제거되므로 접근 불가
		System.out.println(localVariable); // for문 종료 후에도 계속 유지됨
		
	} // m1() 메서드 끝
	
	public void m2() {
		// m1() 메서드와 다른 m2() 메서드 내에서는
		// m1() 메서드에서 선언된 로컬 변수는 존재하지 않으므로 접근이 불가능하며
		// 멤버변수(클래스 변수 또는 인스턴스 변수)에만 접근이 가능하다!
//		System.out.println(localVariable); // 존재하지 않는 변수이므로 접근 불가
		System.out.println(instanceVariable); // 인스턴스 변수 접근 가능
	}
	
}














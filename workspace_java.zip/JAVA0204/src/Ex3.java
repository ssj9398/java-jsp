
public class Ex3 {

	public static void main(String[] args) {
		/*
		 * 접근제한자(= 접근제어자, Access Modifier)
		 * - 클래스, 메서드, 멤버변수 등에 접근을 제어하는 키워드
		 * - public, protected, default(= package), private 4가지
		 * 
		 * 1. public : 누구나 접근 가능하도록 지정(모든 클래스에서 접근 가능)
		 *    => 주로 멤버변수에 접근하여 데이터를 대신 입출력 하는 기능의 메서드에 사용
		 *       = Getter/Setter 메서드
		 *         1) Getter : 멤버변수의 값을 외부로 리턴하는 역할(파라미터 X, 리턴값 O)
		 *                     일반적으로 getXXX() 형태의 이름을 사용(XXX : 멤버변수명)
		 *         2) Setter : 외부로부터 값을 전달받아 멤버변수에 저장하는 역할
		 *                     (파라미터 O, 리턴값 X)
		 *                     일반적으로 setXXX() 형태의 이름을 사용(XXX : 멤버변수명)
		 *       => Getter/Setter 자동 생성 단축키 : Alt + Shift + S -> R 
		 * 
		 * 2. private : 자신의 클래스 내에서만 접근 가능(다른 클래스에서 접근 불가)
		 *    => 주로 멤버변수의 접근을 외부로부터 차단하기 위해 사용  
		 *    
		 * => 이처럼 멤버변수에 private 접근제한자를 사용하여 외부 접근을 차단하고
		 *    별도의 Getter/Setter 메서드를 public 으로 제공하여
		 *    간접적인 데이터 접근을 허용하는 것을 Encapsulation(캡슐화, 은닉) 이라고 함
		 *    (데이터 보호를 위해 Getter/Setter 내에서 부가적인 확인 작업도 가능)
		 */
		Student s = new Student();
		s.name = "홍길동";
		s.score = 90;
		System.out.println("이름 : " + s.name + ", 점수 : " + s.score);
		
		// 점수가 0 ~ 100 사이이지만, int형 변수이므로 그 외의 값을 전달해도
		// 문법적으로는 아무런 문제가 없다! 단, 논리적으로 불가능한 점수
		s.score = -100; // -100점은 존재하지 않지만, 입력 가능한 점수
		// 따라서, 이러한 잘못된 값이 저장되는 것을 방지하기 위해서는
		// 외부에서 함부로 멤버변수에 접근하는 것을 차단해야함
		System.out.println("-----------------------------------------");
		
		Student2 s2 = new Student2();
		s2.name = "이순신";
//		s2.score = 100; // The field Student2.score is not visible
		// => 멤버변수 score 는 private 접근제한자로 지정되어 있으므로
		//    다른 클래스(Ex3) 에서 보이지 않기 때문에, 접근이 불가능하다!
		//    반드시, Student2 클래스 내에서만 접근이 가능한 변수
//		System.out.println(s2.score); 
		
		// Setter(setScore()) 메서드를 호출하여 점수를 저장하고
		// Getter(getScore()) 메서드를 호출하여 점수를 출력
		s2.setScore(100);
		System.out.println(s2.getScore());
		
	}

}

class Student2 {
	String name;
	private int score; // Student2 클래스 내부에서만 접근 가능한 변수
	
	// private 접근제한자로 선언된 멤버변수 score 에 접근하기 위한 Getter/Setter 메서드 정의
	// 1. 멤버변수 score 의 값을 외부로 리턴하는 Getter 메서드 정의
	public int getScore() {
		// 멤버변수 score 는 private 접근제한자가 선언되어 있지만
		// 같은 클래스 내에서는 접근 가능하므로, getScore() 메서드에서 접근 가능하다!
		return score;
	}
	
	// 2. 외부로부터 값을 전달받아 멤버변수 score 에 저장하는 Setter 메서드 정의
	public void setScore(int s) {
		score = s;
	}
	
}

class Student {
	String name;
	int score;
}
























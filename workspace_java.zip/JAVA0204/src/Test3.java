
public class Test3 {

	public static void main(String[] args) {
		Account3 acc = new Account3();
//		acc.accountNo = "111-1111-111";
//		acc.ownerName = "홍길동";
//		acc.balance = 100000;
		// => 값을 저장하기 위해 멤버변수에 직접 접근이 불가능하므로 Setter 메서드 사용
		acc.setAccountNo("111-1111-111");
		acc.setOwnerName("홍길동");
//		acc.setBalance(10000);
		// 잔고를 설정하는 setBalance() 보다는 입금/출금 기능의 메서드를 사용
		acc.deposit(10000);
		
		
//		System.out.println("계좌번호 : " + acc.accountNo);
//		System.out.println("예금주명 : " + acc.ownerName);
//		System.out.println("현재잔고 : " + acc.balance);
		// => 값을 출력하기 위해 멤버변수에 직접 접근이 불가능하므로 Getter 메서드 사용
		System.out.println("계좌번호 : " + acc.getAccountNo());
		System.out.println("예금주명 : " + acc.getOwnerName());
		System.out.println("현재잔고 : " + acc.getBalance());
	}

}

/*
 * 은행계좌(Account3) 클래스 정의
 * 1. 멤버변수
 *    - 계좌번호(acccountNo, 문자열)
 *    - 예금주명(ownerName, 문자열)
 *    - 현재잔고(balance, 정수)
 *  
 * 2. 메서드
 *    - Getter/Setter
 *    
 */
class Account3 {
	private String accountNo;
	private String ownerName;
	private int balance;
	
	// accountNo 변수에 대한 Getter/Setter
	public String getAccountNo() {
		return accountNo;
	}
	
	public void setAccountNo(String newAccountNo) {
		accountNo = newAccountNo;
	}
	
	// ownerName 변수에 대한 Getter/Setter
	public String getOwnerName() {
		return ownerName;
	}
	
	public void setOwnerName(String newOwnerName) {
		ownerName = newOwnerName;
	}
	
	// balance 변수에 대한 Getter/Setter 
	public int getBalance() {
		return balance;
	}
	
//	public void setBalance(int newBalance) {
//		balance = newBalance;
//	}
	
	// setBalance() 메서드 대신 입금/출금 기능의 메서드 정의
	public void deposit(int amount) {
		System.out.println("입금 금액 : " + amount + "원");
		// 전달받은 입금금액(amount)을 현재잔고(balance)에 누적
		balance += amount;
		System.out.println("현재잔고 : " + balance + "원");
	}
	
	public int withdraw(int amount) {
		System.out.println("출금할 금액 : " + amount + "원");
		
		// 출금 가능 여부 판별
		// => if문 또는 else 문 수행 시 모든 경우의 수에 따른 리턴 필수!
		if(balance < amount) { // 출금이 불가능한 경우
			System.out.println("잔액이 부족하여 출금 불가! (현재잔고 : " + balance + "원)");
			return 0; // 출금이 불가능하므로 0 리턴
		} else { // 출금이 가능한 경우
			// 입력받은 출금할 금액(amount)만큼 현재잔고(balance)에서 차감 후 금액 리턴
			balance -= amount;
			System.out.println("현재잔고 : " + balance + "원");
			return amount; // 출금이 가능하므로 출금금액만큼 리턴
		}
		
	}
	
}

// Account4 클래스 정의
// 멤버변수 3개에 대한 Getter/Setter 자동 생성(Alt + Shift + S -> R)
class Account4 {
	private String accountNo;
	private String ownerName;
	private int balance;
	
	public String getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}
	public String getOwnerName() {
		return ownerName;
	}
	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}
	public int getBalance() {
		return balance;
	}
	public void setBalance(int balance) {
		this.balance = balance;
	}
	
	
}












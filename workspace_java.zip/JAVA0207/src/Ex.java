
public class Ex {

	public static void main(String[] args) {
		/*
		 * 메서드 오버로딩(Method Overloding) = 다중 정의
		 * - 동일한 이름의 메서드를 여러개 정의하는 것
		 * - 메서드 이름은 동일하고 파라미터가 서로 달라야 함
		 *   => 파라미터의 타입 또는 갯수가 달라야 함
		 * - 리턴타입은 오버로딩과 무관함(달라도 상관없음)
		 * - 반드시 메서드를 호출하는 시점에서 오버로딩 된 메서드를 구분할 수 있어야함
		 */
		
		int num = -5;
		
		AbsoluteNum an = new AbsoluteNum();
		// 정수 num을 전달받아 절대값을 리턴하는 intAbs() 메서드 호출
		// 메서드 오버로딩을 적용하지 않을 경우
		System.out.println(num + "의 절대값 : " + an.intAbs(num));
		
		// 똑같은 절대값이라 하더라도 파라미터 타입이 다르면 다른 메서드를 호출해야함
		double dNum = -3.14;
		System.out.println(dNum + "의 절대값 : " + an.doubleAbs(dNum));
	
		System.out.println("------------------------------------------");
		
		OverloadingAbsoluteNum oan = new OverloadingAbsoluteNum();
		
		// 메서드 오버로딩을 적용할 경우
		// => 동일한 이름으로 서로 다른 데이터를 구분하여 동일한 작업 처리가 가능
		System.out.println(oan.abs(-5));
		System.out.println(oan.abs(-3.14));
		System.out.println(oan.abs(-20L));
	}

}

class OverloadingAbsoluteNum {
	// int형 파라미터 1개를 전달받는 abs() 메서드
	public int abs(int num) { 
		if(num < 0) {
			System.out.println("num 이 음수이므로 양수로 변환!");
			num = -num;
		}
		
		return num;
	}
	
//	public int abs(int num2) {} // 오류 발생!
	// => 파라미터 타입이 같고, 이름만 다른 것은 오버로딩이 아니다!
	//    (반드시 메서드를 호출하는 시점에 어떤 메서드를 호출해야 하는지 구분되어야함)
	
//	public double abs(int num2) {} // 오류 발생
	// => 리턴타입만 바꾸는 것은 오버로딩이 아니다!
	//    (호출하는 시점과 리턴타입은 아무런 관계가 없다!)
	
	
	// double형 파라미터 1개를 전달받는 abs() 메서드
	public double abs(double num) { 
		if(num < 0) {
			System.out.println("num 이 음수이므로 양수로 변환!");
			num = -num;
		}
		
		return num;
	}
	
	// long형 파라미터 1개를 전달받는 abs() 메서드
	public long abs(long num) { 
		if(num < 0) {
			System.out.println("num 이 음수이므로 양수로 변환!");
			num = -num;
		}
		
		return num;
	}
	
}


class AbsoluteNum {
	// 일반적으로 메서드를 정의할 때 기능이 동일하더라도 파라미터가 다를 경우
	// 별개의 메서드로 정의하여 각각 따로 사용해야한다.
	// => 따라서, 같은 기능이지만 이름이 달라서 혼동을 가져올 수 있다.
	
	// 정수 num을 전달받아 절대값을 리턴하는 intAbs() 메서드 정의
	public int intAbs(int num) {
		if(num < 0) {
			System.out.println("num 이 음수이므로 양수로 변환!");
			num = -num;
		}
		
		return num;
	}

	// 실수 num을 전달받아 절대값을 리턴하는 doubleAbs() 메서드 정의
	public double doubleAbs(double num) {
		if(num < 0) {
			System.out.println("num 이 음수이므로 양수로 변환!");
			num = -num;
		}
		
		return num;
	}
	
	// 만약, long 타입 변수를 전달받아 절대값을 리턴해야할 경우 longAbs() 이름을 사용
	// => 각각 다른 데이터 타입에 대한 메서드를 다 따로 정의해야함
	
}



















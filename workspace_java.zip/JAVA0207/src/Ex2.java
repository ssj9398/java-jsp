
public class Ex2 {

	public static void main(String[] args) {
		OverloadingMethod2 om = new OverloadingMethod2();
		om.print(2, "홍길동"); // "홍길동" 2번 출력
		om.print(2, "홍길동", "이순신"); // "홍길동 & 이순신" 2번 출력
		om.print(3, "홍길동", "이순신", "강감찬"); // "홍길동 & 이순신 & 강감찬" 3번 출력
	}

}

// 파라미터가 다른 메서드 오버로딩
class OverloadingMethod2 {
	public void print(int count, String name1) {
		for(int i = 1; i <= count; i++) {
			System.out.println(name1);
		}
	}
	
	// ----------------------------------------
	public void print(String name1, int count) {
		for(int i = 1; i <= count; i++) {
			System.out.println(name1);
		}
	}
	// ----------------------------------------

	public void print(int count, String name1, String name2) {
		for(int i = 1; i <= count; i++) {
			System.out.println(name1 + " & " + name2);
		}
	}
	
//	public void print(int count, String name2, String name1) {
//		for(int i = 1; i <= count; i++) {
//			System.out.println(name1 + " & " + name2);
//		}
//	}

	public void print(int count, String name1, String name2, String name3) {
		for(int i = 1; i <= count; i++) {
			System.out.println(name1 + " & " + name2 + " & " + name3);
		}
	}
}
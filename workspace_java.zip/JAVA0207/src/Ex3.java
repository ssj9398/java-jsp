
public class Ex3 {

	public static void main(String[] args) {
		/*
		 * 가변 인자(= 비정형 인자, Variable Arguments(VARARGS))
		 * - 메서드의 파라미터를 하나의 인자만 사용하여 전달받는 기능
		 * - 동일한 타입의 파라미터를 0개 ~ 무한대로 전달받아 배열로 관리
		 * - 메서드 파라미터 부분에 데이터타입 뒤에 ... 기호를 붙여서 표현
		 *   ex) public void add(int... nums) {}
		 * - 주의사항! 가변 인자는 마지막 파라미터로 단 한 번만 사용 가능
		 * 
		 */
		NormalArguments na = new NormalArguments();
		na.print("홍길동");
		na.print("홍길동", "이순신");
		na.print("홍길동", "이순신", "강감찬");
//		na.print("홍길동", "이순신", "강감찬", "김태희"); // 파라미터 갯수 불일치로 오류
		System.out.println("--------------------------------------");
		
		// VariableArguments 클래스의 print() 메서드를 호출하여
		// 0개 ~ 무한대까지 문자열을 전달하여 출력
		VariableArguments va = new VariableArguments();
		va.print("ab");
		va.print("ab", "cd");
		va.print("ab", "cd", "e", "f", "g");
		va.print();
	}

}

class VariableArguments {
	// 가변인자(...)를 사용한 메서드 오버로딩
	public void print(String... names) { // String 타입 파라미터를 0 ~ 무한대로 전달받음
		// 가변인자를 사용한 변수 names 는 String 타입 배열 변수로 사용됨
		// 따라서, 배열 접근 방법을 활용하여 배열 내의 모든 요소에 접근
		for(int i = 0; i < names.length; i++) {
			System.out.print(names[i] + " ");
		}
		
		System.out.println();
	}
	
	public void print2(int num, String... names) {} // 다른 파라미터와 조합 가능
	
    // 가변인자가 다른 파라미터보다 앞에 올 수 없다
//	public void print3(String... names, int num) {} // 오류 발생
	
	// 가변인자가 2개 이상 올 수 없다
//	public void print4(int... num, String... names) {} // 오류 발생
}

class NormalArguments {
	// 가변인자를 사용하지 않은 메서드 오버로딩
	// => 동일 타입의 파라미터 갯수가 변할 경우 해당 갯수만큼 메서드 오버로딩 수행 필수
	//    단, 오버로딩 되지 않은 갯수의 파라미터는 사용 불가
	public void print(String name1) {
		System.out.println(name1);
	}
	
	public void print(String name1, String name2) {
		System.out.println(name1 + ", " + name2);
	}
	
	public void print(String name1, String name2, String name3) {
		System.out.println(name1 + ", " + name2 + ", " + name3);
	}
}














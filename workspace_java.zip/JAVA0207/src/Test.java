
public class Test {

	public static void main(String[] args) {
		Sum sum = new Sum();
		System.out.println("두 수의 합 : " + sum.add(10, 20)); // 30
		System.out.println("두 수의 합 : " + sum.add(10.0, 20.0)); // 30.0
		System.out.println("두 수의 합 : " + sum.add(10L, 20L)); // 30
		System.out.println("------------------------------------");
		
		OverloadingTest ot = new OverloadingTest();
		ot.print(5, "Hello, World!"); // "Hello, World" 문자열 2번 반복 출력
		ot.print(3, 10); // 정수 10을 3번 반복 출력
		ot.print(10, 'A'); // 문자 'A' 를 10번 반복 출력
		
	}

}

class OverloadingTest {
	
	public void print(int count, String data) {
		for(int i = 1; i <= count; i++) {
			System.out.println(data);
		}
	}
	
	public void print(int count, int data) {
		for(int i = 1; i <= count; i++) {
			System.out.println(data);
		}
	}
	
	public void print(int count, char data) {
		for(int i = 1; i <= count; i++) {
			System.out.println(data);
		}
	}
	
	
}

class Sum {
	// int형 파라미터 2개를 전달받아 합을 리턴하는 sum() 메서드 정의
	public int add(int num1, int num2) {
		return num1 + num2;
	}

	// long형 파라미터 2개를 전달받아 합을 리턴하는 sum() 메서드 정의
	public long add(long num1, long num2) {
		return num1 + num2;
	}

	// double형 파라미터 2개를 전달받아 합을 리턴하는 sum() 메서드 정의
	public double add(double num1, double num2) {
		return num1 + num2;
	}
}


















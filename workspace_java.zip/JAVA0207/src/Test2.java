
public class Test2 {

	public static void main(String[] args) {
		Calculator c = new Calculator();
		c.cal('+', 2, 3); // 2 + 3 = 5 출력
		c.cal('+', 2, 3, 5); // 2 + 3 + 5 = 10 출력
		c.cal('+', 2, 3, 5, 10); // 2 + 3 + 5 + 10 = 20 출력
		
		c.cal('-', 10, 2); // 10 - 2 = 8 출력
		c.cal('-', 10, 2, 3); // 10 - 2 - 3 = 5 출력
		c.cal('-', 10, 2, 3, 5); // 10 - 2 - 3 - 5 = 20 출력
	}

}

class Calculator {
	// 연산기호(연산자)와 연산에 사용될 데이터 2 ~ 4개를 전달받아 연산 수행
	public void cal(char opr, int num1, int num2) {
//		System.out.println(num1 + " + " + num2 + " = " + (num1 + num2));
//		System.out.printf("%d + %d = %d\n", num1, num2, num1 + num2);
		// 연산자(opr)에 따라 서로 다른 연산을 수행
		if(opr == '+') {
			System.out.printf("%d + %d = %d\n", num1, num2, num1 + num2);
		} else if(opr == '-') {
			System.out.printf("%d - %d = %d\n", num1, num2, num1 - num2);
		}
	}
	
	public void cal(char opr, int num1, int num2, int num3) {
//		System.out.printf("%d + %d + %d = %d\n", num1, num2, num3, num1 + num2 + num3);
		if(opr == '+') {
			System.out.printf("%d + %d + %d = %d\n", num1, num2, num3, num1 + num2 + num3);
		} else if(opr == '-') {
			System.out.printf("%d - %d - %d = %d\n", num1, num2, num3, num1 - num2 - num3);
		}
	}
	
	public void cal(char opr, int num1, int num2, int num3, int num4) {
//		System.out.printf("%d + %d + %d + %d = %d\n", num1, num2, num3, num4, num1 + num2 + num3 + num4);
		if(opr == '+') {
			System.out.printf("%d + %d + %d + %d = %d\n", num1, num2, num3, num4, num1 + num2 + num3 + num4);
		} else if(opr == '-') {
			System.out.printf("%d - %d - %d - %d = %d\n", num1, num2, num3, num4, num1 - num2 - num3 - num4);
		}
	}
	
}























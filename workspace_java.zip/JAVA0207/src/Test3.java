
public class Test3 {

	public static void main(String[] args) {
		// 가변인자를 활용한 계산기
		Calculator3 c = new Calculator3();
		c.cal('+', 2, 3); // 2 + 3 = 5 출력
		c.cal('+', 2, 3, 5); // 2 + 3 + 5 = 10 출력
		c.cal('+', 2, 3, 5, 10); // 2 + 3 + 5 + 10 = 20 출력
		
		c.cal('-', 10, 2); // 10 - 2 = 8 출력
		c.cal('-', 10, 2, 3); // 10 - 2 - 3 = 5 출력
		c.cal('-', 10, 2, 3, 5); // 10 - 2 - 3 - 5 = 20 출력
		
		c.cal('*', 10, 2); // 10 * 2 = 20 출력
		c.cal('*', 10, 2, 3); // 10 * 2 * 3 = 60 출력
		
		c.cal('/', 10, 2); // 10 / 2 = 5 출력
		c.cal('/', 10, 2, 3); // 10 / 2 / 3 = 1 출력
		
		c.cal('+');
//		c.cal('+', 10);
	}

}

class Calculator3 {
	public void cal(char opr, int... nums) {
		// 최소한 피연산자(데이터)가 2개 이상일 때만 연산 수행
		if(nums.length < 2) {
			System.out.println("피연산자가 부족합니다!");
			return;
		}
		
		int total = nums[0]; // 연산을 누적할 변수(배열의 첫번째 숫자를 초기값으로 저장)
		// 다음 연산은 배열의 두번째 숫자부터 시작
		if(opr == '+') {
			System.out.print(nums[0]);
			
			for(int i = 1; i < nums.length; i++) {
				System.out.print(" + " + nums[i]);
				total += nums[i];
			}
		} else if(opr == '-') {
			System.out.print(nums[0]);
			
			for(int i = 1; i < nums.length; i++) {
				System.out.print(" - " + nums[i]);
				total -= nums[i];
			}
		} else if(opr == '*') {
			System.out.print(nums[0]);
			
			for(int i = 1; i < nums.length; i++) {
				System.out.print(" * " + nums[i]);
				total *= nums[i];
			}
		} else if(opr == '/') {
			System.out.print(nums[0]);
			
			for(int i = 1; i < nums.length; i++) {
				System.out.print(" / " + nums[i]);
				total /= nums[i];
			}
		} 
		
		System.out.println(" = " + total);
	}
}
















public class Ex2 {

	public static void main(String[] args) {
		/*
		 * 생성자(Constructor)
		 * - 생성자 메서드 라고도 함
		 * - 객체가 생성될 때 호출되어 멤버변수 초기화나 객체 생성 시 특정 작업을 수행
		 * - 메서드 구조와 유사하나, 리턴타입이 없고, 이름을 클래스명과 동일하게 정의
		 * - 메서드와 마찬가지로 파라미터가 없을 수도 있고, 파라미터가 있을 수도 있다.
		 * - 생성자를 정의하지 않으면, 컴파일러에 의해 기본 생성자가 자동으로 생성됨
		 *   => 하나라도 정의할 경우, 기본 생성자가 자동으로 생성되지 않는다!
		 *      (기본 생성자 : 파라미터가 없고, 구현부의 코드가 아무것도 없음)
		 *   => 생성자는 반드시 최소한 한 개 이상이 존재해야함(자동 생성 기본 생성자 포함)
		 *   
		 * < 생성자 정의 기본 문법 >
		 * [제한자] 클래스명([파라미터...]) {
		 * 		// 객체 생성 시 수행할 작업들...
		 * }
		 */
		
		DefaultPerson dp = new DefaultPerson(); 
		// => DefaultPerson 인스턴스를 생성하면서 파라미터가 없는 생성자를 호출
		//    이 때, 아무 생성자도 정의하지 않으면 자동으로 생성되는 기본생성자가 호출됨
		//    생성자 내에서 수행할 작업이 없으므로 멤버변수 name 에 null 값이 자동 저장됨
		System.out.println("DefaultPerson 의 name = " + dp.name); // null 출력됨
		
		DefaultPerson2 dp2 = new DefaultPerson2(); 
		// => DefaultPerson2 인스턴스를 생성하면서 파라미터가 없는 생성자를 호출
		//    이 때, 생성자 내에서 멤버변수 name 을 "홍길동"으로 초기화했으므로 
		//    멤버변수 값 출력 시 "홍길동" 출력됨
		System.out.println("DefaultPerson2 의 name = " + dp2.name);
		
		
		ParameterPerson pp = new ParameterPerson("홍길동");
		// 생성자를 호출하여 "홍길동" 문자열을 전달한 후 종료되면 다음 문장이 실행됨
		System.out.println("ParameterPerson 의 name = " + pp.name);
		// 이미 파라미터를 전달받는 생성자를 정의했으므로
		// 기본 생성자인 ParameterPerson() 생성자는 자동으로 정의되지 않는다!
//		ParameterPerson pp2 = new ParameterPerson(); // 컴파일에러 발생!
		
		ParameterPerson2 pp2 = new ParameterPerson2("이순신", 44, false);
		System.out.println("ParameterPerson2 의 name = " + pp2.name);
		System.out.println("ParameterPerson2 의 age = " + pp2.age);
		System.out.println("ParameterPerson2 의 isHungry = " + pp2.isHungry);
				
	}

}

class DefaultPerson {
	String name;
	
//	public DefaultPerson() {} // 기본(Default) 생성자
	// => 아무런 생성자도 정의하지 않으면 컴파일러에 의해 자동으로 생성되는 생성자
	// => 파라미터로 아무것도 전달받지 않고, 생성자 호출 시 수행할 작업도 없는 생성자
}

class DefaultPerson2 {
	String name;
	
	public DefaultPerson2() {
		System.out.println("DefaultPerson2() 생성자 호출됨!");
		// 생성자 내에서 멤버변수에 저장될 기본값을 설정할 수 있다!
		name = "홍길동";
	} 
}

class ParameterPerson {
	String name;
	
	// 파라미터로 String 타입 데이터를 전달받아 멤버변수 name 을 초기화하는 생성자 정의
	public ParameterPerson(String newName) {
		System.out.println("ParameterPerson(String) 생성자 호출됨!");
		name = newName;
	}
}

class ParameterPerson2 {
	String name;
	int age;
	boolean isHungry;
	
	// 파라미터로 String, int, boolean 타입 데이터를 전달받아 
	// 멤버변수 name, age, isHungry 초기화하는 생성자 정의
	public ParameterPerson2(String newName, int newAge, boolean newIsHungry) {
		System.out.println("ParameterPerson(String, int, boolean) 생성자 호출됨!");
		name = newName;
		age = newAge;
		isHungry = newIsHungry;
	}
}











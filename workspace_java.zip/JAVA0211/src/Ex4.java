
public class Ex4 {

	public static void main(String[] args) {
		/*
		 * 레퍼런스 this
		 * - 자신의 인스턴스 주소를 저장하는 레퍼런스 변수(참조 변수)
		 * - 자동으로 생성되는 레퍼런스
		 * - 생성자 또는 메서드 내에서 로컬변수와 멤버변수의 이름이 같을 때
		 *   멤버변수를 지정하기 위한 키워드로 사용됨
		 * 
		 * < 기본 문법 >
		 * this.멤버변수명
		 */
		Person4 p = new Person4("홍길동");
		System.out.println(p.name);
	}

}

class Person4 {
	String name;
	
	public Person4(String name) {
		// 메서드(생성자) 내의 로컬변수명과 클래스 내의 멤버변수명이 같을 경우
		// 메서드 내에서 두 변수의 이름을 지정하면 로컬변수를 지정하게 됨
//		name = name; // 로컬변수 name 값을 다시 로컬변수 name 에 저장하는 코드 = 효과X
		this.name = name;
		// => 멤버변수 name(this.name) 에 로컬변수 name(name)의 값을 전달
	}
	
	public void setName(String name) {
//		name = name; // 로컬변수 name 값을 다시 로컬변수 name 에 저장하는 코드 = 효과X
		this.name = name;
		// => 멤버변수 name(this.name) 에 로컬변수 name(name)의 값을 전달
	}
	
}
















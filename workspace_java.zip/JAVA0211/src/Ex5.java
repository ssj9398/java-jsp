
public class Ex5 {

	public static void main(String[] args) {
		/*
		 * 생성자 this()
		 * - 생성자 내에서 자신의 또 다른 생성자를 호출하는 키워드
		 * - 레퍼런스 this 와 동일하게 자신의 인스턴스에 접근하여
		 *   다른 생성자를 호출할 때 사용
		 * - 생성자 오버로딩 시 멤버변수 초기화 코드의 중복을 제거하기 위해 사용
		 *   => 여러 생성자에서 멤버변수를 중복으로 초기화하지 않고,
		 *      하나의 생성자에서만 초기화하고, 나머지 생성자에서는 
		 *      해당 생성자를 호출하여 초기화 할 값만 전달 후 대신 초기화 수행
		 * - 생성자 내의 첫 번째 라인에서 생성자 this() 를 호출해야함
		 *   => 생성자 호출 코드보다 다른 코드가 먼저 실행될 수 없다!
		 *   
		 * < 생성자 this() 호출 기본 문법 >
		 * 생성자 내의 첫번째 라인에서
		 * this(파라미터...);
		 */
		
		MyDate d1 = new MyDate();
		// 기본 생성자를 통해 아무것도 전달하지 않으면 1900/1/1 출력
		System.out.println(d1.year + "/" + d1.month + "/" + d1.day);
		
		MyDate d2 = new MyDate(2020);
		// 생성자에 정수 1개를 전달하면 연도를 초기화하여 2020/1/1 출력
		System.out.println(d2.year + "/" + d2.month + "/" + d2.day);
		
		MyDate d3 = new MyDate(2020, 2);
		// 생성자에 정수 2개를 전달하면 연, 월을 초기화하여 2020/2/1 출력
		System.out.println(d3.year + "/" + d3.month + "/" + d3.day);
		
		MyDate d4 = new MyDate(2020, 2, 11);
		// 생성자에 정수 3개를 전달하면 연, 월, 일을 초기화하여 2020/2/11 출력
		System.out.println(d4.year + "/" + d4.month + "/" + d4.day);
		
	}

}

class MyDate {
	int year;
	int month;
	int day;
	
	public MyDate() {
		this(1900, 1, 1); // 파라미터 3개짜리 생성자(MyDate(int, int, int)) 호출
		// => 반드시 생성자 내의 첫 번째 라인에서 생성자 this() 를 사용해야함!
		System.out.println("MyDate() 생성자 호출됨!");
		
//		this.year = 1900;
//		this.month = 1;
//		this.day = 1;
		
		// 생성자 내에서 다른 코드보다 아래쪽(뒤)에 생성자 this() 가 올 수 없다!
//		this(1900, 1, 1); // 컴파일에러 발생!
		// Constructor call must be the first statement in a constructor
	}
	
	public MyDate(int year) {
		this(year, 1, 1);
		System.out.println("MyDate(int) 생성자 호출됨!");
//		this.year = year;
//		this.month = 1;
//		this.day = 1;
	}
	
	public MyDate(int year, int month) {
		this(year, month, 1);
		System.out.println("MyDate(int, int) 생성자 호출됨!");
//		this.year = year;
//		this.month = month;
//		this.day = 1;
	}
	
	// 전체를 초기화하는 생성자는 그대로 두고, 나머지 생성자만 this() 를 사용
	public MyDate(int year, int month, int day) {
		System.out.println("MyDate(int, int, int) 생성자 호출됨!");
		this.year = year;
		this.month = month;
		this.day = day;
	}
	
	
}




















public class Ex6 {

	public static void main(String[] args) {
		WalkTestBad wtb = new WalkTestBad();
        wtb.walk();
        wtb.walk(150);
        wtb.walk(50, "cm");
        
		WalkTestGood wtg = new WalkTestGood();
		wtg.walk();
		wtg.walk(150);
		wtg.walk(50, "cm");
	}

}

class WalkTestBad {
    public void walk() {
        System.out.println("100cm 이동");
        // walk(int, String) 메서드를 호출하여 100, "cm" 를 전달하면 대신 출력해주므로
        // 출력문에 대한 중복 코드를 제거할 수 있다!
    }
    
    public void walk(int distance) {
        System.out.println(distance + "cm 이동");
        // distance 와 "cm"를 전달하여 대신 출력하면 중복 코드 제거됨
    }
    
    public void walk(int distance, String unit) {
        // 전달받은 단위(unit)에 따라 이동거리 계산 달리해야함
        switch (unit) {
            case "cm": // 기본 단위가 cm 이므로 별도의 거리 계산 필요없음
                break;
            case "inch": // inch 의 경우 기본 길이(distance) * 2.5
//                distance = (int)(distance * 2.5);
                distance *= 2.5;
                break;
            default:
                System.out.println("Unknown unit");
                distance = 0;
        }
        
        System.out.println(distance + "cm 이동");
    }
     
}

class WalkTestGood {
    public void walk() {
    	walk(100, "cm");
    }
    
    public void walk(int distance) {
        walk(distance, "cm");
    }
    
    public void walk(int distance, String unit) {
        // 전달받은 단위(unit)에 따라 이동거리 계산 달리해야함
        switch (unit) {
            case "cm": // 기본 단위가 cm 이므로 별도의 거리 계산 필요없음
                break;
            case "inch": // inch 의 경우 기본 길이(distance) * 2.5
//                distance = (int)(distance * 2.5);
                distance *= 2.5;
                break;
            default:
                System.out.println("Unknown unit");
                distance = 0;
        }
        
        System.out.println(distance + "cm 이동");
    }
     
}

















//package test; 
// => Ex7 클래스는 test 패키지에 소속되어 있지 않으므로 컴파일 에러 발생!
//    현재 위치는 Default package 이므로 아무런 package 도 지정하지 않아야함

import java.util.Date; // java.util 패키지의 Date 클래스를 현재 소스코드에 포함시킴
// => 이 코드가 있을 때는 Date 클래스명 앞에 패키지명을 생략할 수 있다!
import javax.swing.JButton;
import javax.swing.JFrame;
// => 각각 서로 다른 클래스들을 별도로 지정하는 경우에 사용하는 문장

//import javax.swing.*;
// => 특정 패키지 내의 모든 클래스들을 한꺼번에 import 시키는 문장
// => javax.swing 패키지의 클래스만 포함하고, 서브패키지(폴더)는 포함시키지 않는다!

public class Ex7 {

	public static void main(String[] args) {
		/*
		 * package(패키지)
		 * - 윈도우에서의 폴더, 리눅스에서의 디렉토리에 해당하는 개념
		 * - 자바의 클래스 파일들을 모아놓는 공간
		 *   => 서로 다른 패키지에는 같은 이름의 클래스가 각각 존재할 수 있다!
		 *      (같은 이름의 파일이 서로 다른 폴더에 존재하는 것과 동일)
		 * - 자바에서 패키지를 사용하면, 실제 폴더가 패키지로 구분됨
		 * - 특정 클래스 파일은 하나의 패키지에'만' 소속되어야 함
		 * 
		 * package 키워드
		 * - 특정 클래스 파일의 맨 첫 번째 라인에 해당 클래스가 소속된 패키지명을 명시
		 * - 실제 클래스 파일이 위치하는 패키지와 다를 경우 오류 발생
		 * - 소스 코드의 첫번째 라인(주석 제외)에서만 사용 가능한 키워드
		 *   => 클래스 내에서 단 한 번만 사용 가능
		 *   
		 * < package 키워드 사용 기본 문법 >
		 * 소스코드 첫 번째 라인에서
		 * package 패키지명;
		 * 
		 * 
		 * import 키워드
		 * - 원래 클래스에 접근할 때 패키지명.클래스명 형태로 특정 클래스에 접근하거나
		 *   import 문을 사용하여 특정 패키지의 위치를 선언하여 패키지명 지정 생략 가능
		 *   (같은 패키지 내에서는 패키지명을 생략할 수 있다)
		 * - java.lang 패키지는 유일하게 생략이 가능한 패키지
		 *   => 그 외의 모든 패키지는 반드시 위치 정보가 필요함
		 * - import 문 뒤에 패키지명과 클래스명을 지정하면 특정 클래스만 포함시키고,
		 *   패키지명 뒤에 만능문자(*)를 지정하면 해당 패키지 내의 모든 클래스를 포함
		 * - package 문보다 아래쪽, 다른 코드들보다 윗쪽에 명시해야하며
		 *   package 문은 단 한 번만 사용 가능하지만, import 문은 여러번 사용 가능
		 * - 자동 import 단축키 : Ctrl + Shift + O 
		 *   
		 * < import 키워드 사용 기본 문법 >
		 * import 패키지명.클래스명;    또는   import 패키지명.*;
		 */
		
		// java.lang 패키지에 있는 String 클래스를 사용할 경우
		java.lang.String s = "홍길동";
		String s2 = "홍길동"; // java.lang 패키지이므로 패키지명 생략 가능
		
		// java.util 패키지에 있는 Random 클래스의 인스턴스 생성
		java.util.Random r = new java.util.Random();
//		Random r2 = new Random(); // 패키지명을 지정하지 않으면 컴파일 에러 발생!
		
		// java.util 패키지에 있는 Date 클래스의 인스턴스 생성
		Date d = new Date();
		// => 패키지명이 없지만, import 문을 통해 Date 클래스를 포함시켰으므로 오류 X
		
		// javax.swing 패키지에 있는 JFrame 클래스의 인스턴스 생성
		JFrame f = new JFrame();
		// javax.swing 패키지에 있는 JButton 클래스의 인스턴스 생성
		JButton btn = new JButton();
	}

}























public class Ex8 {

	public static void main(String[] args) {
		/*
		 * 기본형 변수와 참조형 변수의 차이
		 * - 기본형(Primitive Type) 변수는 실제 값(리터럴)을 저장하며,
		 *   참조형(Reference Type) 변수는 인스턴스의 주소값(참조값)을 저장
		 * - 변수의 값을 복사할 때
		 *   1) 기본형 : 변수에 저장된 실제 값을 복사(Pass by Value)
		 *      => 복사본과 원본은 아무런 관계가 없으므로
		 *         복사본의 값을 변경해도 원본이 변경되지 않음
		 *   2) 참조형 : 변수에 저장된 인스턴스의 주소 값을 복사(Pass by Reference)
		 *      => 복사본과 원본은 같은 주소값을 가지므로, 같은 인스턴스를 가리킴
		 *         복사본을 통해 인스턴스 값을 변경하면
		 *         원본 인스턴스의 값도 같이 변경됨(변경된 값을 같이 공유함)
		 */
		
		int x = 10;
		int y = x; // 변수 x값을 복사(기본형 변수 복사 = 실제 데이터의 복사)
		System.out.println("x = " + x + ", y = " + y);
		
		x = 99; // 변수 x값을 변경하더라도, 복사된 값을 갖는 y 에 영향 X
		System.out.println("x = " + x + ", y = " + y);
		
		System.out.println("----------------------------");
		
		MyDate d1 = new MyDate(2020, 2, 11);
		System.out.println(d1.year + "/" + d1.month + "/" + d1.day);
		
		MyDate d2 = d1; // 변수 d1 값을 복사(참조형 변수 복사 = 인스턴스 주소의 복사)
		
		d1.year = 1900; 
		// 하나의 인스턴스에서 값을 복사(주소값을 복사)하면
		// 해당 주소를 공유하는(같은 주소를 참조하는) 모든 변수에 영향을 미친다.
		// => 즉, 하나의 참조변수를 통해 값을 바꾸면 다른 참조변수도 동일하게 변경됨
		System.out.println(d1.year + "/" + d1.month + "/" + d1.day);
		System.out.println(d2.year + "/" + d2.month + "/" + d2.day);
		// => d1 인스턴스에서 값을 바꾸면 d2 인스턴스도 동일하게 변경되어있음
		
		System.out.println("===================================");
		
		
		PassValue pv = new PassValue();
		int num = 10;
		pv.changeValue(num); // 파라미터로 기본형 변수 전달 시 값의 복사 일어남
		System.out.println("changeValue() 메서드 호출 후의 num : " + num);
		// => 값의 복사를 통해 값을 변경하는 경우 원본에는 아무런 영향이 없다!
		System.out.println("-------------");
		
		Num refNum = new Num();
		pv.changeReference(refNum); // 파라미터로 참조형 변수 전달 시 주소값의 복사 일어남
		System.out.println("changeReference() 메서드 호출 후의 num : " + refNum.num);
		// => 주소값의 복사를 통해 해당 주소의 변수 값을 변경하는 경우에는
		//    해당 주소를 함께 참조하는 원본에도 영향이 있으므로 원본 값도 변경됨
	}

}

class PassValue {
	
	public void changeValue(int num) { 
		// 기본형(정수)을 전달받기 위해 기본형(int 타입)변수 선언
		num += 999;
		System.out.println("PassValue 의 changeValue() : " + num);
	}
	
	public void changeReference(Num refNum) {
		// 참조형(주소)을 전달받기 위해 참조형(Num 타입) 변수 선언
		refNum.num += 999;
		System.out.println("PassValue 의 changeReference() : " + refNum.num);
	}
	
}

class Num {
	int num = 10;
}















public class Test {

	public static void main(String[] args) {
		/*
		 * Account 클래스 생성 후 다음과 같이 데이터 저장 및 출력
		 * 계좌번호 : 111-1111-111
		 * 예금주명 : 홍길동
		 * 현재잔고 : 10000원
		 */
		Account acc = new Account();
//		acc.accountNo = "111-1111-111";
		acc.setAccountNo("111-1111-111");
		acc.setOwnerName("홍길동");
		acc.setBalance(10000);
		
		System.out.println("계좌번호 : " + acc.getAccountNo());
		System.out.println("예금주명 : " + acc.getOwnerName());
		System.out.println("현재잔고 : " + acc.getBalance() + "원");
		
		// Account 클래스의 showAccountInfo() 메서드를 호출하면
		// 계좌번호, 예금주명, 현재잔고가 출력
		acc.showAccountInfo();
		System.out.println("------------------------------------------");
		System.out.println("출금된 금액 : " + acc.withdraw(5000) + "원");
		
		System.out.println("------------------------------------------");
		System.out.println("출금된 금액 : " + acc.withdraw(50000) + "원");

		System.out.println("------------------------------------------");
		System.out.println("출금된 금액 : " + acc.withdraw('m', 5000000) + "원");
		
	}

}

class Account {
	private String accountNo;
	private String ownerName;
	private int balance;
	
	// Getter/Setter 정의(Alt + Shift + S -> R)
	public String getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}
	public String getOwnerName() {
		return ownerName;
	}
	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}
	public int getBalance() {
		return balance;
	}
	public void setBalance(int balance) {
		this.balance = balance;
	}
	
	public void showAccountInfo() {
		System.out.println("계좌번호 : " + accountNo);
		System.out.println("예금주명 : " + ownerName);
		System.out.println("현재잔고 : " + balance + "원");
	}
	
	// setBalance() 메서드 대신 입금/출금 기능의 메서드 정의
	public void deposit(int amount) {
		System.out.println("입금 금액 : " + amount + "원");
		// 전달받은 입금금액(amount)을 현재잔고(balance)에 누적
		balance += amount;
		System.out.println("현재잔고 : " + balance + "원");
	}
	
	public int withdraw(int amount) {
		System.out.println("출금할 금액 : " + amount + "원");
		
		// 출금 가능 여부 판별
		// => if문 또는 else 문 수행 시 모든 경우의 수에 따른 리턴 필수!
		if(balance < amount) { // 출금이 불가능한 경우
			System.out.println("잔액이 부족하여 출금 불가! (현재잔고 : " + balance + "원)");
			return 0; // 출금이 불가능하므로 0 리턴
		} else { // 출금이 가능한 경우
			// 입력받은 출금할 금액(amount)만큼 현재잔고(balance)에서 차감 후 금액 리턴
			balance -= amount;
			System.out.println("현재잔고 : " + balance + "원");
			return amount; // 출금이 가능하므로 출금금액만큼 리턴
		}
		
	}
	
	/*
	 * 메서드 오버로딩을 활용하여 마이너스 통장 기능을 수행
	 * => withdraw() 메서드에 char 타입(통장 타입), int 타입(출금할 금액)을 전달받아
	 *    char 타입 파라미터가 'm' 일 경우 마이너스 통장이므로
	 *    잔고가 부족하더라도 출금을 수행하도록 정의
	 *    => char 타입 파라미터가 'm' 이 아닐 경우 "통장 타입 오류 발생!" 출력 후 중단
	 */
	public int withdraw(char accountType, int amount) {
		if(accountType == 'm') { // 마이너스 통장
			balance -= amount;
			System.out.println("현재잔고 : " + balance + "원");
			return amount;
		} else {
			System.out.println("통장 타입 오류 발생!");
			return 0;
		}
	}
	
}
















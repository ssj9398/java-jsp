
public class Test2 {

	public static void main(String[] args) {
		Account2 acc = new Account2("111-1111-111", "홍길동", 0);
		System.out.println("계좌번호 : " + acc.getAccountNo());
		System.out.println("예금주명 : " + acc.getOwnerName());
		System.out.println("현재잔고 : " + acc.getBalance());
	}

}

class Account2 {
	private String accountNo;
	private String ownerName;
	private int balance;
	
	// 멤버변수에 저장할 데이터 3개를 파라미터로 전달받아 초기화하는 생성자 정의
	public Account2(String newAccountNo, String newOwnerName, int newBalance) {
		accountNo = newAccountNo;
		ownerName = newOwnerName;
		balance = newBalance;
	}
	
	// Getter/Setter 정의
	public String getAccountNo() {
		return accountNo;
	}
	
	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}
	
	public String getOwnerName() {
		return ownerName;
	}
	
	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}
	
	public int getBalance() {
		return balance;
	}
	
	public void setBalance(int balance) {
		this.balance = balance;
	}
	
}















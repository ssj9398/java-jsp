
public class Test4 {

	public static void main(String[] args) {
		Account4 acc = new Account4();
//		System.out.println("계좌번호 : " + acc.getAccountNo());
//		System.out.println("예금주명 : " + acc.getOwnerName());
//		System.out.println("현재잔고 : " + acc.getBalance());

		Account4 acc2 = new Account4("999-9999-999");
//		System.out.println("계좌번호 : " + acc2.getAccountNo());
//		System.out.println("예금주명 : " + acc2.getOwnerName());
//		System.out.println("현재잔고 : " + acc2.getBalance());
		
		Account4 acc3 = new Account4("999-9999-999", "홍길동");
//		System.out.println("계좌번호 : " + acc3.getAccountNo());
//		System.out.println("예금주명 : " + acc3.getOwnerName());
//		System.out.println("현재잔고 : " + acc3.getBalance());
		
		Account4 acc4 = new Account4("999-9999-999", "홍길동", 100000);
//		System.out.println("계좌번호 : " + acc4.getAccountNo());
//		System.out.println("예금주명 : " + acc4.getOwnerName());
//		System.out.println("현재잔고 : " + acc4.getBalance());
	}

}

class Account4 {
	private String accountNo;
	private String ownerName;
	private int balance;
	
	// Account4() 생성자 정의
	public Account4() {
		System.out.println("Account4() 생성자 호출됨!");
		showAccountInfo();
	}
	
	// Account4(String) 생성자 정의 - 계좌번호(accountNo) 초기화
	public Account4(String accountNo) {
		System.out.println("Account4(String) 생성자 호출됨!");
		this.accountNo = accountNo;
		showAccountInfo();
	}
	
	// Account4(String, String) 생성자 정의 - 계좌번호, 예금주명 초기화
	public Account4(String accountNo, String ownerName) {
		System.out.println("Account4(String, String) 생성자 호출됨!");
		this.accountNo = accountNo;
		this.ownerName = ownerName;
		showAccountInfo();
	}
	
	// Account4(String, String, int) 생성자 정의 - 계좌번호, 예금주명, 현재잔고 초기화
	public Account4(String accountNo, String ownerName, int balance) {
		System.out.println("Account4(String, String, int) 생성자 호출됨!");
		this.accountNo = accountNo;
		this.ownerName = ownerName;
		this.balance = balance;
		showAccountInfo();
	}
	
	
	// Getter/Setter 정의
	public String getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}
	
	public String getOwnerName() {
		return ownerName;
	}
	
	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}
	
	public int getBalance() {
		return balance;
	}
	
	public void setBalance(int balance) {
		this.balance = balance;
	}
	
	public void showAccountInfo() {
		System.out.println("계좌번호 : " + accountNo);
		System.out.println("예금주명 : " + ownerName);
		System.out.println("현재잔고 : " + balance + "원");
	}
	
}

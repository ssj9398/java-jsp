
public class Test5 {

	public static void main(String[] args) {
		Account5 acc = new Account5();
		acc.showAccountInfo();

		Account5 acc2 = new Account5("999-9999-999");
		acc2.showAccountInfo();
		
		Account5 acc3 = new Account5("999-9999-999", "이순신");
		acc3.showAccountInfo();
		
		Account5 acc4 = new Account5("999-9999-999", "이순신", 100000);
		acc4.showAccountInfo();
	}

}

class Account5 {
	private String accountNo; // 기본값 : "111-1111-111"
	private String ownerName; // 기본값 : "홍길동"
	private int balance;      // 기본값 : 0
	
	// Account5() 생성자 정의
	public Account5() {
//		this("111-1111-111", "홍길동", 0);
		System.out.println("Account5() 생성자 호출됨!");
	}
	
	// Account5(String) 생성자 정의 - 계좌번호(accountNo) 초기화
	public Account5(String accountNo) {
		this(accountNo, "홍길동", 0);
		System.out.println("Account5(String) 생성자 호출됨!");
//		this.accountNo = accountNo;
	}
	
	// Account5(String, String) 생성자 정의 - 계좌번호, 예금주명 초기화
	public Account5(String accountNo, String ownerName) {
		this(accountNo, ownerName, 0);
		System.out.println("Account5(String, String) 생성자 호출됨!");
//		this.accountNo = accountNo;
//		this.ownerName = ownerName;
	}
	
	// Account5(String, String, int) 생성자 정의 - 계좌번호, 예금주명, 현재잔고 초기화
	public Account5(String accountNo, String ownerName, int balance) {
		System.out.println("Account5(String, String, int) 생성자 호출됨!");
		this.accountNo = accountNo;
		this.ownerName = ownerName;
		this.balance = balance;
	}
	
	
	// Getter/Setter 정의
	public String getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}
	
	public String getOwnerName() {
		return ownerName;
	}
	
	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}
	
	public int getBalance() {
		return balance;
	}
	
	public void setBalance(int balance) {
		this.balance = balance;
	}
	
	public void showAccountInfo() {
		System.out.println("계좌번호 : " + accountNo);
		System.out.println("예금주명 : " + ownerName);
		System.out.println("현재잔고 : " + balance + "원");
	}
	
}

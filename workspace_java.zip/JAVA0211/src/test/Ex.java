package test;
// 현재 클래스가 소속된 위치(패키지명)가 test 이다.
// => 만약 package test; 문 생략 시 오류 발생!

public class Ex {

}

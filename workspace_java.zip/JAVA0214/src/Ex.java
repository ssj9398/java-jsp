
public class Ex {

	public static void main(String[] args) {
		/*
		 * 상속(Inheritance)
		 * - is-a 관계가 성립하는 객체간의 관계   
		 * - 슈퍼클래스의 모든 멤버를 서브클래스에서 물려받아 선언없이 사용하는 것 
		 * - 슈퍼클래스(Super Class) = 부모 클래스 = 상위 클래스 = 조상 클래스
		 *   서브클래스(Sub Class) = 자식 클래스 = 하위 클래스 = 자손 클래스
		 * - 생성자 및 private 접근 지정자가 선언된 멤버는 상속 대상에서 제외됨
		 * - 자바는 단일 상속만 지원함
		 * - 별도로 상속 대상을 지정하지 않을 경우 Object 클래스를 자동으로 상속받는다.
		 *   => java.lang.Object 클래스는 모든 클래스의 최상위 클래스라고 한다.
		 *   
		 * < 상속 기본 문법 >
		 * class 서브클래스명 extends 슈퍼클래스명 {}
		 */
		
		// 서브클래스의 인스턴스 생성
		Child c = new Child();
		c.childPrn(); // 서브클래스에서 정의한 메서드
		// Child 클래스는 자신의 클래스 내의 멤버뿐만 아니라
		// 슈퍼클래스인 Parent 클래스의 멤버도 선언없이 사용 가능
		c.name = "홍길동"; // 슈퍼클래스로부터 상속받은 멤버변수
		c.parentPrn(); // 슈퍼클래스로부터 상속받은 메서드
		
		// 슈퍼클래스의 인스턴스 생성
		Parent p = new Parent();
		p.parentPrn(); // 슈퍼클래스 자신이 정의한 메서드
//		p.childPrn(); // 서브클래스에서 정의한 메서드 = 접근 불가
		
		System.out.println("----------------------------");
		
		SpiderMan s = new SpiderMan();
		s.eat();
		s.jump();
		s.fireWeb();
		
		System.out.println("---------------------------");
		// GrandFather 클래스로부터 상속받은 Father 클래스를
		// 다시 Son 클래스에서 상속받을 경우 GrandFather 클래스의 멤버에도 접근 가능
		Son son = new Son();
		// Son 클래스 자신이 정의한 멤버
		System.out.println(son.phone);
		son.programmingWell();
		
		// Son 클래스의 슈퍼클래스인 Father 클래스의 멤버
		System.out.println(son.car);
		son.singWell();
		
		// Son 클래스의 슈퍼클래스(Father)의 슈퍼클래스인 GrandFather 클래스의 멤버
		System.out.println(son.house);
		son.drawWell();
		
	}

}

class Parent { // 자동으로 Object 클래스를 상속(extends Object 생략되어 있음)
	String name;
	
	public void parentPrn() {
		System.out.println("슈퍼클래스의 parentPrn()");
	}
}

// Parent 클래스를 상속받는 Child 클래스 정의
class Child extends Parent {
	public void childPrn() {
		System.out.println("서브클래스의 childPrn()");
	}
}

// --------------------------------------------------------
class Person { // 슈퍼클래스
	String name;
	
	public void eat() {
		System.out.println("밥 먹기!");
	}
	
	public void jump() {
		System.out.println("뛰기!");
	}
}

// 슈퍼클래스 Person 을 상속받는 서브클래스 SpiderMan 정의
class SpiderMan extends Person {
	boolean isSpider;
	
	public void fireWeb() {
		System.out.println("거미줄 발사!");
	}
}

// ------------------------------------------------------------------
class GrandFather {
	String house = "이층집";
	
	public void drawWell() {
		System.out.println("그림을 잘 그린다!");
	}
}

class Father extends GrandFather {
	String car = "스포츠카";
	
	public void singWell() {
		System.out.println("노래를 잘 한다!");
	}
}

class Son extends Father {
	String phone = "스마트폰";
	
	public void programmingWell() {
		System.out.println("프로그래밍을 잘 한다!");
	}
}















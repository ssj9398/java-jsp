
public class Ex2 {

	public static void main(String[] args) {
		/*
		 * 상속에서의 생성자
		 * - 생성자는 상속되지 않는다.
		 * - 인스턴스 생성 시, 서브클래스의 인스턴스 생성 전에
		 *   슈퍼클래스의 인스턴스를 먼저 생성한 후 서브클래스의 인스턴스를 생성한다.
		 *   
		 * ex) Employee 클래스 <- Manager 클래스 정의
		 *     1) new Manager() 코드 실행되어 Manager() 생성자로 이동
		 *     2) 슈퍼클래스인 Employee 의 Employee() 생성자 호출하여 이동
		 *     3) Employee 의 슈퍼클래스인 Object 클래스의 생성자 호출하여 이동
		 *     4) Object 인스턴스 생성되고, 생성자 내의 코드 실행
		 *     5) Employee 인스턴스 생성되고, 생성자 내의 코드 실행
		 *     6) Manager 인스턴스 생성되고, 생성자 내의 코드 실행
		 *     
		 */
//		Employee emp = new Employee();
//		Employee emp2 = new Employee("홍길동", 4000);
//		System.out.println(emp2.getEmployee());
		
		// 생성자는 상속되지 않으므로, 기본생성자를 정의하지 않으면 호출 불가
//		Manager man = new Manager(); // 컴파일에러 발생! 기본 생성자 없음
		Manager man2 = new Manager("이순신", 6000, "개발팀");
		System.out.println(man2.getManager());
		
	}

}

class Employee {
	String name; // 사원 이름
	int salary; // 연봉
	
	public Employee() {
		System.out.println("Employee() 생성자 호출됨!");
	}
	
	public Employee(String name, int salary) {
		System.out.println("Employee(String, int) 생성자 호출됨!");
		this.name = name;
		this.salary = salary;
	}
	
	public String getEmployee() {
		return name + ", " + salary;
	}
	
}

class Manager extends Employee {
	String depart; // 부서명
	
	public Manager(String name, int salary, String depart) {
		// 서브클래스의 생성자 내에서 가장 먼저 슈퍼클래스의 생성자를 호출한다!
		// => 아무런 지정이 없을 경우 슈퍼클래스의 기본생성자를 자동으로 호출
		// Employee() 생성자 호출
		
		System.out.println("Manager(String, int, String) 생성자 호출됨!");
		// 자신의 클래스 내에서 슈퍼클래스의 멤버에 자유롭게 접근 가능
		this.name = name;
		this.salary = salary;
		this.depart = depart;
	}
	
	public String getManager() {
//		return name + ", " + salary + ", " + depart;
		// name + ", " + salary 를 리턴하는 코드는
		// Employee 클래스의 getEmployee() 메서드에서 이미 수행중인 작업이므로 중복
		// => 따라서, getEmployee() 메서드를 호출하여 중복코드를 제거할 수 있다!
		//    기본 Employee 클래스 내용이 변경되어도 수정 범위가 줄어든다
		//    = 유지보수성이 향상됨
		return getEmployee() + ", " + depart;
	}
	
}
































public class Ex3 {

	public static void main(String[] args) {
		// 같은 패키지 내의 다른 클래스 멤버에 접근
		ParentClass p = new ParentClass();
		p.publicVar = 10;    // public(O)
		p.protectedVar = 10; // protected(O) - 패키지가 같으므로 접근 가능
		p.defaultVar = 10;   // default(O) - 패키지가 같으므로 접근 가능
//		p.privateVar = 10;   // private(X) - 다른 클래스에서 접근 불가
	}

}

class ParentClass {
	// 접근제한자에 따른 접근 범위 차이
	public int publicVar; // 모든 패키지의 모든 클래스에서 접근 가능(= 누구나 접근 가능)
	protected int protectedVar; // 같은 패키지 or 패키지 달라도 상속 관계이면 접근 가능
	int defaultVar; // 같은 패키지 내에서 접근 가능
	private int privateVar; // 자신의 클래스에서만 접근 가능(= 다른 클래스에서 접근 불가)
	
	public void useMember() {
		// 자신의 클래스 내의 멤버에 접근 = 모든 접근제한자에 접근 가능
		this.publicVar = 10;    // public(O)
		this.protectedVar = 10; // protected(O)
		this.defaultVar = 10;   // default(O)
		this.privateVar = 10;   // private(O)
	}
	
}

class SamePackageSomeClass {
	
	public void useMember() {
		// 같은 패키지 내의 다른 클래스 멤버에 접근
		ParentClass p = new ParentClass();
		p.publicVar = 10;    // public(O)
		p.protectedVar = 10; // protected(O) - 패키지가 같으므로 접근 가능
		p.defaultVar = 10;   // default(O) - 패키지가 같으므로 접근 가능
//		p.privateVar = 10;   // private(X) - 다른 클래스에서 접근 불가
	}
}















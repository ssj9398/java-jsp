
public class Test {

	public static void main(String[] args) {
		// ItwillBank 인스턴스 생성 및 사용
		ItwillBank ib = new ItwillBank();
		// Account 클래스의 멤버 접근
		ib.accountNo = "111-1111-111";
		ib.ownerName = "홍길동";
		ib.showAccountInfo();
		
		// ItwillBank 클래스의 멤버 접근
		ib.contract("자동차");
	}

}

/*
 * Account 클래스를 상속받는 ItwillBank 클래스 정의
 * - Account 의 기본 기능은 그대로 사용 가능
 * - 멤버변수 추가 : 보험명(insureName, 문자열)
 * - 메서드 추가 : 보험계약(contract())
 *   => 파라미터 : String 타입(insureName, 보험명)
 *      리턴타입 : void
 *   => 전달받은 보험명을 변수에 저장 후 "XXX 보험 가입 완료!" 출력
 */
class ItwillBank extends Account {
	String insureName;
	
	public void contract(String insureName) {
		this.insureName = insureName;
		System.out.println(this.insureName + " 보험 가입 완료!");
	}
}

class Account {
	String accountNo;
	String ownerName;
	int balance;
	
	public void showAccountInfo() {
		System.out.println("계좌번호 : " + accountNo);
		System.out.println("예금주명 : " + ownerName);
		System.out.println("현재잔고 : " + balance + "원");
	}
	
	// setBalance() 메서드 대신 입금/출금 기능의 메서드 정의
	public void deposit(int amount) {
		System.out.println("입금 금액 : " + amount + "원");
		// 전달받은 입금금액(amount)을 현재잔고(balance)에 누적
		balance += amount;
		System.out.println("현재잔고 : " + balance + "원");
	}
	
	public int withdraw(int amount) {
		System.out.println("출금할 금액 : " + amount + "원");
		
		// 출금 가능 여부 판별
		// => if문 또는 else 문 수행 시 모든 경우의 수에 따른 리턴 필수!
		if(balance < amount) { // 출금이 불가능한 경우
			System.out.println("잔액이 부족하여 출금 불가! (현재잔고 : " + balance + "원)");
			return 0; // 출금이 불가능하므로 0 리턴
		} else { // 출금이 가능한 경우
			// 입력받은 출금할 금액(amount)만큼 현재잔고(balance)에서 차감 후 금액 리턴
			balance -= amount;
			System.out.println("현재잔고 : " + balance + "원");
			return amount; // 출금이 가능하므로 출금금액만큼 리턴
		}
		
	}
	
}





















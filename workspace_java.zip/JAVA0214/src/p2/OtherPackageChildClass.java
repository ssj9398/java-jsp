package p2;

import p1.ParentClass;

public class OtherPackageChildClass extends ParentClass {
	// 다른 패키지이고, 상속 관계에 있는 서브클래스에서의 접근 범위
	public void useMember() {
		// 상속 관계이므로 슈퍼클래스의 멤버에 직접 접근 가능
		publicVar = 10;    // public(O)
		protectedVar = 10; // protected(O) - 패키지는 다르지만, 상속관계이므로 접근 가능
//		defaultVar = 10;   // default(X) - 다른 패키지에서 접근 불가
//		privateVar = 10;   // private(X) - 다른 클래스에서 접근 불가
	}
}

package p2;

import p1.ParentClass;

public class OtherPackageSomeClass {
	public void useMember() {
		// 같은 패키지 내의 다른 클래스 멤버에 접근
		ParentClass p = new ParentClass();
		p.publicVar = 10;    // public(O)
//		p.protectedVar = 10; // protected(X) - 패키지가 다르고, 상속 관계가 아니므로 접근 불가
//		p.defaultVar = 10;   // default(X) - 다른 패키지에서 접근 불가
//		p.privateVar = 10;   // private(X) - 다른 클래스에서 접근 불가
	}
}

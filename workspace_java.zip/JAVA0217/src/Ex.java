
public class Ex {

	public static void main(String[] args) {
		/*
		 * 메서드 오버라이딩(Overriding) = 메서드 재정의
		 * - 슈퍼클래스로부터 상속받은 메서드와 시그니쳐(이름, 파라미터 등)가
		 *   완벽하게 동일한 메서드를 새롭게 재정의하는 것
		 *   => 기존의 부모의 메서드를 자식이 새롭게 수정하는 것
		 * - 오버라이딩 후, 슈퍼클래스의 메서드는 은닉되어 보이지 않는다.
		 * - 오버라이딩 규칙
		 *   1) 상속이 전제되어야 함
		 *   2) 메서드 시그니쳐(이름, 파라미터 타입 및 갯수, 리턴타입)가 동일해야함
		 *   3) 접근제한자는 슈퍼클래스의 메서드와 같거나 넓어야 함(확대만 가능)
		 *      (=> 좁은  private < default < protected < public  넓은
		 *      ex) 슈퍼클래스 메서드가 public 이면, 오버라이딩 메서드는 public 만 가능
		 *   4) 예외클래스 사용 범위는 축소만 가능함
		 *   5) private, static, final 키워드가 사용된 메서드는 오버라이딩 불가 
		 * 
		 */
		
		Child c = new Child();
		c.childPrn();
		c.parentPrn(); // Child 클래스에서 오버라이딩 된 parentPrn() 메서드가 호출됨
		// => Parent 클래스의 parentPrn() 메서드는 은닉되어 보이지 않는다!
		
		System.out.println("--------------------------");
		
		Dog dog = new Dog();
		dog.cry();
		
		Cat cat = new Cat();
		cat.cry();
		
		System.out.println("--------------------------");
		
		SpiderMan s = new SpiderMan();
		s.isSpider = true;
		s.jump();
		
		s.isSpider = false;
		s.jump();
		
	}

}

class Parent {
	public void parentPrn() {
		System.out.println("슈퍼클래스의 parentPrn()");
	}
}

class Child extends Parent {
	public void childPrn() {
		System.out.println("서브클래스의 childPrn()");
	}
	
	// 슈퍼클래스인 Parent 클래스의 parentPrn() 메서드에 대한 오버라이딩 수행
	// => 선언부가 같고 구현부 코드(메서드 수행 내용)가 다른 메서드 재정의
	// => 슈퍼클래스의 메서드와 호출 형태가 완전히 동일하므로 
	//    슈퍼클래스의 메서드는 은닉되고, 서브클래스의 메서드가 호출됨
//	public void parentPrn() {
//		System.out.println("서브클래스에서 오버라이딩 된 parentPrn()");
//	}
	
	// 오버라이딩 자동 생성 단축키 : Alt + Shift + S -> V
	@Override
	public void parentPrn() {
		System.out.println("서브클래스에서 오버라이딩 된 parentPrn()");
	}
	
	
}

// --------------------------------------
class Animal {
	String name;
	int age;
	
	public void cry() {
		System.out.println("동물 울음 소리!");
	}
}

// Animal 클래스를 상속받는 Dog, Cat 클래스 정의
// => cry() 메서드 오버라이딩 
//    - Dog 클래스 : "강아지는 멍멍" 출력, Cat 클래스 : "고양이는 야옹" 출력
class Dog extends Animal {
	public void cry() {
		System.out.println("강아지는 멍멍!");
	}
}

class Cat extends Animal {
	public void cry() {
		System.out.println("고양이는 야옹!");
	}
}

// -----------------------------------------------------

class Person {
	String name;
	
	public void eat() {
		System.out.println("먹기!");
	}
	
	public void jump() {
		System.out.println("뛰기!");
	}
}

class Spider {
	public void jump() {
		System.out.println("Spider 의 엄청난 점프!");
	}
	
	public void fireWeb() {
		System.out.println("거미줄 발사!");
	}
}

class SpiderMan extends Person {
	boolean isSpider;
	
	Spider spider = new Spider();
	
	// Person 클래스의 jump() 메서드 오버라이딩
	public void jump() {
		// isSpider 가 true 일 경우 Spider 클래스의 jump() 메서드 호출
		// isSpider 가 false 일 경우 "점프" 출력
		if(isSpider) { // isSpider == true 와 동일(!isSpider 는 isSpider == false 와 동일)
			spider.jump();
		} else {
			System.out.println("Person 의 점프!");
		}
	}
	
}









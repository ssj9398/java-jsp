
public class Ex2 {

	public static void main(String[] args) {
		/*
		 * 레퍼런스 super
		 * - 슈퍼클래스의 인스턴스 주소를 담는 참조변수(자동 생성)
		 * - 사용법은 레퍼런스 this 와 동일
		 * - 은닉된 멤버(변수 또는 메서드)에 접근할 때 사용
		 *   => 오버라이딩 시 슈퍼클래스의 멤버변수 또는 메서드가 보이지 않을 때
		 *      슈퍼클래스의 멤버에 접근하는 키워드
		 * - 단, 접근 범위는 1촌(부모)까지만 가능
		 *      
		 * < 기본 문법 >
		 * super.멤버변수 또는 super.메서드()
		 * 
		 */
		Child2 c = new Child2();
		c.watchTv();
		
		System.out.println("---------------");
		
		Child2_2 c2 = new Child2_2();
		c2.method();
	}

}

class Parent2 {
	String tv = "부모님 TV";
	
	public void watchTv() {
		System.out.println("Parent2 의 " + tv + " 시청!");
	}
}

class Child2 extends Parent2 {
	// 메서드뿐만 아니라 멤버변수도 오버라이딩과 동일한 작업을 수행 가능
	String tv = "내 TV"; // 슈퍼클래스인 Parent2 의 멤버변수 tv 는 은닉됨 = 은닉 변수
	
	@Override
	public void watchTv() {
//		System.out.println("Child2 의 " + tv + " 시청!");
		
		// 자신의 인스턴스에서 자신의 멤버변수에 접근하기 위해서는 this.멤버 형태로 접근
//		System.out.println("Child2 의 " + this.tv + " 시청!"); // this 생략도 가능
		
		// 슈퍼클래스의 은닉된 멤버에 접근하기 위해서는 super.멤버 형태로 접근
		System.out.println("Child2 의 " + super.tv + " 시청!");
		
//		super.watchTv(); // 슈퍼클래스의 은닉된 메서드 호출
	}
	
}

class Parent2_2 {
	String x = "parent";
}

class Child2_2 extends Parent2_2 {
	String x = "child";
	
	public void method() {
		String x = "method";
		
		System.out.println("x = " + x); // 로컬변수 x 가리킴
		// => 만약, String x = "method"; 코드가 없으면 x 는 this.x 와 동일
		// => 만약, String x = "method"; 와 String x = "child"; 코드가 없으면
		//    x 는 super.x 와 동일
		System.out.println("this.x = " + this.x); // 자신의 인스턴스(멤버) 변수 가리킴
		// => 만약, String x = "child"; 코드가 없으면 this.x 는 super.x 와 동일
		System.out.println("super.x = " + super.x); // 슈퍼클래스의 은닉변수 x 가리킴
	}
	
}




















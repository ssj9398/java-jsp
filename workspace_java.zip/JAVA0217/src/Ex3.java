
public class Ex3 {

	public static void main(String[] args) {
		/*
		 * 생성자 super()
		 * - 슈퍼클래스의 생성자를 명시적으로 호출
		 * - 슈퍼클래스의 멤버변수와 서브클래스의 멤버변수를 동시에 전달받아
		 *   초기화를 수행하려 할 때, 슈퍼클래스의 초기화 코드와 중복되는 경우
		 *   중복을 제거하기 위해 슈퍼클래스의 생성자를 호출하여 대신 초기화를 수행
		 *   => 자신의 멤버변수만 자신이 직접 초기화하여 중복 코드를 제거
		 * - 슈퍼클래스의 생성자 파라미터와 동일한 형태로 호출해야함
		 * - 반드시 생성자의 첫번째 라인에서 호출되어야 함
		 *   => 생성자 this() 와 생성자 super() 는 동시 사용 불가능
		 * - 생성자 내에서 생성자 this() 또는 생성자 super() 호출 코드가 없다면
		 *   컴파일러에 의해 슈퍼클래스의 기본 생성자가 자동으로 호출됨
		 *   => super(); 코드가 첫 줄에 자동으로 추가됨
		 * - 서브클래스 생성자에서 자동으로 슈퍼클래스의 기본 생성자가 호출될 때
		 *   슈퍼클래스에 기본 생성자가 존재하지 않으면 오류 발생!
		 *   => 따라서, 명시적으로 슈퍼클래스의 다른 생성자를 호출하거나
		 *      슈퍼클래스에서 기본 생성자를 정의하도록 해야한다!
		 *   
		 * < 기본 문법 >
		 * 생성자 내에서 super([파라미터...]); 형태로 사용
		 */
		
		Manager man = new Manager("이순신", 4000, "개발팀");
		System.out.println("이름 : " + man.name);
		System.out.println("연봉 : " + man.salary);
		System.out.println("부서 : " + man.depart);
		
	}

}

class Employee {
	String name;
	int salary;
	
	// Employee() 생성자 정의
//	public Employee() {
//		System.out.println("Employee() 생성자 호출됨!");
//		name = "홍길동";
//		salary = 0;
//	}
	
	public Employee() {}

	// Employee(String, int) 생성자 정의
	public Employee(String name, int salary) {
		System.out.println("Employee(String, int) 생성자 호출됨!");
		this.name = name;
		this.salary = salary;
	}
	
}

class Manager extends Employee {
	String depart;
	
	// name, salary, depart 를 전달받아 초기화하는 생성자 Manager() 정의
	public Manager(String name, int salary, String depart) {
		// 생성자 첫 라인에 this() 또는 super() 생성자 호출 코드가 없을 경우
		// 자바 컴파일러에 의해 자동으로 super() 코드가 삽입됨
		// super();
		// => 만약, 슈퍼클래스에서 기본생성자 없이 파라미터 생성자만 정의했을 경우
		//    기본 생성자가 자동 생성되지 않으므로 컴파일에러가 발생하게 된다!
		// => 따라서! 파라미터가 있는 생성자를 명시적으로 호출(super(파라미터...))하거나
		//    또는 기본생성자를 무조건 명시하면 된다!
		
//		this.name = name; // 슈퍼클래스의 Employee(String, int) 생성자와 중복됨
//		this.salary = salary; // 슈퍼클래스의 Employee(String, int) 생성자와 중복됨
		// 슈퍼클래스의 생성자를 호출하여 대신 멤버변수의 초기화 수행을 위해
		// 생성자 super() 를 호출하여 파라미터 전달
		super(name, salary); // 명시적으로 슈퍼클래스의 파라미터 생성자를 호출
		this.depart = depart;
//		super(name, salary); // 컴파일에러 발생! 생성자 내에서 가장 먼저 실행되어야 함
	}
	
}
















public class Test {

	public static void main(String[] args) {
		ItwillBank ib = new ItwillBank();
		ib.showAccountInfo();
		
		System.out.println("출금된 금액 : " + ib.withdraw(99999) + "원");
		System.out.println("--------------------------");
		
		Taxi taxi = new Taxi();
		taxi.speedUp(100);
		taxi.speedDown(100);
		
		Truck truck = new Truck();
		truck.speedUp(100);
		truck.speedDown(100);
	}

}

class Account {
	String accountNo;
	String ownerName;
	int balance;
	
	public void showAccountInfo() {
		System.out.println("계좌번호 : " + accountNo);
		System.out.println("예금주명 : " + ownerName);
		System.out.println("현재잔고 : " + balance + "원");
	}
	
	// setBalance() 메서드 대신 입금/출금 기능의 메서드 정의
	public void deposit(int amount) {
		System.out.println("입금 금액 : " + amount + "원");
		// 전달받은 입금금액(amount)을 현재잔고(balance)에 누적
		balance += amount;
		System.out.println("현재잔고 : " + balance + "원");
	}
	
	public int withdraw(int amount) {
		System.out.println("출금할 금액 : " + amount + "원");
		
		// 출금 가능 여부 판별
		// => if문 또는 else 문 수행 시 모든 경우의 수에 따른 리턴 필수!
		if(balance < amount) { // 출금이 불가능한 경우
			System.out.println("잔액이 부족하여 출금 불가! (현재잔고 : " + balance + "원)");
			return 0; // 출금이 불가능하므로 0 리턴
		} else { // 출금이 가능한 경우
			// 입력받은 출금할 금액(amount)만큼 현재잔고(balance)에서 차감 후 금액 리턴
			balance -= amount;
			System.out.println("현재잔고 : " + balance + "원");
			return amount; // 출금이 가능하므로 출금금액만큼 리턴
		}
		
	}
	
}

// ItwillBank 클래스 정의
// 출금(withdraw()) 메서드 오버라이딩
// => 잔고가 부족해도 무조건 출금을 수행하도록 오버라이딩
class ItwillBank extends Account {
	String insureName;
	
	public int withdraw(int amount) {
		System.out.println("출금할 금액 : " + amount + "원");
		
		balance -= amount;
		System.out.println("현재잔고 : " + balance + "원");
		
		return amount; // 출금이 가능하므로 출금금액만큼 리턴
	}
}

/*
 * 자동차(Car) 클래스 정의
 * - 멤버변수
 *   1) 현재속력(speed, 정수형)
 *   2) 최대속력(maxSpeed, 정수형)
 *   
 * - 메서드
 *   1) 속력 증가 : speedUp() 
 *      - 파라미터로 증가할 속력(s) 전달, 리턴값 없음
 *      - "자동차의 속력 증가" 출력
 *        
 *   2) 속력 감소 : speedDown() 
 *      - 파라미터로 감소할 속력(s) 전달, 리턴값 없음
 *      - "자동차의 속력 감소" 출력  
 *      
 * Taxi 클래스 정의 - Car 클래스를 상속받아 정의
 * - speedUp() 메서드 오버라이딩 : "Taxi 의 속력 증가!" 출력
 * - speedDown() 메서드 오버라이딩 : "Taxi 의 속력 감소!" 출력
 * 
 * Truck 클래스 정의 - Car 클래스를 상속받아 정의
 * - speedUp() 메서드 오버라이딩 : "Truck 의 속력 증가!" 출력
 * - speedDown() 메서드 오버라이딩 : "Truck 의 속력 감소!" 출력
 */

class Car {
	int speed;
	int maxSpeed;
	
	public void speedUp(int speed) {
		System.out.println("자동차 속력 증가!");
	}
	
	public void speedDown(int speed) {
		System.out.println("자동차 속력 감소!");
	}
}

class Taxi extends Car {

	@Override
	public void speedUp(int speed) {
		System.out.println("Taxi 속력 증가!");
	}

	@Override
	public void speedDown(int speed) {
		System.out.println("Taxi 속력 감소!");
	}
	
}

class Truck extends Car {

	@Override
	public void speedUp(int speed) {
		System.out.println("Truck 속력 증가!");
	}

	@Override
	public void speedDown(int speed) {
		System.out.println("Truck 속력 감소!");
	}
	
}














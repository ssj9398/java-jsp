
public class Test3 {

	public static void main(String[] args) {
		SpiderMan3 s = new SpiderMan3("피터파커");
	}

}


class Person2 {
	String name;
	
	Person2(String name) {
//		super(); // Object 클래스의 Object() 기본 생성자 호출(코드가 없어도 암묵적 호출됨)
		this.name = name;
		System.out.println("Person2(String name) 끝");
	}
}

class SpiderMan3 extends Person2 {
	Spider spider;
	boolean isSpider;
	
	public SpiderMan3(String name) {
		this(name, new Spider(), true); // 자신의 다른 생성자 호출
		System.out.println("SpiderMan3(String name) 끝");
	}
	
	public SpiderMan3(String name, Spider spider, boolean isSpider) {
		super(name); // 슈퍼클래스의 생성자 호출
		this.spider = spider;
		this.isSpider = isSpider;
		System.out.println("SpiderMan3(String name, Spider spider, boolean isSpider) 끝");
	}
	
	
	
	
	
}























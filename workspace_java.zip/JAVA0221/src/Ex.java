
public class Ex {

	public static void main(String[] args) {
		/*
		 * instanceof 연산자
		 * - 좌변의 객체(참조변수)가 우변 클래스의 타입인지 판별하는 연산자
		 * - 판별 결과가 true 이면 형변환이 가능한 관계(업캐스팅 또는 다운캐스팅)
		 *        ""     false 이면 절대로 형변환 불가능
		 * 
		 * < 기본 문법 >
		 * if(A instanceof B) {}
		 * => A 는 참조변수, B 는 클래스명
		 * 
		 */
		
		SmartPhone sp = new SmartPhone("갤럭시S9", "010-1111-2222", "안드로이드");
		sp.call();
		sp.sms();
		sp.kakaoTalk();
		
		// sp 는 SmartPhone 입니까? YES
		if(sp instanceof SmartPhone) { 
			System.out.println("sp 는 SmartPhone 이다!");
		}
		
		System.out.println("--------------------------");
		
		// sp 는 HandPhone 입니까? YES
		if(sp instanceof HandPhone) {
			System.out.println("sp 는 HandPhone 이다!");
			System.out.println("그러므로 sp 는 HandPhone 으로 형변환이 가능하다!");
			
			HandPhone hp = sp; // 업캐스팅 = 자동(묵시적) 형변환
			
			System.out.println("sp 는 HandPhone 이 가지는 모든 기능을 포함한다!");
			System.out.println("따라서, 업캐스팅 후에도 HandPhone 의 기능 사용 가능!");
			
			hp.call(); // HandPhone 의 기능인 전화 기능과
			hp.sms();  // 문자 기능을 사용할 수 있으나
//			hp.kakaoTalk(); // SmartPhone 의 기능은 사용을 포기해야한다.
			
		} else {
			System.out.println("sp 는 HandPhone 이 아니다!");
		}
		
		System.out.println("--------------------------");
		
		HandPhone hp = new HandPhone();
		
		// hp 는 SmartPhone 입니까? NO
		if(hp instanceof SmartPhone) {
			System.out.println("hp 는 SmartPhone 이다!");
		} else {
			System.out.println("hp 는 SmartPhone 이 아니다!");
			System.out.println("그러므로 SmartPhone 으로 변환 불가능!");
			System.out.println("hp 는 SmartPhone 이 가진 기능을 모두 다 포함하지 못함!");
		}
		
		System.out.println("---------------------------");
		
		// SmartPhone -> HandPhone 타입으로 업캐스팅
		HandPhone hp2 = new SmartPhone("갤럭시S9", "010-1111-2222", "안드로이드");
		hp2.call(); // HandPhone 의 기능인 전화 기능과
		hp2.sms();  // 문자 기능을 사용할 수 있으나
//		hp2.kakaoTalk(); // SmartPhone 의 기능은 사용을 포기해야한다.
		
		// hp2 는 SmartPhone 입니까?
		if(hp2 instanceof SmartPhone) {
			System.out.println("hp2 는 SmartPhone 이다!");
			System.out.println("그러므로 hp2 는 SmartPhone 으로 형변환이 가능하다!");
			
//			SmartPhone sp2 = hp2; // 자동 형변환 X
			SmartPhone sp2 = (SmartPhone)hp2; // 명시적 형변환 필요
			System.out.println("hp2 는 SmartPhone 이 가지는 모든 기능을 포함한다!");
			
			sp2.call(); // HandPhone 의 기능인 전화 기능과
			sp2.sms();  // 문자 기능을 사용할 수 있으며
			sp2.kakaoTalk(); // SmartPhone 의 기능도 다시 사용 가능하다!
		} else {
			System.out.println("hp2 는 SmartPhone 이 아니다!");
		}
		
		
		System.out.println("===============================");
		
		Child c = new Child();
		
//		Parent p = c;
//		p.parentPrn();
		
		// 형변환을 바로 수행하지 않고, instanceof 연산자를 통해 검사 후 수행
		if(c instanceof Parent) { // c is a Parent? 질문과 동일
			System.out.println("c 는 Parent 이다!");
			Parent p = c;
			p.parentPrn();
		}
		
		Parent p = new Parent();
		
		if(p instanceof Child) {
			System.out.println("p 는 Child 이다!");
		} else {
			System.out.println("p 는 Child 가 아니다!");
		}
		
		
	}

}

class HandPhone {
	String model;
	String number;
	
	public HandPhone() {}

	public HandPhone(String model, String number) {
		this.model = model;
		this.number = number;
	}
	
	public void call() {
		System.out.println("전화 기능!");
	}
	
	public void sms() {
		System.out.println("문자 기능!");
	}

}

class SmartPhone extends HandPhone {
	String osName;

	public SmartPhone(String model, String number, String osName) {
		super(model, number);
		this.osName = osName;
	}
	
	public void kakaoTalk() {
		System.out.println("카톡 기능!");
	}
	
}





class Parent {
	public void parentPrn() {
		System.out.println("슈퍼클래스의 parentPrn()");
	}
}

class Child extends Parent {
	public void childPrn() {
		System.out.println("서브클래스의 childPrn()");
	}
}
























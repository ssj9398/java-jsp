
public class Ex3 {

	public static void main(String[] args) {
		/*
		 * 다형성(Polymorphism)
		 * - 하나의 참조변수로 여러 인스턴스를 참조할 수 있는 특성
		 * - 인스턴스를 업캐스팅 하여 슈퍼클래스 타입으로 서브클래스의 멤버 다루는 것
		 */
		
		Circle c = new Circle();
		c.paint();
		
		Rectangle r = new Rectangle();
		r.design();
		
		Triangle t = new Triangle();
		
		// 슈퍼클래스의 메서드를 상속받아 오버라이딩을 할 경우 코드의 통일성이 향상됨
		c.draw();
		r.draw();
		t.draw();
		
		// 코드의 통일성을 더욱 향상시키기 위해 업캐스팅 활용
		// => Circle, Rectangle, Triangle 의 공통 슈퍼클래스인 Shape 클래스 타입 활용
		Shape s = c;
//		s.paint(); // 업캐스팅 후에는 상속받은 메서드와 동일한 메서드만 호출 가능
		s.draw();
		
		s = r;
		s.draw();
		
		s = t;
		s.draw();
		
		System.out.println("------------------------------------------");
		
		// 다형성을 배열에 적용시키는 경우
//		Shape[] sArr = new Shape[3];
//		sArr[0] = new Circle(); // Circle -> Shape 업캐스팅
//		sArr[1] = new Rectangle(); // Rectangle -> Shape 업캐스팅
//		sArr[2] = new Triangle(); // Triangle -> Shape 업캐스팅
		
		Shape[] sArr = {new Circle(), new Rectangle(), new Triangle()};
		// => Shape 타입 배열에 Circle, Rectangle, Triangle 인스턴스를 저장 = 업캐스팅
		
		for(int i = 0; i < sArr.length; i++) {
			// 배열 내의 모든 인스턴스에 있는 draw() 메서드 호출
			sArr[i].draw(); // 하나의 변수명만으로 모든 인스턴스의 공통 메서드 호출 반복
		}
		
		System.out.println("------------------------------------");
		
		// 메서드에 다형성 활용
		polymorphism(c); // Circle -> Shape
		polymorphism(r); // Rectangle -> Shape
		polymorphism(t); // Triangle -> Shape
		
	}
	
	public static void polymorphism(Shape s) { // 메서드 호출 시 업캐스팅 일어남
		s.draw();
	}
	

}

class Shape {
	public void draw() {
		System.out.println("도형 그리기!");
	}
}

class Circle extends Shape {
	
	public void paint() {
		System.out.println("원 그리기(paint)!");
	}

//	@Override
//	public void draw() {
//		System.out.println("원 그리기!");
//	}
	
}

class Rectangle extends Shape {
	
	public void design() {
		System.out.println("사각형 그리기(design)!");
	}

	@Override
	public void draw() {
		System.out.println("사각형 그리기!");
	}
	
}

class Triangle extends Shape {

	@Override
	public void draw() {
		System.out.println("삼각형 그리기!");
	}
	
}


















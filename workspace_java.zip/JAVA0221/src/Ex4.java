
public class Ex4 {

	public static void main(String[] args) {
		/*
		 * < 자바 프로그램 실행 과정 >
		 * 0. 소스 코드 작성 및 컴파일(번역) 후 클래스 실행
		 * 1. 클래스 로딩 => static 변수 및 메서드가 메모리에 로딩됨
		 * 2. main() 메서드 호출(실행)
		 * 3. 인스턴스 생성 => 인스턴스 변수 및 메서드가 메모리에 로딩됨
		 * 4. 메서드 호출(실행) => 메서드 내의 로컬 변수가 메모리에 로딩됨
		 * 5. 결과 출력됨
		 * 
		 * < static 키워드 >
		 * - 클래스, 메서드, 변수의 지정자로 사용
		 * - 메서드 또는 변수에 static 키워드를 사용할 경우
		 *   인스턴스 생성과 상관없이 클래스가 로딩되는 시점에 함께 메모리에 로딩됨
		 *   => 따라서, 참조변수 없이 클래스명만으로 해당 멤버에 접근 가능
		 *   (기본 문법 : 클래스명.멤버변수 또는 클래스명.메서드() 형태로 접근)
		 *   
		 * < static 변수 >
		 * - 인스턴스 생성 전, 클래스가 메모리에 로딩될 때 static 변수도 함께 로딩됨
		 * - 참조변수 없이 클래스명만으로 해당 멤버에 접근 가능
		 * - 멤버변수에 static 키워드를 사용할 경우 클래스 변수(정적 변수)로 취급되며
		 *   모든 인스턴스가 하나의 변수를 공유함(클래스 당 하나만 생성됨)  
		 */
		
//		System.out.println(s1.a); // 참조변수 선언 전 접근 불가
		// 일반 멤버변수는 반드시 인스턴스 생성 후 참조변수를 통해서만 접근이 가능하다!
		
		// static 멤버변수의 경우 클래스명만으로 인스턴스 생성과 상관없이 접근이 가능하다!
		System.out.println("StaticMember.a : " + StaticMember.a);
//		System.out.println("StaticMember.b : " + StaticMember.b); // 인스턴스 변수 X
		
		StaticMember s1 = new StaticMember();
		StaticMember s2 = new StaticMember();
		
		System.out.println("s1.a : " + s1.a + ", s2.a : " + s2.a);
		System.out.println("s1.b : " + s1.b + ", s2.b : " + s2.b);
		
		// s1 인스턴스의 변수 a 값을 99 로 변경, s1 인스턴스의 변수 b 값을 999로 변경
//		s1.a = 99; // s1 인스턴스의 static 변수 a 의 값을 99 로 변경
		StaticMember.a = 99; // StaticMember 클래스의 static 변수 a 의 값을 99로 변경
		// => 두 코드는 실행 결과가 동일하다!
		
		System.out.println("s1.a : " + s1.a + ", s2.a : " + s2.a); // 99, 99 출력됨
		// => s1 인스턴스에서 멤버변수 a 값을 변경하면 s2 인스턴스의 a 도 변경됨
		//    클래스 당 하나씩 생성되는 멤버변수이므로 모든 인스턴스에서 값을 공유
		
		s1.b = 999;
		System.out.println("s1.b : " + s1.b + ", s2.b : " + s2.b); // 999, 20 출력됨
		// => s1 인스턴스에서 멤버변수 b 값을 변경하더라도 s2 인스턴스의 b 는 변경 X
		//    인스턴스 당 하나씩 생성되는 멤버변수이므로 모든 인스턴스가 각각 따로 관리
		
	}

}

class StaticMember {
	static int a = 10; // 정적(static) 변수 = 모든 인스턴스에서 공유하는 멤버변수
	// => StaticMember 클래스가 메모리에 로딩될 때 함께 로딩되는 변수 
	
	int b = 20; // 인스턴스 변수 = 각 인스턴스에서 별도로 관리하는 멤버변수
	// => StaticMember 인스턴스가 생성될 때 생성되는 변수
	
	public void method() {
		// 자신의 클래스 내의 메서드에서 static 변수나 인스턴스 변수 접근 방법 동일
		a = 99;
		b = 999;
	}
}















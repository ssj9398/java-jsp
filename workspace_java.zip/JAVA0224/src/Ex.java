
public class Ex {

	public static void main(String[] args) {
		/*
         * static 메서드(= 정적 메서드)
         * - 메서드 선언 시 리턴타입 앞에 static 키워드를 붙여서 정의
         * - 클래스가 메모리에 로딩될 때 static 변수와 함께 메모리에 로딩되므로
         *   인스턴스 생성과 무관 => 클래스명만으로 접근이 가능
         *   (클래스명.메서드명() 형태로 호출)
         * 
         * < static 메서드 사용 시의 주의사항 >
         * - 인스턴스 생성 시점에서 생성되는 것들은 static 메서드 내에서 접근 불가능
         * 1. this 또는 super 사용 불가
         *    => 원인 : static 메서드가 로딩되는 시점은 클래스가 로딩되는 시점이며
         *              인스턴스 생성 전이므로 인스턴스 주소가 저장되는 레퍼런스가 없음
         *    => 동일한 변수명 사용 시 해결책 : this.XXX 이나 super.XXX 대신
         *                                      클래스명.XXX 사용으로 대체
         * 2. 인스턴스 변수 사용 불가
         *    => 원인 : static 메서드가 로딩되는 시점은 클래스가 로딩되는 시점이며
		 *              인스턴스 변수는 인스턴스 생성 후에 메모리에 로딩되므로
		 *              static 메서드가 로딩되는 시점에서는 존재하지 않는 변수이다!
         * 3. 메서드 오버라이딩 불가
         */
		
		// static 메서드도 변수처럼 인스턴스 생성과 관계 없이 클래스명만으로 접근 가능
		StaticMethod.staticMethod();
		
		StaticMethod sm = new StaticMethod();
		sm.normalMethod(); // 일반 메서드 접근 가능
//		sm.staticMethod(); // static 메서드 접근 가능 => 정석적인 접근 방법은 아님!
		StaticMethod.staticMethod(); // static 메서드에 접근하는 정석적인 방법
		
		
		StaticMethodChild.staticMethod();
		
	}

}

class StaticMethod {
	int normalVar = 10;
	static int staticVar = 20;
	
	public void normalMethod() {
		System.out.println("일반 메서드!");
		System.out.println("일반 메서드에서 인스턴스 변수 접근 : " + normalVar);
		System.out.println("일반 메서드에서 static 변수 접근 : " + staticVar);
		
		// 일반 메서드에서 static 메서드도 호출 가능
		staticMethod(); 
	}
	
	public static void staticMethod() {
		System.out.println("static 메서드!");
//		System.out.println("static 메서드에서 인스턴스 변수 접근 : " + normalVar);
		// => 컴파일에러 발생! 
		//    (Cannot make a static reference to the non-static field normalVar)
		
		System.out.println("static 메서드에서 static 변수 접근 : " + staticVar);
		
		// static 메서드에서 일반 메서드도 호출 불가능(인스턴스 변수도 접근 불가)
//		normalMethod();
	}

	
	public void setNormalVar(int normalVar) {
		this.normalVar = normalVar;
	}

	public static void setStaticVar(int staticVar) {
//		this.staticVar = staticVar; // static 메서드 내에서 this, super 사용 불가
		StaticMethod.staticVar = staticVar; // this 대신 클래스명으로 구분
	}

	
}

class StaticMethodChild extends StaticMethod {
	
	// static 메서드는 서브클래스에서 오버라이딩 불가!
	// => 동일한 형태의 새로운 메서드를 정의하는 개념으로 사용 가능!
//	@Override
//	public static void staticMethod() {	}
	// => @Override 어노테이션 사용하면 오버라이딩 오류 발생! 
	
	public static void staticMethod() {	} // 새로 정의하는 문법으로는 사용 가능
	
}


















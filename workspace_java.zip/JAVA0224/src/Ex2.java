
public class Ex2 {
	/*
	 * static 멤버와 인스턴스 멤버 메모리 할당 순서
	 * 1. static 키워드가 선언된 모든 멤버가 메모리에 로딩됨
	 * 2. static 멤버가 메모리에 로딩될 때 static 변수 a, c 에 
	 *    check() 메서드 호출 후 리턴값이 할당되어야 하므로 check() 메서드 호출됨
	 *    => "call : 1" 출력
	 *       "call : 3" 출력
	 * 3. main() 메서드가 자동으로 호출됨
	 *    => "main() 메서드" 출력
	 * 4. main() 메서드 내에서 Ex2 인스턴스 생성됨 => 인스턴스 변수 b 메모리에 로딩됨
	 * 5. 인스턴스 변수 b 가 로딩될 때 check() 메서드 호출됨
	 *    => "call : 2" 출력   
	 */
	int b = check(2);
	
	static int a = check(1);
	
	public static int check(int i) {
		System.out.println("call : " + i);
		return 0;
	}

	public static void main(String[] args) {
		System.out.println("main() 메서드");
		Ex2 ex = new Ex2();
	}
	
	static int c = check(3);

}

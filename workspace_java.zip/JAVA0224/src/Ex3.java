import java.util.Calendar;

public class Ex3 {

	public static void main(String[] args) {
		/*
		 * 싱글톤 디자인 패턴(Singleton Design Pattern)
		 * - 단 하나의 인스턴스만을 공유하도록 하는 프로그래밍 기법
		 * - 외부에서 인스턴스 생성을 하지 못하게 차단하고
		 *   클래스 내에서 직접 인스턴스를 생성하여 외부에 리턴하는 기법
		 * - 누구나 단 하나의 인스턴스만을 공유하여 사용해야함
		 * 
		 * < 패턴 규칙 >
		 * 1. 외부에서 인스턴스 생성이 불가능하도록 생성자에 private 접근제한자 선언
		 * 2. 자신의 클래스 내에서 인스턴스를 생성하여 참조변수에 저장
		 * 	  => 외부에서 인스턴스 생성이 불가능하므로
	     *    => 인스턴스 생성없이 접근해야하므로 static 키워드 사용
	     *    => 외부에서 함부로 접근하지 못하도록 private 접근제한자 선언
		 * 3. 생성된 인스턴스를 외부로 리턴하는 Getter 메서드 정의
		 *    => private 접근제한자 멤버변수에 저장된 인스턴스를 리턴
         *    => 인스턴스 생성없이 접근해야하므로 static 키워드 사용
         *    
         * < 실제 정의할 때의 문법 순서 >
         * 1. 멤버변수 선언 및 인스턴스 생성(private static)
         * 2. 생성자 정의(private)
         * 3. Getter 정의(public static)
		 */
//		SingletonClass sc = new SingletonClass();
		
//		SingletonClass.instance = null;
		
		// 싱글톤 디자인 패턴으로 생성된 인스턴스 가져오기
		// => static 메서드인 getInstance() 메서드 호출을 위해 클래스명.메서드() 로 호출
		SingletonClass sc = SingletonClass.getInstance();
		sc.print();
		
		SingletonClass sc2 = SingletonClass.getInstance();
		
		if(sc == sc2) {
			System.out.println("sc 와 sc2 는 같은 인스턴스!");
		} else {
			System.out.println("sc 와 sc2 는 다른 인스턴스!");
		}
		
		System.out.println("==============================");
		
		// 싱글톤 패턴과 비슷한 사용 예 - Calendar 클래스
//		Calendar cal = new Calendar(); // 인스턴스 생성 불가
		Calendar cal = Calendar.getInstance(); 
		// => Calendar 클래스 내의 static 메서드를 호출하여 인스턴스 가져오기
		
		
	}

}

class SingletonClass {
	
	// 외부에서 생성자 호출이 불가능하도록 private 접근제한자 선언
	private SingletonClass() {}
	
	// 외부에서 인스턴스 생성이 불가능한 대신 자신의 클래스에서 직접 인스턴스 생성
	// => 인스턴스 생성없이 접근해야하므로 static 키워드 사용
	// => 외부에서 함부로 접근하지 못하도록 private 접근제한자 선언
	private static SingletonClass instance = new SingletonClass();

	// private 접근제한자 멤버변수에 저장된인스턴스를 외부로 리턴하는 Getter 메서드 정의
	// => 인스턴스 생성없이 접근해야하므로 static 키워드 사용
	public static SingletonClass getInstance() {
		return instance;
	}
	
	// ----------------------------------------------
	
	public void print() {
		System.out.println("print() 메서드 호출!");
	}
	
}

class SingletonClass2 {
	// 1. 멤버변수 선언 및 인스턴스 생성 => private static 선언
	private static SingletonClass2 instance = new SingletonClass2();
	
	// 2. 생성자 정의 => private 선언
	private SingletonClass2() {}

	// 3. Getter 정의 => static 선언
	public static SingletonClass2 getInstance() {
		return instance;
	}
	
}


















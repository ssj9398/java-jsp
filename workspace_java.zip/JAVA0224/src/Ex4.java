
public class Ex4 {

	public static void main(String[] args) {
		/*
		 * final 키워드
		 * - '변경의 마지막' 이라는 의미로 사용되는 키워드
		 * - 변수, 메서드, 클래스에 사용 가능
		 * 
		 * 1. 변수에 final 키워드가 사용될 경우
		 *    - 변수 값 변경 불가 = 상수로 취급됨
		 *    - 반드시 초기화 코드가 포함되어야 함
		 *    - 초기화 코드를 포함하지 않는 변수를 blank final 변수라고 하며
		 *      생성자에서 반드시 해당 변수 초기화가 수행되어야 함!
		 *      (=> 주로 객체마다 다른 고정된 값을 사용해야 하는 경우)
		 *    - 기존 상수(final 변수)를 그대로 사용하는 것은 가능
		 *    - 대표적인 변경 불가 상수 : Math 클래스의 PI 등
		 *    - 상수 선언 시 주로 대문자로 이름을 지정
		 *      (단어 간의 구분 시 언더스코어(_) 기호 사용. ex) MY_NAME)
		 *
		 * 2. 메서드에 final 키워드가 사용될 경우
		 *    - 메서드 내용 변경 불가 = 메서드 오버라이딩 금지
		 *    - 슈퍼클래스의 메서드를 상속받아 그대로 사용하는 것은 가능
		 *    
		 * 3. 클래스에 final 키워드가 사용될 경우
		 *    - 클래스 내용 변경 불가 = 상속 금지
		 *    - 해당 클래스의 인스턴스 생성을 통해 그대로 사용하는 것은 가능
		 *    - 대표적인 상속 불가 클래스 : String 등
		 */
		
		FinalVariable fv = new FinalVariable(5);
		fv.a = 99;
//		fv.b = 999; // 컴파일 에러 발생! final 변수(= 상수)는 값 변경 불가!
		            // (The final field FinalVariable.b cannot be assigned)
		
		// Math 클래스의 PI 상수는 사용은 가능하지면 변경은 불가능한 final 상수
		System.out.println(Math.PI);
//		Math.PI = 3.14; // final 변수(= 상수) 이므로 값 변경 불가

		
		SubFinalMethod sfm = new SubFinalMethod();
		sfm.finalMethod(); // final 메서드를 서브클래스에서 상속받아 사용은 가능!
		
		
		// final 클래스는 상속은 불가능하며, 해당 클래스를 사용하는데 제약은 없다!
		FinalClass fc = new FinalClass();
		System.out.println(fc.name);
		fc.print();
	}

}

class FinalVariable {
	// 변수에 final 키워드가 선언될 경우
	
	int a = 10; // 값 변경이 가능한 변수
	final int b = 20; // 값 변경이 불가능한 상수
	
	// 별도의 초기화가 되지 않은 상수(blank final 변수)는 선언 과정에서 오류 발생됨
	// The blank final field c may not have been initialized
	final int c;
	// => 단, 생성자를 통해 초기화하는 코드가 포함될 경우 오류가 발생하지 않는다!
	//    (생성자에서 단 한 번의 초기화는 가능하다!)
	public FinalVariable(int c) {
		this.c = c;
	}
	
	public void change() {
//		c = 9999; // 생성자에서 한 번 초기화하고 나면 변경 불가!
	}
	
}

class FinalMethod {
	// 메서드에 final 키워드가 사용될 경우
	public final void finalMethod() { // 오버라이딩이 불가능한 메서드가 됨
		System.out.println("슈퍼클래스의 finalMethod()");
	}
	
	public void normalMethod() { // 일반 메서드 = 오버라이딩 가능
		System.out.println("슈퍼클래스의 normalMethod()");
	}
}

class SubFinalMethod extends FinalMethod {

	// 슈퍼클래스에서 상속받은 메서드 중 final 메서드는 오버라이딩이 불가능하다!
//	@Override
//	public void finalMethod() {
//		System.out.println("서브클래스에서 오버라이딩 된 finalMethod()");
//	}
	
	// 일반메서드는 오버라이딩이 가능하다!
	@Override
	public void normalMethod() {
		System.out.println("서브클래스에서 오버라이딩 된 normalMethod()");
	}
	
	
}

// 클래스에 final 키워드를 사용할 경우
final class FinalClass { // 상속 불가능한 클래스가 됨
	String name = "final 클래스";
	
	public void print() {
		System.out.println("FinalClass 의 print() 메서드!");
	}
}

// FinalClass 는 상속받을 수 없다!
//class SubFinalClass extends FinalClass {}








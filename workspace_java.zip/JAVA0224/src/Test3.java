
public class Test3 {

	public static void main(String[] args) {
		Account acc = Account.getInstance();
		System.out.println(acc.getBankName());
	}

}

class Account {
	// ---------------------------------------------------
	// Account 클래스의 싱글톤 디자인 패턴 적용
	private static Account instance = new Account();
	
	private Account() {}

	public static Account getInstance() {
		return instance;
	}
	// ---------------------------------------------------
	
	private String bankName = "ITWILL 은행";

	public String getBankName() {
		return bankName;
	}
	
}
























public class Ex {

	public static void main(String[] args) {
		/*
		 * (public) static final 상수
		 * - 주로 특정 변수 값을 지정하기 위해 클래스 내에 상수 제공
		 *   => 이 때, 값 변경이 불가능하고 클래스명만으로 접근하도록 static final 사용
		 */
		Car car = new Car();
		car.setCarName("그랜져");
		car.setCarColor("Blue");
		
		Car car2 = new Car();
		car2.setCarName("GRANDURE");
		car2.setCarColor("BLUE");
		
		if(car.getCarName() == car2.getCarName()) {
			System.out.println("두 차는 차종이 같습니다!");
		} else {
			System.out.println("두 차는 차종이 다릅니다!");
		}
		
		// -------------------------------------------
		
//		car.setCarName(car.CAR_NAME_GRANDURE);
		car.setCarName(Car.CAR_NAME_GRANDURE); // static 상수에 접근하는 올바른 방법
//		car.CAR_NAME_GRANDURE = "SONATA"; // 상수이므로 값 변경 불가
		
		// car 클래스의 차량 모델명이 그랜져인지 판별
		if(car.getCarName() == Car.CAR_NAME_GRANDURE) {
			System.out.println("차량이 그랜져입니다!");
		} else {
			System.out.println("차량이 그랜져가 아닙니다!");
		}
		
		car.setCarColor(Car.CAR_COLOR_RED);
		
		car.setGearType(Car.CAR_GEARTYPE_AUTO);
		
		
	}

}

class Car {
	String carName; // 차모델명
	String carColor; // 차량 색상
	int cc; // 차량 배기량
	int gearType; // 기어 타입(1 : AUTO, 2 : MANUAL)
	
	// 멤버변수 값을 저장하는 변수(상수) 선언 및 초기화
	public static final String CAR_NAME_SONATA = "SONATA";
	public static final String CAR_NAME_GRANDURE = "GRANDURE";
	
	public static final String CAR_COLOR_WHITE = "하얀색";
	public static final String CAR_COLOR_RED = "아주 빨간색";
	
	public static final int CAR_GEARTYPE_AUTO = 1;
	public static final int CAR_GEARTYPE_MANUAL = 2;
	
	public String getCarName() {
		return carName;
	}
	public void setCarName(String carName) {
		this.carName = carName;
	}
	public String getCarColor() {
		return carColor;
	}
	public void setCarColor(String carColor) {
		this.carColor = carColor;
	}
	public int getCc() {
		return cc;
	}
	public void setCc(int cc) {
		this.cc = cc;
	}
	public int getGearType() {
		return gearType;
	}
	public void setGearType(int gearType) {
		this.gearType = gearType;
	}

}














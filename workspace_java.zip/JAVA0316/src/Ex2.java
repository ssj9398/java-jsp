
public class Ex2 {

	public static void main(String[] args) {
		Vehicle[] vehicles = {new DieselSUV(), new ElectricCar()};
		for(Vehicle v : vehicles) {
			v.reportPosition();
			v.addFuel();
		}
		
		// DieselSUV 와 ElectricCar 인스턴스의 addFuel() 메서드가 호출되므로
		// Vehicle 클래스의 addFuel() 메서드 코드는 실행되지 않는다!
		// => 하지만, Vehicle 클래스에서 삭제하면 다형성 활용이 불가능해진다!
		
		
	}

}

class Vehicle {
	private int curX, curY;
	
	public void reportPosition() {
		System.out.printf("현재 위치 : (%d, %d)\n", curX, curY);
	}
	
	public void addFuel() {
		System.out.println("모든 운송 수단은 연료가 필요");
	}
}

class DieselSUV extends Vehicle {

	@Override
	public void addFuel() {
		System.out.println("주유소에서 급유");
	}
	
}

class ElectricCar extends Vehicle {

	@Override
	public void addFuel() {
		System.out.println("급속 충전");
	}
	
}
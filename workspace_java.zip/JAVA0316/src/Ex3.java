
public class Ex3 {

	public static void main(String[] args) {
		/*
		 * 추상 클래스(Abstract Class)와 추상 메서드(Abstract Method)
		 * 
		 * 1. 추상메서드
		 *   - 메서드 구현부(Body)가 없는 메서드 = 실행할 코드(동작)가 없는 메서드
		 *     => 메서드 구현부{} 대신 세미콜론(;)으로 끝냄
		 *   - 메서드 선언부 리턴타입 앞에 abstract 키워드 명시
		 *   - 호출할 수 없는 메서드이므로 추상메서드가 포함된 클래스는
		 *     반드시 추상클래스로 정의해야한다!
		 *     
		 *   < 기본 문법 >
		 *   [접근제한자] abstract 리턴타입 메서드명([파라미터...]); 
		 *     
		 * 2. 추상클래스
		 *   - 인스턴스를 생성할 수 없는 클래스(new 사용 불가)
		 *   - 클래스 내에 추상메서드가 하나라도 존재할 경우 반드시 추상클래스로 선언
		 *   - 추상메서드는 물론 일반메서드도 가질 수 있으며, 멤버변수와 상수 사용 가능
		 *     => 즉, 모든 추상클래스가 추상메서드를 포함해야하는 것은 아니다!
		 *   - 추상메서드가 포함된 클래스(추상클래스)를 상속받는 서브클래스는
		 *     반드시 추상메서드를 구현(implements)해야한다. = 오버라이딩과 방법 동일
		 *     => 궁극적인 목적 : 서브클래스에서 메서드 구현을 강제하기 위함
		 *     => 서브클래스에서 추상메서드를 구현하지 않으면 컴파일 에러 발생 = 상속 불가
		 *   - 추상클래스를 상속받아 추상메서드를 구현한 서브클래스를 사용해야한다!
		 *   - 추상클래스도 클래스이므로 단일 상속만 가능하다!
		 *     
		 *   < 기본 문법 >
		 *   [접근제한자] abstract class 클래스명 {
		 *   	// 멤버변수, 상수
		 *      // 일반메서드, 추상메서드
		 *   }
		 */
		
//		AbstractClass ac = new AbstractClass(); // 컴파일에러 발생
		// Cannot instantiate the type AbstractClass
		// => 추상클래스는 인스턴스 생성이 불가능하다!
		
		// 추상클래스를 상속받아 추상메서드를 구현한 서브클래스를 사용해야한다!
		SubAbstractClass sac = new SubAbstractClass();
		sac.normalMethod(); // 일반메서드
		sac.abstractMethod(); // 서브클래스에서 구현한 추상메서드
		
	}

}

abstract class AbstractClass {
	int num = 1;
	
	public void normalMethod() {
		System.out.println("AbstractClass 의 일반 메서드!");
	}
	
//	public void abstractMethod() {
//		System.out.println("서브클래스에서 반드시 오버라이딩 하길 원하는 메서드");
//	}
	
	public abstract void abstractMethod(); // 추상메서드
	
}

class SubAbstractClass extends AbstractClass {

	// 추상클래스를 상속받은 서브클래스는 슈퍼클래스인 추상클래스가 포함하는
	// 추상메서드를 반드시 구현(implement) 해야한다 => 오버라이딩과 동일함
	// The type SubAbstractClass must implement the inherited abstract method AbstractClass.abstractMethod()
	@Override
	public void abstractMethod() {
		System.out.println("서브클래스에서 구현한 추상메서드 abstractMethod()!");
	}
	
}


class NormalClass {
	public void normalMethod() {
		System.out.println("NormalClass 의 일반 메서드!");
	}
}

class SubNormalClass extends NormalClass {
	// 슈퍼클래스의 메서드를 오버라이딩 하지 않아도 아무 문제가 없다!
}


















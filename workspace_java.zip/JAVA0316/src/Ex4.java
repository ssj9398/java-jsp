
public class Ex4 {

	public static void main(String[] args) {
		/*
		 * 추상클래스를 상속받은 서브클래스는 반드시 추상메서드를 구현해야하지만
		 * 만약, 추상메서드 구현을 회피해야할 경우 자신도 추상클래스로 선언하면 된다.
		 * (자신도 추상메서드를 포함하게 되므로 추상클래스가 되어야함)
		 * => 단, 서브클래스 중 누군가는 반드시 추상메서드를 구현해야만 사용 가능하다!
		 */
//		AbstractClass4 ac = new AbstractClass4(); // 추상클래스 인스턴스 생성 불가!
//		MiddleAbstractClass4 mac = new MiddleAbstractClass4(); // 추상클래스 인스턴스 생성 불가!
		
		// 추상클래스를 구현한 일반 서브클래스를 인스턴스화하여 사용해야함
		SubAbstractClass4 sac = new SubAbstractClass4();
		sac.normalMethod();
		sac.normalMethod2();
		sac.abstractMethod();
	}

}

abstract class AbstractClass4 { // 추상메서드를 포함하므로 추상클래스로 정의
	public void normalMethod() {
		System.out.println("슈퍼클래스의 일반메서드!");
	}
	
	// 추상메서드 abstractMethod() 정의
	public abstract void abstractMethod();
	
}

abstract class MiddleAbstractClass4 extends AbstractClass4 {
	// 상속받은 추상메서드를 구현하지 않을 경우, 현재 클래스도 추상클래스로 선언해야한다!
	public void normalMethod2() {
		System.out.println("중간 서브클래스의 일반메서드!");
	}
}

// 최종적으로 서브클래스 중 누군가가 추상메서드를 구현해야 사용 가능하다!
class SubAbstractClass4 extends MiddleAbstractClass4 {

	@Override
	public void abstractMethod() {
		System.out.println("서브클래스에서 구현한 추상메서드!");
	}
	
}

















public class Test3 {

	public static void main(String[] args) {
		
	}

}

abstract class Vehicle4 {
	private int curX, curY;
	
	public void reportPosition() {
		System.out.printf("현재 위치 : (%d, %d)\n", curX, curY);
	}
	
	// Vehicle 클래스의 모든 서브클래스에서 addFuel() 메서드를 오버라이딩 하도록 강제
	// => 추상메서드로 구현
	public abstract void addFuel();
	
}

// DieselSUV4 와 ElectricCar4 클래스 정의 - 추상클래스 Vehicle4 클래스를 상속
class DieselSUV4 extends Vehicle4 {

	@Override
	public void addFuel() {
		System.out.println("주유소에서 급유!");
	}
	
}

class ElectricCar4 extends Vehicle4 {

	@Override
	public void addFuel() {
		System.out.println("전기 급속 충전!");
	}
	
}

class HorseCart extends Vehicle4 {

	@Override
	public void addFuel() {
		System.out.println("건초 공급!");
	}
	
}










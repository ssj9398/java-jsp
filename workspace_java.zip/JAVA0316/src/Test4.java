
public class Test4 {

	public static void main(String[] args) {
		// 상속 관계에서 다형성 활용이 가능하므로
		// 레퍼런스 타입으로 사용 가능한 추상클래스도 다형성 활용이 가능하다!
		Shape s; // 슈퍼클래스인 추상클래스 Shape 에 대한 레퍼런스 변수 선언
		
//		s = new Shape(); // 추상클래스는 인스턴스 생성 불가
		
		// Circle, Rectangle, Triangle 인스턴스에 대한 업캐스팅 활용
		s = new Circle();
		s.draw();
		
		s = new Rectangle();
		s.draw();
		
		s = new Triangle();
		s.draw();
		
	}

}

/*
 * Shape 클래스 정의
 * - draw() 메서드 정의 => 파라미터 X, 리턴값 X, 추상메서드로 정의
 * 
 * Circle, Rectangle, Triangle 클래스 정의 => Shape 클래스 상속
 * - draw() 메서드 = "원 그리기!", "사각형 그리기!", "삼각형 그리기!" 구현
 */
abstract class Shape { // 추상클래스
	public abstract void draw(); // 추상메서드
}

class Circle extends Shape {
	
	@Override
	public void draw() {
		System.out.println("원 그리기!");
	}
	
}

class Rectangle extends Shape {
	
	@Override
	public void draw() {
		System.out.println("사각형 그리기!");
	}
	
}

class Triangle extends Shape {

	@Override
	public void draw() {
		System.out.println("삼각형 그리기!");
	}
	
}

















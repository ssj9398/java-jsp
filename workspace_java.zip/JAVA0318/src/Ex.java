
public class Ex {

	public static void main(String[] args) {
		/*
		 * 인터페이스(Interface)
		 * - 클래스가 아니므로 선언 시 class 키워드 대신 interface 키워드 사용
		 * - 인터페이스는 추상메서드와 상수만 가질 수 있다.
		 *   => 모든 메서드는 public abstract 가 붙은 추상메서드로 취급됨(생략 가능)
		 *   => 모든 멤버변수는 public static final 이 붙인 상수로 취급됨(생략 가능)
		 * - 추상클래스와 마찬가지로 객체 생성이 불가능
		 *   => 단, 참조변수 타입으로는 사용 가능 = 다형성 활용(업캐스팅) 가능  
		 * - 추상메서드 구현을 강제하여, 코드의 통일성이 향상됨
		 * - 클래스에서 인터페이스를 상속받아 구현해야할 경우 implements 키워드 사용
		 * - 인터페이스끼리 상속받을 경우 extends 키워드 사용
		 */
		
//		MyInterface mi = new MyInterface(); // 객체 생성 불가
		// 인터페이스를 구현한 서브클래스의 인스턴스 생성 후 사용
		MyInterfaceImplements mii = new MyInterfaceImplements();
		mii.method1();
		mii.method2();
//		mii.NUM2 = 30; // 모든 멤버변수는 상수이므로 값 변경 불가
	
		System.out.println("------------------------------------");
		
		SuperMan s = new SuperMan();
		s.takeOff();
		s.fly();
		s.land();
		
		Airplane a = new Airplane();
		a.takeOff();
		a.fly();
		a.land();
		
		// 인터페이스 인스턴스 생성은 불가능하지만, 참조변수 타입으로 다형성 활용 가능
//		Flyer f = new Flyer();
		Flyer f = s;
		f.takeOff();
		f.fly();
		f.land();
	
		f = a;
		f.takeOff();
		f.fly();
		f.land();
	
		
	}

}

// 인터페이스 정의
interface MyInterface {
	// 인터페이스 내의 모든 멤버변수는 상수(public static final)다.
	public static final int NUM1 = 10; // 상수
	int NUM2 = 20; // 상수 = public static final 키워드 생략됨
	
	// 인터페이스 내의 모든 메서드는 추상메서드(public abstract)다.
	public abstract void method1(); // 추상메서드
//	void method2() {} // public abstract 생략된 추상메서드이므로 바디{}를 가질 수 없다.
	void method2(); // 추상메서드
	
}

// MyInterface 인터페이스를 상속받아 구현하는 서브클래스 정의
// => 주의! 인터페이스를 상속받는 클래스에서 extends 가 아닌 implements 키워드 사용!
class MyInterfaceImplements implements MyInterface {
	// 인터페이스를 상속받았을 경우 추상메서드가 존재하면 반드시 구현 = 오버라이딩 필수!
	@Override
	public void method1() {
		System.out.println("서브클래스에서 구현한 추상메서드 method1()");
	}

	@Override
	public void method2() { 
		// 부모의 메서드 접근제한자보다 좁을 수 없으므로 반드시 public 사용
		System.out.println("서브클래스에서 구현한 추상메서드 method2()");
	}
	
}

// ------------------------------------------------------------
// Flyer 인터페이스 정의
// => 이륙(takeOff()), 비행(fly()), 착륙(land()) 메서드 정의 = 추상메서드
interface Flyer {
	public abstract void takeOff();
	public abstract void fly();
	public abstract void land();
}

// SuperMan 클래스 정의 => Flyer 인터페이스를 상속받아 구현
// => 각 메서드 구현하여 "SuperMan 이륙", "SuperMan 비행", "SuperMan 착륙" 출력
class SuperMan implements Flyer {

	@Override
	public void takeOff() {
		System.out.println("SuperMan 이륙!");
	}

	@Override
	public void fly() {
		System.out.println("SuperMan 비행!");
	}

	@Override
	public void land() {
		System.out.println("SuperMan 착륙!");
	}
	
}

// Airplane 클래스 정의 => Flyer 인터페이스를 상속받아 구현
//=> 각 메서드 구현하여 "Airplane 이륙", "Airplane 비행", "Airplane 착륙" 출력
class Airplane implements Flyer {

	@Override
	public void takeOff() {
		System.out.println("Airplane 이륙!");
	}

	@Override
	public void fly() {
		System.out.println("Airplane 비행!");
	}

	@Override
	public void land() {
		System.out.println("Airplane 착륙!");
	}
	
}

// ------------------------------------------------------------
interface 고래 extends 동물 { // 인터페이스끼리 상속은 extends 사용
	// 인터페이스 내의 모든 메서드는 추상메서드이므로 메서드 바디({})를 가질 수 없다!
//	public void 번식() {}
}

interface 상어 extends 동물 {
	
}

class 고래상어 implements 고래, 상어 {
	// 인터페이스를 상속(구현)할 때, 2개 이상의 부모로부터 상속(구현)이 가능하다
	// => 즉, 인터페이스는 다중 구현을 지원함!
	@Override
	public void 번식() {
		System.out.println("알을 낳아 번식!");
	}
	
}















public class Ex2 {

	public static void main(String[] args) {
		/*
		 * 인터페이스끼리의 상속
		 */
	}

}

interface IHello {
	public void sayHello(String name);
}

interface IGoodbye {
	public void sayGoodbye(String name);
}

// IHello, IGoodbye 인터페이스를 상속받는 ITotal 인터페이스 정의 
// 인터페이스 끼리는 다중 상속 가능하며, extends 키워드 사용하여 상속
interface ITotal extends IHello, IGoodbye {
	// 부모 인터페이스를 상속받아 내용을 확장하는 목적이므로 extends 사용하여 상속
	public void greeting(String name);
}

// ITotal 인터페이스를 상속받아 구현하는 ISay 클래스 정의
class ISay implements ITotal {
	// ITotal 인터페이스가 가지는 3개의 추상메서드를 모두 구현해야함!
	@Override
	public void sayHello(String name) {
		System.out.println(name + "씨, 안녕하세요!");
	}

	@Override
	public void sayGoodbye(String name) {
		System.out.println(name + "씨, 안녕히 가세요!");
	}

	@Override
	public void greeting(String name) {
		System.out.println(name + ", 안녕!");
	}
	
}

abstract class ISay2 implements ITotal {
	// ITotal 인터페이스가 가지는 3개의 추상메서드를 모두 구현해야함!
	// => 만약, 추상메서드 중 하나라도 구현하지 않을 경우 컴파일 에러 발생!
	//    => 현재 클래스를 추상클래스로 선언해야한다!
	@Override
	public void sayHello(String name) {
		System.out.println(name + "씨, 안녕하세요!");
	}

//	@Override
//	public void sayGoodbye(String name) {
//		System.out.println(name + "씨, 안녕히 가세요!");
//	}
//
//	@Override
//	public void greeting(String name) {
//		System.out.println(name + ", 안녕!");
//	}
	
}





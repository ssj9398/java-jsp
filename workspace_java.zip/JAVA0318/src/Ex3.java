
public class Ex3 {

	public static void main(String[] args) {
		// 나쁜 예
		// => HandPhone 과 DigitalCamera 클래스의 공통 클래스 Object 로 업캐스팅
		Object[] objs = {new HandPhone(), new DigitalCamera()};
		for(int i = 0; i < objs.length; i++) { 
			// 배열 내의 객체를 꺼내서 Object 타입 변수에 저장
			Object o = objs[i];
//			o.charge(); // Object 클래스에 존재하지 않는 메서드이므로 호출 불가
			// => HandPhone, DigitalCamera 클래스 타입으로 다운캐스팅 필수!
			if(o instanceof HandPhone) { // o 는 HandPhone 입니까?
				// HandPhone 타입으로 다운캐스팅
				HandPhone hp = (HandPhone)o; // HandPhone 타입으로 변환 후
				hp.charge(); // 충전 가능
			} else if(o instanceof DigitalCamera) { // o 는 DigitalCamera 입니까?
				// DigitalCamera 타입으로 다운캐스팅
				DigitalCamera dc = (DigitalCamera)o; // DigitalCamera 타입으로 변환 후
				dc.charge(); // 충전 가능
			}
		}
		System.out.println("----------------------------------------");
		
		// 좋은 예
		// => HandPhone 과 DigitalCamera 클래스의 공통 인터페이스 Chargeable 로 업캐스팅
		Chargeable[] objs2 = {new HandPhone2(), new DigitalCamera2()};
		for(int i = 0; i < objs2.length; i++) {
			Chargeable c = objs2[i];
			// Chargeable 인터페이스에 공통 추상메서드 charge() 가 존재하므로
			// 별도의 다운캐스팅 없이 바로 charge() 메서드 호출이 가능하다!
			c.charge();
		}
		
	}

}

class Phone {}

class HandPhone extends Phone {
	public void charge() {
		System.out.println("HandPhone 충전!");
	}
}

class Camera {}

class DigitalCamera extends Camera {
	public void charge() {
		System.out.println("Camera 충전!");
	}
}

// 서로 상속 관계가 없는 클래스들 간에 인터페이스를 통한 상속관계를 부여하면
// 다형성을 확장하여 사용할 수 있게 된다!
interface Chargeable {
	public void charge(); // 공통의 충전 기능에 대한 추상메서드 정의
}

// 기존 클래스를 상속받은 상태에서 추가적인 상속을 위해 인터페이스를 활용할 수 있다!
class HandPhone2 extends Phone implements Chargeable {
	public void charge() {
		System.out.println("HandPhone 충전!");
	}
}

class DigitalCamera2 extends Camera implements Chargeable {
	public void charge() {
		System.out.println("Camera 충전!");
	}
}












public class Ex4 {

	public static void main(String[] args) {
		병사 병사 = new 병사();
		탱크 탱크 = new 탱크();
		기계일꾼 기계일꾼 = new 기계일꾼();
		
		병사.공격(탱크);
		병사.공격(탱크);
		System.out.println("탱크 체력 : " + 탱크.체력);
		
		탱크.공격(병사);
		System.out.println("병사 체력 : " + 병사.체력);
		
		기계일꾼.수리(탱크);
//		기계일꾼.수리(병사); // 병사는 수리가능 인터페이스를 구현하지 않았으므로 전달 불가
	}

}

class 유닛 {
	int 체력;
	final int 최대체력;
	int 공격력;
	
	public 유닛(int 체력) {
		this.체력 = 체력;
		최대체력 = 체력;
	}

}

interface 공격가능 { // 실제로는 ~가능한 이라는 의미를 사용 = interface Movable {}
	// 지정된 대상(유닛)을 공격하는 기능의 추상메서드 공격() 정의
	public void 공격(유닛 u); // 유닛 타입 객체를 파라미터로 전달받음
}

interface 이동가능 {
	// 지정된 위치(x, y)로 이동하는 기능의 추상메서드 이동() 정의
	public void 이동(int x, int y); // 좌표 x, y 를 파라미터로 전달받음
}

// -------------------------------------------------------------
// 수리가 가능한 유닛들을 별도로 구분하기 위한 인터페이스 활용법
// => 아무 코드도 기술되지 않은 빈 인터페이스를 정의하고
//    해당 클래스에 인터페이스를 구현하도록하면 마커(Marker) 용도로 활용 가능
// => 추상메서드가 하나도 없으므로 구현의 강제성이 없이 표시 용도로만 사용
interface 수리가능 {}
// -------------------------------------------------------------

// 병사(Marine) 클래스 정의 - 유닛, 공격가능, 이동가능
class 병사 extends 유닛 implements 공격가능, 이동가능, 치료가능 {

	public 병사() { // final 상수인 체력을 초기화하기 위한 생성자 정의
		super(50); // 유닛 클래스의 생성자를 호출하여 체력 전달
		공격력 = 5;
	}

	@Override
	public void 이동(int x, int y) {
		System.out.println("걸어서 x, y 좌표로 무브!");
	}

	@Override
	public void 공격(유닛 u) {
		System.out.println("총으로 " + u + "를 공격!");
		u.체력 -= 공격력; // 공격력만큼 체력 감소
	}
	
	public String toString() {
		return "병사";
	}
	
}

// 탱크 클래스 정의 - 유닛, 이동가능, 공격가능, 수리가능
class 탱크 extends 유닛 implements 이동가능, 공격가능, 수리가능 {
	
	public 탱크() {
		super(150);
		공격력 = 30;
	}
	
	@Override
	public void 이동(int x, int y) {
		System.out.println("바퀴를 사용하여 x, y 좌표로 무브!");
	}

	@Override
	public void 공격(유닛 u) {
		System.out.println("대포로 " + u + "를 공격!");
		u.체력 -= 공격력;
	}
	
	public String toString() {
		return "탱크";
	}
}

// 기계일꾼 클래스 정의 - 유닛, 공격가능, 이동가능, 수리가능
class 기계일꾼 extends 유닛 implements 이동가능, 공격가능, 수리가능 {
	
	public 기계일꾼() {
		super(60);
		공격력 = 2;
	}
	
	@Override
	public void 이동(int x, int y) {
		System.out.println("걸어서 x, y 좌표로 무브!");
	}

	@Override
	public void 공격(유닛 u) {
		System.out.println("용접기로 " + u + "를 공격!");
		u.체력 -= 공격력;
	}
	
	public String toString() {
		return "기계일꾼";
	}
	
	// 기계 유닛을 수리하는 수리() 메서드 정의
	public void 수리(수리가능 수리유닛) { // 공통항목으로 수리가능타입 객체를 전달받음
		// 수리를 위해서는 체력 변수에 접근해야하므로 유닛타입으로 다운캐스팅 수행
		// => 수리 가능한 유닛들만 선별하여 유닛타입으로 다운캐스팅
		if(수리유닛 instanceof 유닛) { // 수리유닛은 유닛타입입니까?
			유닛 u = (유닛)수리유닛;
			// 대상 유닛의 체력이 최대체력이 될 때까지 체력을 1씩 증가시킴(수리)
			while(u.체력 < u.최대체력) {
				u.체력++;
				System.out.println(u + " 수리 중... [" + u.체력 + "/" + u.최대체력 +"]");
			}
			System.out.println(u + " 의 수리가 끝났습니다!");
		}
	}
	
}

interface 치료가능 {}

// 간호장교 클래스 정의 - 유닛, 이동가능, 치료가능
class 간호장교 extends 유닛 implements 이동가능, 치료가능 {
	
	public 간호장교() {
		super(60);
	}
	
	@Override
	public void 이동(int x, int y) {
		System.out.println("걸어서 x, y 좌표로 무브!");
	}

	public String toString() {
		return "간호장교";
	}
	
	// 생체 유닛을 치료하는 치료() 메서드 정의
	public void 치료(치료가능 치료유닛) { // 공통항목으로 치료가능타입 객체를 전달받음
		if(치료유닛 instanceof 유닛) { // 치료유닛은 유닛타입입니까?
			유닛 u = (유닛)치료유닛;
			// 대상 유닛의 체력이 최대체력이 될 때까지 체력을 1씩 증가시킴(수리)
			while(u.체력 < u.최대체력) {
				u.체력++;
				System.out.println(u + " 치료 중... [" + u.체력 + "/" + u.최대체력 +"]");
			}
			System.out.println(u + " 의 치료가 끝났습니다!");
		}
	}
	
}






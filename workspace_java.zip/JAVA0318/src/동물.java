
public interface 동물 {
	/*
	 * 인터페이스 내의 모든 메서드는 추상메서드이다.
	 * => public abstract 키워드 생략 가능
	 */
	public void 번식();
}

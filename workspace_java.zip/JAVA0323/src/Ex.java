
public class Ex {

	public static void main(String[] args) {
		// enum 타입 상수에 접근하려면 객체 생성 없이 타입명.상수명 형태로 접근
		System.out.println(Grade.SALES);
		
		// enum 타입 참조 변수를 선언하여 상수 저장도 가능
		Grade g = Grade.SALES; // Grade 의 SALES 상수를 Grade 타입 변수에 저장
//		TestEnum t = Grade.SALES; // 다른 타입 enum 상수 저장 불가
		System.out.println(g);
		
		calculate(Grade.SALES);
//		calculate(SEASON.SPRING); // 컴파일 에러 발생! Grade 타입 enum 상수만 전달 가능!
		
		
		
		// instanceof 연산자를 활용한 타입 판별
		if(g instanceof Grade) {
			System.out.println(g + " : Grade 타입!");
		}
		
//		if(g instanceof SEASON) {} // 일치하지 않는 타입이므로 오류 발생!

		if(g instanceof Enum) { // 주의! enum 은 Enum 클래스를 상속받았음
			System.out.println(g + " : Enum 타입!");
		}

		if(g instanceof Object) {
			System.out.println(g + " : Object 타입!");
		}
		
	}
	
	public static void calculate(Grade g) {
		// 전달된 enum 상수에 대한 판별
		if(g == Grade.SALES) {
			System.out.println("SALES 이므로 영업실적 반영!");
		} else if(g == Grade.PART_TIME_JOB) {
			System.out.println("PART_TIME_JOB 이므로 근무시간 반영!");
		} else if(g == Grade.NORMAL) {
			System.out.println("NORMAL 이므로 근로계약 기준 반영!");
		}
	}

}

// enum 타입 정의
// class 키워드 대신 enum 키워드를 사용하여 정의
enum Grade {
	// 단순히 사용할 상수의 이름을 나열하기만 하면 된다!
	SALES, PART_TIME_JOB, NORMAL
}

enum Season1 {
	SPRING, SUMMER, FALL, WINTER
}


















public class Ex2 {

	public static void main(String[] args) {
		Ex2 ex = new Ex2();
		ex.compareEnum(Season.FALL);
		ex.compareEnum(Season.SUMMER);
		
		ex.enumSwitch(Season.WINTER);
		System.out.println("-----------------------------");
		
		// enum 의 메서드
		// 1. values() : 해당 enum 타입에 해당하는 배열로 모든 상수를 리턴
		// 2. name() : 해당 enum 상수의 이름을 문자열로 리턴
		// 3. ordinal() : 해당 enum 상수의 순서번호(인덱스)를 정수로 리턴
		// 4. valueOf() : 입력받은 문자열이 enum 상수와 일치하는 경우
		//                해당 문자열을 enum 타입으로 변환하여 리턴
		Season[] sArr = Season.values(); // Season 상수를 모두 배열로 변환하여 리턴
		for(int i = 0; i < sArr.length; i++) {
			String strName = sArr[i].name(); // 배열의 enum 상수 이름을 문자열로 리턴
			System.out.println("enum 상수명 : " + strName + 
								", 순서번호(ordinal) : " + sArr[i].ordinal());
			
			Season s = Season.valueOf(strName);
			if(s == Season.SPRING) {
				System.out.println("SPRING 입력됨!");
			}
//			Season s = Season.valueOf("봄"); // 일치하는 enum 상수가 없으므로 실행 에러 발생!
		}
		
	}
	
	public void compareEnum(Season season) {
		// compareTo() 메서드는 현재 enum 객체의 상수값과 파라미터의 상수값의 차를 리턴
		// ex) Season.SUMMER 값을 사용하여 season.compareTo(Season.WINTER) 수행 시
		//     Season.SUMMER(2) - Season.WINTER(4) = -2 리턴됨
		//     Season.FALL(3) - Season.WINTER(4) = -1 리턴됨
		System.out.println(season.compareTo(Season.WINTER));
		
		// enum 상수에 대한 비교 수행
		if(season.equals(Season.SPRING)) { // equals() 메서드로 enum 상수 비교 가능
			System.out.println("따뜻한 봄날입니다!");
		} else if(season.compareTo(Season.WINTER) < 0) {
			System.out.println("최소한 겨울은 아니잖아요!");
		} else {
			System.out.println("겨울입니다!");
		}
	}

	public void enumSwitch(Season season) {
		// switch ~ case 문의 switch() 파라미터로 정수, 문자열, enum 3가지만 전달 가능
		// enum 타입 전달 시 case 문에는 상수 이름만 사용하면 됨!
		switch (season) { // switch 문에 전달받은 enum 타입을 자동으로 감지
			case SPRING : // Season.SPRING 지정 시 오류 발생!
				System.out.println("봄!");
				break;
			case SUMMER :
				System.out.println("여름!");
				break;
			case FALL :
				System.out.println("가을!");
				break;
			case WINTER :
				System.out.println("겨울!");
		}
	}

}

enum Season {
	// enum 상수는 자동으로 ordinal 값이 순차적으로 부여되며, 인덱스처럼 0부터 부여됨
	SPRING/*0*/, SUMMER/*1*/, FALL/*2*/, WINTER/*3*/
}

















public class Ex3 {

	public static void main(String[] args) {
		/*
		 * 향상된 for문(for each 문)
		 * - 배열이나 컬렉션 등의 데이터 저장 객체 사용 시
		 *   인덱스 등을 지정하여 반복하는 것이 아니라
		 *   해당 객체 내의 데이터를 순서대로 가져오는 작업을 자동으로 반복하는 for문
		 * - 객체 내용을 반복하여 가져오는 작업을 자동으로 처리하므로 편리함
		 * - 그러나, 무조건 객체 내의 모든 요소에 차례대로 접근하므로
		 *   특정 위치의 데이터에만 접근하는 것이 불가능!
		 * - 또한, 배열 내의 인덱스 번호 지정 등의 작업이 불가능(별도의 인덱스변수 필요) 
		 *   
		 * < 기존 배열 접근을 위한 for문 기본 문법 >
		 * for(int i = 0; i < 배열명.length; i++) {
		 * 		// 제어변수 i 를 활용하여 인덱스 번호로 객체에 접근하여 데이터 사용
		 * }
		 * 
		 * < 향상된 for문 기본 문법 >
		 * for(객체에서 꺼낸 데이터를 저장할 변수 선언 : 배열 등의 객체) {
		 * 		// 제어변수 없이 자동으로 좌변 변수에 데이터가 저장되므로 바로 사용 가능
		 * }
		 */
		
		// 배열의 데이터를 향상된 for문으로 접근
		String[] names = {"JAVA", "JSP", "Android", "Oracle"};
		
		// 1. 기존 for문을 사용하여 배열 내의 모든 데이터 출력
		for(int i = 0; i < names.length; i++) {
//			System.out.println(names[i]);
			// 변수에 저장하기 위한 작업을 별도로 수행해야함
			String name = names[i];
			System.out.println(name);
		}
		
		// 2. 향상된 for문을 사용하여 배열 내의 모든 데이터 출력
		for(String name : names) {
			// 우변의 String[] 타입 names 에서 데이터 좌변 String name 에 저장 반복
			// => 별도로 변수에 저장하는 작업이 필요없음
			System.out.println(name);
		}
		
	}

}


















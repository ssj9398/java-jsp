
public class Ex4 {

	public static void main(String[] args) {
		/*
		 * java.lang.Object 클래스
		 * - 모든 클래스들의 최상위 클래스
		 *   => Object 클래스의 모든 멤버는 다른 모든 클래스에서 사용 가능
		 * 
		 */
		Person p = new Person("홍길동", 20);
		// 1. getClass() : 대상 객체의 클래스 타입 리턴
		System.out.println(p.getClass()); // 대상 객체의 클래스 타입을 Class 객체로 리턴
		System.out.println(p.getClass().getName()); // 대상 객체의 클래스 타입 이름 리턴
		
		// 2. hashCode() : 대상 객체의 해쉬코드 값을 정수로 리턴
		// => 객체가 생성되어 있는 메모리 공간(Heap)의 주소값
		System.out.println(p.hashCode());
		
		// 3. toString() : 대상 객체의 정보를 문자열로 변환하여 리턴
		System.out.println(p.toString());
		// => 일반 객체의 toString() 메서드 실행 결과는
		//    클래스명 + "@" + hashCode()의16진수변환결과 실행결과와 같다
		// 출력문에서 toString() 메서드 생략하고, 객체만 출력해도 toString() 결과와 동일
		// => 즉, 출력문에서 toString() 메서드는 생략 가능하다!
		System.out.println(p);
		
//		String obj = p; // 객체를 문자열 변수에 저장 불가
		String obj = p.toString();
		
		
		// 4. equals() : 대상 객체와 현재 객체가 같은지를 비교
		//               (기본적으로 객체의 주소값을 비교)
		Person p2 = new Person("이순신", 44);
		if(p.equals(p2)) { // p 와 p2 가 같은지 비교
			System.out.println("p 와 p2 는 같다!");
		} else {
			System.out.println("p 와 p2 는 다르다!");
		}
		
	}

}

class Person {
	String name;
	int age;
	
	public Person(String name, int age) {
		this.name = name;
		this.age = age;
	}
	
}














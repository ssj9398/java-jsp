
public class Ex5 {

	public static void main(String[] args) {
		/*
		 * Object 클래스의 equals() 메서드 특징
		 * - 두 객체에 대한 동등비교 수행
		 * - 기본적으로 두 객체의 주소값을 비교하므로 동등비교연산자(==) 사용 결과 동일
		 * - 일반적으로 '두 객체가 같다' 라는 의미는, 두 객체의 데이터(멤버변수 값)가
		 *   동일하다는 의미로 사용되는 것이 대부분이다.
		 *   => 따라서, 클래스 정의 시 equals() 메서드를 오버라이딩하여
		 *      해당 객체 내의 모든 멤버변수 비교를 통해 동등여부를 리턴하도록 해야함
         * - 자바에서 제공하는 대부분의 API 는 equals() 메서드가
		 *   오버라이딩되어 있으므로 객체간의 실제 데이터 비교를 쉽게 할 수 있다.
		 *   (ex. String, ArrayList 등) 
		 */
		Person p1 = new Person("홍길동", 20);
		Person p2 = new Person("홍길동", 20);
		if(p1 == p2) {
			// 두 객체에 대한 동등비교 연산은 주소값에 대한 비교를 수행함
			System.out.println("p1, p2 주소값이 같다!");
		} else {
			System.out.println("p1, p2 주소값이 다르다!");
		}
		
		if(p1.equals(p2)) {
			// Object 클래스의 equlas() 메서드는 동등비교연산과 동일함(= 주소값 비교)
			System.out.println("p1, p2 주소값이 같다!");
		} else {
			System.out.println("p1, p2 주소값이 다르다!");
		}
		
		System.out.println("-----------------");
		
//		Person p1 = new Person("홍길동", 20);
//		Person p2 = p1; // p1 인스턴스의 주소값을 p2 에 저장(복사)
//		if(p1 == p2) {
//			// 두 객체에 대한 동등비교 연산은 주소값에 대한 비교를 수행함
//			System.out.println("p1, p2 주소값이 같다!");
//		} else {
//			System.out.println("p1, p2 주소값이 다르다!");
//		}
//		
//		if(p1.equals(p2)) {
//			// Object 클래스의 equlas() 메서드는 동등비교연산과 동일함(= 주소값 비교)
//			System.out.println("p1, p2 주소값이 같다!");
//		} else {
//			System.out.println("p1, p2 주소값이 다르다!");
//		}
		
		System.out.println("-----------------");
		
		Person5 p3 = new Person5("홍길동", 20);
		Person5 p4 = new Person5("홍길동", 20);
		
		if(p3 == p4) {
			// 두 객체에 대한 동등비교 연산은 주소값에 대한 비교를 수행함
			System.out.println("p3, p4 주소값이 같다!");
		} else {
			System.out.println("p3, p4 주소값이 다르다!");
		}
		
		// equals() 메서드에 대한 오버라이딩 수행 시
		// 주소값이 아닌 실제 데이터에 대한 비교를 수행함
		if(p3.equals(p4)) {
			System.out.println("p3, p4 실제값(데이터)이 같다!");
		} else {
			System.out.println("p3, p4 실제값(데이터)이 다르다!");
		}
		
	}

}

class Person5 {
	String name;
	int age;
	
	public Person5(String name, int age) {
		this.name = name;
		this.age = age;
	}

	// Object 클래스의 equals() 메서드를 오버라이딩 하여
	// 모든 멤버변수(name, age)가 같은지 비교한 후 같으면 true, 아니면 false 리턴
//	@Override
//	public boolean equals(Object obj) {
//		boolean result = false;
//		// Person5 타입 인스턴스가 파라미터로 전달될 때 Object 타입으로 업캐스팅 일어남
//		// => Person5 타입 멤버에 접근하려면 다시 다운캐스팅 필수!
//		//    instanceof 연산자를 사용하여 Person5 타입으로 다운캐스팅 가능 여부 판별
//		if(obj instanceof Person5) {
//			// obj 를 Person5 타입으로 다운캐스팅 수행
//			Person5 p = (Person5)obj;
//			
//			if(name.equals(p.name) && age == p.age) { // 멤버변수 name, age 비교
//				result = true;
//			}
//		}
//		
//		return result;
//	}
	
	
	// equals() 메서드에 대한 자동 오버라이딩 : Alt + Shift + S -> H
	// => 전체 비교를 모두 자동으로 수행하므로 추가할 작업이 없다!
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Person5 other = (Person5) obj;
		if (age != other.age)
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		return true;
	}
	
	
}




















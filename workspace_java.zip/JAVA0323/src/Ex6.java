import java.util.ArrayList;

public class Ex6 {

	public static void main(String[] args) {
		/*
		 * Object 클래스의 toString() 메서드
		 * - 객체 정보를 문자열(String) 로 변환하여 리턴하는 메서드
		 * - 기본적으로 객체(인스턴스)의 클래스명과 참조값(주소값)을 문자열로 리턴함
		 *   => 일반적으로 객체의 정보란 객체의 모든 데이터(멤버변수 값)를 의미하므로
		 *   toString() 메서드를 오버라이딩하여 모든 멤버변수 값을 문자열로 결합 후
		 *   리턴하도록 해야한다!
		 * - 자바에서 제공하는 대부분의 API 는 toString() 메서드가
		 *   오버라이딩되어 있으므로 객체 정보(데이터)를 쉽게 출력 가능
		 *   (ex. String, ArrayList 등)
		 */
		
		// toString() 메서드가 오버라이딩 되어있지 않은 Person 클래스의 경우
		// 클래스명과 참조값이 문자열로 결합되어 리턴됨
		// => p.getClass().getName() + "@" + Integer.toHexString(p.hashCode()) 형태 리턴 
		Person p = new Person("홍길동", 20);
		System.out.println(p.toString()); // Person@15db9742 출력됨
		System.out.println(p);
		// -----------------------------------------------------
		// toString() 메서드를 오버라이딩 한 Person6 클래스의 경우
		// => 이름(name) 과 나이(age) 가 결합되어 리턴됨
		Person6 p2 = new Person6("홍길동", 20);
		System.out.println(p2.toString()); // 이름 : 홍길동, 나이 : 20 출력됨
		System.out.println(p2);
		
		
		System.out.println("---------------------------------");
		
		// toString() 오버라이딩 된 클래스 예
		String str = "홍길동";
		System.out.println(str); // toString() 메서드 호출 코드 생략됨
		System.out.println(str.toString());
		
		ArrayList list = new ArrayList();
		list.add("홍길동");
		list.add("이순신");
		System.out.println(list.toString());
		System.out.println(list); // toString() 메서드 호출 코드 생략됨
		
	}

}

class Person6 {
	String name;
	int age;
	
	public Person6(String name, int age) {
		this.name = name;
		this.age = age;
	}


//	@Override
//	public String toString() {
//		// toString() 메서드를 오버라이딩 하는 경우
//		// 모든 멤버변수를 문자열로 결합하여 리턴
//		return "이름 : " + name + ", 나이 : " + age;
//	}
	
	// toString() 메서드 오버라이딩 자동 생성 단축키 : Alt + Shift + S -> S
	@Override
	public String toString() {
		return "Person6 [name=" + name + ", age=" + age + "]";
	}
	
}




















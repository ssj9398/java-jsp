
public class Test3 {

	public static void main(String[] args) {
		AnnotationEx ae = new AnnotationEx();
		ae.normalMethod(); // 일반메서드는 아무런 표시가 없지만
		ae.deprecatedMethod(); // Deprecated 어노테이션 메서드는 가운데 줄 표시됨
	}

}

class SuperClass {
	public void method() {}
}

class AnnotationEx extends SuperClass {

	// @Override 어노테이션은 오버라이딩 메서드를 표시하기 위한 어노테이션으로
	// 오버라이딩 규칙에 맞지 않을 경우 컴파일 오류 발생함!
	@Override
	public void method() {}
	
	// 만약, 오버라이딩이 아닌 오버로딩을 수행하거나 할 경우 오류 발생
//	@Override
//	public void method(int a) {} // 오류 발생!
	
	
	// @Deprecated 어노테이션은 사용 가능한 메서드이지만
	// 새로운 기능의 다른 메서드로 대체되었거나, 보안상의 이유로 사용을 추천하지 않는
	// 메서드를 표시할 때 사용하는 어노테이션
	public void normalMethod() {}
	
	@Deprecated
	public void deprecatedMethod() {} // deprecate 처리된 메서드
	
}











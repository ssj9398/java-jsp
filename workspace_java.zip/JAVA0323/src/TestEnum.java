
public enum TestEnum { // enum 타입 정의 시 class 대신 enum 키워드를 사용
	// enum 타입 내의 상수를 정의할 때는 상수를 그대로 나열하면 됨
	// => 기본적으로 public static final 상수와 동일한 형태로 접근 가능하며
	//    대신, 해당 상수에 값을 초기화할 수 없다!
	상수1, 상수2, CONSTANT3
}


public class Ex {

	public static void main(String[] args) {
		/*
		 * java.lang.String 클래스
		 * - 문자열을 관리하는 클래스
		 *   => 내부적으로 char[] 타입으로 문자 하나하나를 자동으로 저장하여 관리
		 * - final 클래스이므로 상속 불가
		 * - new 키워드를 사용한 문자열 할당과, 리터럴을 직접 할당하는 방법으로 구분
		 *   => 특별한 경우 외에는 기본적으로 리터럴 직접 할당 방법을 사용함
		 *      (저장공간을 절약할 수 있음)
		 * - 불변성을 가지므로, 문자열을 변경하더라도 원본 문자열은 그대로 유지되고,
		 *   변경된 문자열을 새로운 공간에 할당한다.
		 */
		// 1. 리터럴을 사용하여 직접 문자열을 생성하는 방법
		// => 상수 풀(Constant Pool)에 문자열을 저장하는데
		//    저장하기 전 동일한 문자열이 존재하는지 검사한 뒤
		//    동일한 문자열이 존재할 경우 해당 문자열 주소를 리턴하고 아니면 새로 생성
		String s1 = "Hello"; // 동일한 문자열이 없으므로 새로 생성
		String s2 = "Hello"; // s1 에 해당하는 문자열이 동일하므로 같은 주소값을 사용
		
		if(s1 == s2) { // 참조변수의 동등비교 연산 = 주소값 비교
			System.out.println("s1, s2 주소값이 같다!");
		} else {
			System.out.println("s1, s2 주소값이 다르다!");
		}
		
		if(s1.equals(s2)) { // String 클래스의 equals() 메서드 사용 = 실제값(문자열) 비교 
			System.out.println("s1, s2 실제값(문자열)이 같다!");
		} else {
			System.out.println("s1, s2 실제값(문자열)이 다르다!");
		}
		
		System.out.println("------------------------------------");
		
		// String 클래스의 객체 생성 문법을 사용(new 키워드 사용)하여 문자열 생성
		// => new 키워드를 사용할 때마다 무조건 새로운 Heap 공간에 문자열 생성됨
		String s3 = new String("Hello"); // 힙 공간에 "Hello" 문자열 저장 공간 생성
		String s4 = new String("Hello"); // 동일 문자열 존재 여부와 상관없이 새로 생성 
		
		if(s3 == s4) { // 참조변수의 동등비교 연산 = 주소값 비교
			System.out.println("s3, s4 주소값이 같다!");
		} else {
			System.out.println("s3, s4 주소값이 다르다!");
		}
		
		if(s3.equals(s4)) { // String 클래스의 equals() 메서드 사용 = 실제값(문자열) 비교 
			System.out.println("s3, s4 실제값(문자열)이 같다!");
		} else {
			System.out.println("s3, s4 실제값(문자열)이 다르다!");
		}
		
	}

}





















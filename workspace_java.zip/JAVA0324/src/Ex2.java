
public class Ex2 {

	public static void main(String[] args) {
		/*
		 * String 클래스의 주요 메서드
		 */
		String s1 = "Hello, World!";
		String s2 = "                ITWILL    부산  교육센터            ";
		String s3 = "김태희/전지현/송혜교";
		
		System.out.println("s1 문자열 길이 : " + s1.length());
		// => "Hello, World!" 의 길이가 13이므로, 인덱스는 0 ~ 12번까지 사용됨
		
		// equals() 메서드는 대소문자를 구별하여 비교하지만
		// equalsIgnoreCase() 메서드는 대소문자 구별없이 비교
		System.out.println("s1.equals() : " + s1.equals("HELLO, WORLD!"));
		System.out.println("s1.equalsIgnoreCase() : " + s1.equalsIgnoreCase("HELLO, WORLD!"));
		
		// charAt() : 특정 인덱스에 위치한 문자 1개 리턴
		System.out.println("s1.charAt() : " + s1.charAt(7)); // 7번 인덱스(8번째 문자) 리턴
		
		// indexOf() : 특정 문자열을 탐색하여 해당 문자열이 존재할 경우 시작인덱스 리턴
		System.out.println("World 문자열 위치 : " + s1.indexOf("World"));
		System.out.println("! 문자 위치 : " + s1.indexOf('!')); // char 타입 사용도 가능
		System.out.println("Java 문자열 위치 : " + s1.indexOf("Java")); // 없으면 -1 리턴
		
		// lastIndexOf() : 특정 문자열을 "뒤에서부터" 탐색하여 존재하면 인덱스 리턴
		System.out.println("문자 o 위치 indexOf() : " + s1.indexOf("o")); // 4
		System.out.println("문자 o 위치 lastIndexOf() : " + s1.lastIndexOf("o")); // 8
		
		// replace() : 특정 문자 또는 문자열 치환 = 찾아서 바꾸기
		// => 해당되는 문자 또는 문자열을 모두 치환 
		System.out.println("s1.replace() : " + s1.replace('o', '0')); 
		System.out.println("s1.replace() : " + s1.replace("World", "Java World"));
		
		// concat() : 문자열 결합
		System.out.println("s1.concat() : " + s1.concat(" 입니다!"));
		
		// substring() : 특정 문자열 추출
		// => 시작인덱스만 지정할 경우 시작인덱스 ~ 끝까지 추출
		// => 시작인덱스, 끝인덱스 지정할 경우 시작인덱스 ~ 끝인덱스-1 까지 추출
		System.out.println("s1.substring(7, 11) : " + s1.substring(7, 11)); // 7 ~ 10까지만 추출
		System.out.println("s1.substring(7, 12) : " + s1.substring(7, 12)); // 7 ~ 11까지 추출
		System.out.println("s1.substring(7) : " + s1.substring(7)); // 7 ~ 끝까지 추출
		
		// toUpperCase() : 모든 영문자를 대문자로 변환
		System.out.println("s1.toUpperCase() : " + s1.toUpperCase());
		
		// toLowerCase() : 모든 영문자를 소문자로 변환
		System.out.println("s1.toLowerCase() : " + s1.toLowerCase());
		
		// trim() : 문자열 앞 뒤의 공백 제거(문자열 사이의 공백은 제거하지 않는다!)
		System.out.println("s2.trim() : " + s2.trim() + " 확인!");
		
		// split() : 문자열을 주어진 정규표현식을 사용하여 분리
		// => 기준이 되는 문자를 구분자 또는 분리자라고 하며
		//    분리된 문자열들은 String[] 타입으로 각각 저장됨
		// => ex) "김태희/전지현/송혜교" 문자열을 "/" 기호를 기준으로 분리
		String[] resultArr = s3.split("/");
		for(String str : resultArr) {
			System.out.println(str);
		}
		// 또는
//		for(int i = 0; i < resultArr.length; i++) {
//			System.out.println(resultArr[i]);
//		}
		
		// String.format() : 형식 지정 문자(%로 시작하는 문자)를 사용하여 
		//                   특정 포맷을 적용한 문자열을 생성 = printf() 와 사용법 동일
		String formatString = String.format(
					"이름 : %s, 나이 : %d, 키 : %.1f", "홍길동", 20, 180.34);
		System.out.println(formatString);
		
		
		System.out.println("-----------------");
		// 아무리 문자열 변경을 수행하더라도 String 클래스 문자열 원본은 그대로 유지됨
		System.out.println(s1);
		System.out.println(s2);
		System.out.println(s3);
		
		
	}

}
































public class Ex3 {

	public static void main(String[] args) {
		/*
		 * StringBuffer & StringBuilder 클래스
		 * - 문자열 조작이 빈번할 경우 사용하는 클래스
		 * - String 클래스와 아무런 관계가 없는 클래스(상속 관계 X)
		 * - 내부적으로 임시 저장 공간인 버퍼(Buffer)를 사용하여 문자열을 관리
		 *   => 버퍼의 문자열을 직접 조작하므로 연산 과정에서 새로운 문자열 생성 X
		 * - toString() 메서드가 오버라이딩 되어 있기 때문에 문자열 출력 가능
		 * - StringBuffer 클래스는 멀티쓰레딩 환경을 지원하며 무겁고,
		 *   StringBuilder 클래스는 멀티쓰레딩 환경을 지원하지 않으며 가볍다.
		 * - 기본적인 사용법은 거의 유사함
		 */
		
		// 객체 생성 시 문자열을 사용하여 객체를 초기화하는 경우
		StringBuffer buffer = new StringBuffer("Hello, World!");
		System.out.println(buffer); // 출력 시 toString() 메서드 생략 가능
		String str = buffer.toString(); // 저장 시 toString() 메서드 생략 불가
		
		StringBuffer buffer2 = new StringBuffer();
		System.out.println(buffer2);
		
		buffer2.append("Hello"); // 버퍼에 문자열 추가(기존 문자열 뒤에 결합)
		System.out.println(buffer2);
		
		buffer2.append(", World!"); // 버퍼에 문자열 추가(기존 문자열 뒤에 결합)
		System.out.println(buffer2);
		
		buffer2.insert(7, "Java "); // 버퍼 문자열 특정 인덱스에 문자열 삽입
		System.out.println(buffer2);
		
		buffer2.reverse(); // 문자열 반전(순서 뒤집기)
		System.out.println(buffer2);
		
		StringBuffer buffer3 = new StringBuffer("A");
		buffer3.append("B").append("C").append("D");
		System.out.println(buffer3);
		
	}

}



















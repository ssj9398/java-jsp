
public class Ex4 {

	public static void main(String[] args) {
		/*
		 * java.lang.Math 클래스
		 * - 수학 관련 여러가지 기능을 제공하는 클래스
		 * - final 클래스로 상속 불가
		 * - 모든 멤버는 static 이므로, 클래스명만으로 접근 가능
		 * 
		 */
		
		System.out.println("파이값 : " + Math.PI);
		
		System.out.println("-5 의 절대값 : " + Math.abs(-5));
		System.out.println("3, 4 중 최대값 : " + Math.max(3, 4));
		System.out.println("3, 4 중 최소값 : " + Math.min(3, 4));
		System.out.println("정수 4의 제곱근 : " + Math.sqrt(4));
		System.out.println("정수 2의 10승 : " + Math.pow(2, 10));
		
		System.out.println("실수 3.14 의 소수점 첫째자리 반올림 : " + Math.round(3.14));
		System.out.println("실수 3.5 의 소수점 첫째자리 반올림 : " + Math.round(3.5));
		
		/*
		 * 난수 발생을 위한 Math.random() 메서드ㄴ
		 * - double 타입 범위 내의 무작위 숫자(난수) 발생시키는 메서드
		 *   범위 : 0.0 <= x < 1.0
		 * - 0 <= n < X 까지의 정수형 난수 공식 : (int)(Math.random() * X)
		 * - 1 <= n <= X 까지의 정수형 난수 공식 : (int)(Math.random() * X)
		 */
		System.out.println("double 타입 범위 난수 : " + Math.random());
		
		for(int i = 1; i <= 10; i++) {
//			System.out.println(Math.random());
//			System.out.println("0 <= x < 5 범위 난수 : " + (int)(Math.random() * 5));
			System.out.println("1 <= x <= 5 범위 난수 : " + (int)(Math.random() * 5 + 1));
		}
		
		
	}

}





















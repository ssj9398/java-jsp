
public class Test2 {

	public static void main(String[] args) {
		// String 클래스 연습
		// 1. String 타입 변수 jumin 에서 주민등록번호를 통해 남/여 판별 후 출력
		// => 뒷부분 첫번째 자리 숫자가 1 또는 3이면 남성! 2 또는 4이면 여성! 출력
		String jumin = "001010-5344556";
		if(jumin.charAt(7) == '1' || jumin.charAt(7) == '3') {
			System.out.println("남성입니다!");
		} else if(jumin.charAt(7) == '2' || jumin.charAt(7) == '4') {
			System.out.println("여성입니다!");
		} else {
			System.out.println("잘못된 주민등록번호입니다!");
		}
		
		System.out.println("-----------------------------");
		
		// 2. 이메일 주소가 저장된 String 타입 변수 email 에서
		// '@' 기호를 기준으로 계정명과 도메인을 분리해서 출력
		// ex) ytlee@itwillbs.co.kr 일 경우
		//     계정명 : ytlee     도메인 : itwillbs.co.kr
		String email = "ytlee@itwillbs.co.kr";
		
		int baseIndex = email.indexOf("@"); // '@' 기호 인덱스 저장
		System.out.println("기준 인덱스 번호 : " + baseIndex);
		
		// 계정명 저장
		// => 기준인덱스('@')를 기준으로 처음부터 '@' 기호 인덱스까지 지정하면
		//    '@' 기호의 앞 문자까지 추출됨(끝인덱스-1 까지 추출되므로)
		String user = email.substring(0, baseIndex);
//		System.out.println("계정명 : " + user);
		
		// 도메인 저장
		// => 기준인덱스('@')를 시작점으로 하여 + 1 한 위치 도메인의 첫글자 ~ 끝까지
		String domain = email.substring(baseIndex + 1); 
		System.out.println("계정명 : " + user + ", 도메인 : " + domain);
		
		System.out.println("------------------------------");
		
		String hp = "010-1234-5678";
		// 전화번호 뒷자리를 "****" 로 대체
//		String last4 = hp.substring(9); // hp.substring(9, hp.length()) 와 동일
//		System.out.println("추출된 문자열 : " + last4);
//		String masked = hp.replace(last4, "****");
//		System.out.println(masked);
		
		// 전화번호 가운데자리를 "****" 로 대체
		// 단, 가운데자리 번호가 3자리 또는 4자리 모두 대체되어야 함
//		String centerNum = hp.substring(4, 8); // 인덱스가 정해져있을 경우
		
		// 인덱스가 정해져 있지 않을 경우
		// 앞쪽부터 탐색한 '-' 기호의 인덱스 다음 숫자부터
		// 뒷쪽부터 탐색한 '-' 기호까지 지정
		String centerNum = hp.substring(hp.indexOf('-') + 1, hp.lastIndexOf('-'));
		System.out.println(centerNum);
		
		// 만약, 가운데 번호 숫자 3자리, 4자리에 따라 * 기호 갯수를 달리할 경우
		String mask = "";
		for(int i = 0; i < centerNum.length(); i++) {
			mask += "*";
		}
		
		String masked = hp.replace(centerNum, mask);
		System.out.println(masked);
	}

}




















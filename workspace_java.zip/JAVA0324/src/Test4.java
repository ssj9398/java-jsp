
public class Test4 {

	public static void main(String[] args) {
		// Math 클래스의 활용 연습
		// 1. 실수 num 의 소수점 둘째자리 반올림 수행
		double num = 3.44;
		// 1) 3.45 를 34.5 로 변환하여 소수점 둘째자리 숫자를 첫째자리 숫자로 이동
		// 2) 34.5 를 Math.round() 메서드를 통해 반올림 수행 => 35
		// 3) 35 를 10.0 으로 나누어서 다시 3.5 로 되돌림
		System.out.println(Math.round(num * 10) / 10.0);
		
		System.out.println("-----------------------------");
		
		// 2. Math.random() 메서드를 사용한 난수 생성
		// 1) 1 ~ 45 사이의 난수 6개 생성 및 출력(중복 포함)
		for(int i = 1; i <= 6; i++) {
			System.out.println((int)(Math.random() * 45 + 1));
		}
		
		// 2) 주사위 2개를 던져 두 주사위의 합 출력 => 5번 반복
		//    주사위는 각각 int형 변수 dice1, dice2 로 선언하여 1 ~ 6 사이의 난수 저장
		//    ex) 1 + 2 = 3
		//        6 + 6 = 12
		for(int i = 1; i <= 5; i++) {
			int dice1 = (int)(Math.random() * 6 + 1);
			int dice2 = (int)(Math.random() * 6 + 1);
			System.out.println(dice1 + " + " + dice2 + " = " + (dice1 + dice2));
		}
		
		
		
		
	}

}

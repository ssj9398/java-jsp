import java.util.Arrays;

public class Test5 {

	public static void main(String[] args) {
		/*
		 * [ 문제 ] 로또 번호 생성 프로그램 만들기
		 * 1 ~ 45 사이의 중복되지 않는 난수 6개를 생성하여 배열에 저장한 후, 
		 * 임의로 지정된 1등 당첨번호와 비교하여 일치하는 개수를 출력하는 프로그램
		 * 
		 * [ 출력 결과(예시) ]
		 * 나의 로또 번호 : 10, 15, 30, 35, 37, 40
		 * 1등 당첨번호 : 1, 10, 15, 19, 30, 45
		 * 일치하는 번호 개수 : 3개
		 * 
		 * [ 프로그램 작성 조건 ]
		 * 1. 난수 6개(로또번호)를 저장할 배열명 : myLotto
		 *    => 중복된 숫자가 저장되지 않도록 중복 제거 필수!
		 * 2. 1등 당첨번호를 저장할 배열명 : thisWeekLotto
		 *   (저장할 숫자 : 10, 19, 1, 30, 45, 15)
		 * 3. 화면에 출력할 나의 로또 번호와 1등 당첨번호는 오름차순으로 정렬한 뒤 출력
		 *    => Arrays.sort() 메서드 활용
		 * 4. 난수 발생은 Math.random() 메서드 사용
		 */
		
		int[] myLotto = new int[6]; // 번호 6개 저장할 배열
		int[] thisWeekLotto = {10, 19, 1, 30, 45, 15}; // 1등 당첨번호
		
		// 1. for문을 사용하여 중복된 숫자 발생 시 제어변수 감소시키는 방법
//		for(int i = 0; i < myLotto.length; i++) {
//			// 난수 생성
//			int rNum = (int)(Math.random() * 45 + 1);
//			
//			myLotto[i] = rNum; // 현재 배열 위치에 난수 저장
//			// => 만약 중복된 숫자가 발견되면 i값을 1 감소시키므로
//			//    다시 현재 위치에 새 난수를 저장하게 된다!
//			
//			// 기존에 저장된 myLotto 배열 내의 숫자와 새 난수가 중복인지 판별
//			// => 안쪽 for문을 생성하여 생성된 난수를 배열 내의 숫자와 비교
//			for(int j = 0; j < i; j++) { // 최대 반복 횟수를 저장된 숫자 갯수로 지정
//				if(rNum == myLotto[j]) {
//					// 동일한(중복된) 번호가 존재할 경우 i 반복횟수 1 감소시킴
//					i--;
//					System.out.println("중복 번호 확인! - " + rNum);
//					break; // 중복 체크 후에 더 이상의 반복 진행 없이 안쪽 for문 종료
//				}
//			}
//			
//		}
		
		// 2. while 문을 사용하여 저장되는 숫자 갯수를 체크하면서
		// 중복된 숫자가 없을 때만 난수를 저장하는 방법
		int count = 0; // 현재 저장된 난수 갯수 체크 변수
		while(count < 6) { // 저장된 난수 갯수가 6개 미만일 동안 반복
			int rNum = (int)(Math.random() * 45 + 1); // 난수 발생
			
			boolean isDuplicate = false; // 중복 여부 체크 변수
			// for문을 사용하여 중복 체크한 뒤 중복이면 isDuplicate = true 로 변경
			for(int j = 0; j < count; j++) { // 반복 횟수를 저장 숫자 갯수 -1 까지 지정
				if(rNum == myLotto[j]) { // 중복 여부 체크 
					isDuplicate = true;
//					System.out.println("중복 번호 확인! - " + rNum);
					break;
				}
			}
			
			// 중복 체크 변수가 false 일 때만 난수를 배열에 저장 후 카운트 증가시킴
			if(!isDuplicate) {
				myLotto[count] = rNum; // 난수 저장 후
				count++; // 카운트 1 증가시킴
			}
			
		}
			
		// ------------ 로또 번호 저장 과정과 무관하게 동일한 부분 ----------------
		// 배열에 저장된 번호 정렬
		Arrays.sort(myLotto);
		Arrays.sort(thisWeekLotto);
		
		// 자신의 로또 번호 출력
		System.out.print("나의 로또 번호 : ");
		for(int i = 0; i < myLotto.length; i++) {
			System.out.print(myLotto[i] + " ");
		}
		System.out.println();
			
		// 1등 당첨번호 출력
		System.out.print("1등 당첨번호 : ");
		for(int i = 0; i < thisWeekLotto.length; i++) {
			System.out.print(thisWeekLotto[i] + " ");
		}
		System.out.println();
		
		
		// 일치하는 번호 갯수 카운팅 후 출력
		int sameCount = 0;
		
		// 자신의 로또 번호와 1등 당첨번호를 각각 비교하여 같으면 카운팅 증가시킴
		for(int i = 0; i < myLotto.length; i++) { 
			for(int j = 0; j < thisWeekLotto.length; j++) {
				if(myLotto[i] == thisWeekLotto[j]) {
					sameCount++;
				}
			}
		}
		
		System.out.println("일치하는 번호 개수 : " + sameCount + "개");
		
	}

}























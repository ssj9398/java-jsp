
public class Ex {

	public static void main(String[] args) {
		/*
		 * Wrapper 클래스
		 * - 기본 데이터타입 8개에 대응하는 8개의 클래스
		 * - 기본 데이터타입을 참조 데이터타입(객체)로 변환하여
		 *   객체가 제공하는 다양한 기능(메서드)을 활용할 수 있도록 도와주는 클래스
		 * - Wrapper 클래스에는 상수와 여러 메서드가 제공되므로
		 *   기본 데이터타입에 대한 다양한 작업을 쉽게 수행할 수 있도록 도와줌
		 */
		
		// Wrapper 클래스의 각종 상수들
		System.out.println("byte 타입 최소값 : " + Byte.MIN_VALUE);
		System.out.println("byte 타입 최대값 : " + Byte.MAX_VALUE);
		System.out.println("short 타입 최소값 : " + Short.MIN_VALUE);
		System.out.println("short 타입 최소값 : " + Short.MAX_VALUE);
		System.out.println("int 타입 최소값 : " + Integer.MIN_VALUE);
		System.out.println("int 타입 최소값 : " + Integer.MAX_VALUE);
		System.out.println("int 타입 바이트 : " + Integer.BYTES);
		System.out.println("int 타입 사이즈 : " + Integer.SIZE);
		System.out.println("long 타입 최소값 : " + Long.MIN_VALUE);
		System.out.println("long 타입 최소값 : " + Long.MAX_VALUE);
		
		System.out.println("float 타입 최소값 : " + Float.MIN_VALUE);
		System.out.println("float 타입 최소값 : " + Float.MAX_VALUE);
		System.out.println("double 타입 최소값 : " + Double.MIN_VALUE);
		System.out.println("double 타입 최소값 : " + Double.MAX_VALUE);
		
		System.out.println("char 타입 최소값 : " + (int)Character.MIN_VALUE);
		System.out.println("char 타입 최소값 : " + (int)Character.MAX_VALUE);
		
		System.out.println("-----------------------------------");
		
		// 기본 데이터타입 변수에 정수를 저장하는 방법
		int n1 = 10;
		int n2;
		
		// 기본 데이터타입 변수의 값을 출력하는 방법
		System.out.println("n1 = " + n1);
		
		// Wrapper 클래스 타입 객체에 정수를 저장하는 방법
		// => 생성자에 정수 데이터 또는 문자열로 된 정수를 전달
		Integer num1;
		Integer num2 = new Integer(20); // 정수 20을 Integer 타입 객체로 생성
//		Integer num2 = new Integer("20"); // 문자열 20을 Integer 타입 객체로 생성
		// => 단, 정수형이 아닌 문자열일 경우 오류 발생!
		
		// Wrapper 클래스 타입 객체의 값을 출력하는 방법
		// => toString() 메서드가 오버라이딩 되어 있음
//		System.out.println("num2 = " + num2.toString());
		System.out.println("num2 = " + num2); // toString() 메서드 생략 가능
		
		/*
		 * 오토 박싱(Auto Boxing) 과 오토 언박싱(Auto Unboxing)
		 * - 기본 데이터타입과 참조 데이터타입은 메모리 공간이 다르고 성격이 다르므로
		 *   서로 호환이 불가능한 타입으로 취급됨(구조가 다름)
		 * - 따라서, 상호간의 변환을 위해서는 Wrapper 클래스를 활용해야함
		 *   기본 데이터타입(스택) -> 참조 데이터타입(힙) 으로 변환 : Boxing(박싱)
		 *   참조 데이터타입(힙) -> 기본 데이터타입(스택) 으로 변환 : Unboxing(언박싱)
		 *   => 원래는 박싱에 new 키워드를 통한 객체 생성 방법을 사용하고,
		 *      언박싱에 Wrapper 클래스 객체의 XXXValue() 메서드 호출을 통한 방법 사용
		 *   => JDK 1.5(Java 5) 부터는 상호 변환 과정을 생략해도
		 *      컴파일러에 의해 자동으로 변환되는 오토 박싱, 오토 언박싱이 지원됨
		 */
		
		// 1. 오토 박싱(기본 데이터타입(Stack) -> 참조 데이터타입(Heap))
//		num1 = new Integer(n1); // 기존의 박싱 문법(객체 생성을 통해 기본형 전달)
		num1 = n1; // 오토 박싱이 지원되므로 바로 대입 가능(자동 변환 수행됨)
		System.out.println("n1 = " + n1 + ", num1 = " + num1);
		// 오토 박싱 후에는 int -> Integer 타입으로 변환되었으므로
		// Integer 객체에서 지원하는 다양한 메서드나 상수 등을 활용 가능
		
		
		// 2. 오토 언박싱(참조 데이터타입(Heap) -> 기본 데이터타입(Stack))
		// 기존의 언박싱 문법
//		n2 = num2.intValue(); // Wrapper 클래스 객체의 XXXValue() 메서드로 변환
		n2 = num2; // 오토 언박싱이 지원되므로 바로 대입 가능(자동 변환 수행됨)
		System.out.println("n2 = " + n2 + ", num2 = " + num2);
		// 오토 언박싱 후에는 Integer -> int 타입으로 변환되었으므로
		// 기본 데이터타입으로 할 수 있는 작업들을 수행 가능
		
		
		int num3 = n1 + num2; // 기본형과 참조형간의 연산도 가능
		// Wrapper 클래스 타입(참조형) 객체를 기본형으로 변환 후 연산 수행
		System.out.println(num3);
		
		if(n1 == num1) { // 동등비교연산자로 기본형과 참조형 비교도 가능
			System.out.println(n1 + ", " + num1 + " : 같은 데이터!");
		} else {
			System.out.println(n1 + ", " + num1 + " : 다른 데이터!");
		}
		
		if(num1.equals(n1)) { // equals() 메서드로 참조형과 기본형 비교 가능
			System.out.println(n1 + ", " + num1 + " : 같은 데이터!");
		} else {
			System.out.println(n1 + ", " + num1 + " : 다른 데이터!");
		}
		
		
		// 주의!! Wrapper 클래스 타입 객체 간의 비교 시에는 반드시 equals() 사용!!
		Integer i1 = new Integer(100);
		Integer i2 = new Integer(100);
		
		if(i1 == i2) { // 동등비교연산시에는 주소값이 다르므로 false 리턴됨
			System.out.println(i1 + ", " + i2 + " : 같은 데이터!");
		} else {
			System.out.println(i1 + ", " + i2 + " : 다른 데이터!");
		}
		
		if(i1.equals(i2)) { // equals() 메서드가 오버라이딩 되어 있으므로 비교 가능
			System.out.println(i1 + ", " + i2 + " : 같은 데이터!");
		} else {
			System.out.println(i1 + ", " + i2 + " : 다른 데이터!");
		}
		
	}

}























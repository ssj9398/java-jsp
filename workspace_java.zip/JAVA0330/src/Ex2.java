
public class Ex2 {

	public static void main(String[] args) {
		/*
		 * 문자열 -> 기본형으로 변환
		 * - 주로 웹이나 어플리케이션의 입력창에서 수치데이터를 입력받을 경우
		 *   실제 데이터 타입과 달리 문자열 형태로 전달되는 것이 일반적이다.
		 *   따라서, 문자열 형태의 데이터를 수치데이터로 변환하는 작업이 빈번
		 * 
		 * < 기본 문법 >
		 * Wrapper클래스명.parseXXX(문자열데이터)
		 * => parseXXX() 메서드의 XXX 은 변환할 기본형의 데이터타입 이름
		 *    ex) 문자열로 전달받은 변수 strNum("20")을 int형 변수에 변환하여 저장하는 경우
		 *        int num = Integer.parseInt(strNum);
		 *    ex2) 문자열로 전달받은 변수 strNum("20.0")을 double형 변수에 변환하여 저장하는 경우
		 *        double num = Double.parseDouble(strNum);  
		 * 
		 */
		String strNum = "20"; // 문자열로 전달받은 정수 데이터 20
		// int형 변수에 정수 20으로 변환하여 저장
//		int num = strNum; // 형변환 연산자를 사용할 수도 없다!
		Integer num = Integer.parseInt(strNum); // 리턴타입 int형 -> Integer로 오토박싱
		int n = Integer.parseInt(strNum); // 리턴타입 int형 그대로 저장
		
		
		strNum = "20.0";
//		int n2 = Integer.parseInt(strNum); // NumberFormatException 발생
		// => 20.0 실수형 데이터이므로 int형으로 변환 불가능!
		
		
		/*
		 * Integer 클래스의 다양한 메서드
		 */
		int iNum = 31;
		System.out.println(iNum + " -> 2진수로 변환 : " + Integer.toBinaryString(iNum));
		System.out.println(iNum + " -> 8진수로 변환 : " + Integer.toOctalString(iNum));
		System.out.println(iNum + " -> 16진수로 변환 : " + Integer.toHexString(iNum));
		
	}

}




















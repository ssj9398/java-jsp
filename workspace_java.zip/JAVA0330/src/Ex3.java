
public class Ex3 {

	public static void main(String[] args) {
		/*
		 * Character 클래스 활용
		 */
		
		// toXXX() 메서드를 호출하여 다양한 변환 가능
		char ch = 'A';
		System.out.println(ch + " -> 소문자로 변환 : " + Character.toLowerCase(ch));
		
		ch = 'r';
		System.out.println(ch + " -> 대문자로 변환 : " + Character.toUpperCase(ch));
			
		ch = '!'; // 영문자가 아닌 경우 변환은 안되지만 오류 발생은 없음
		System.out.println(ch + " -> 대문자로 변환 : " + Character.toUpperCase(ch));
			
		// isXXX() 메서드를 호출하여 다양한 판별 가능
		ch = 'T';
		System.out.println(ch + " : 대문자인가? " + Character.isUpperCase(ch));
		
		System.out.println(ch + " : 숫자인가? " + Character.isDigit(ch));
		
		ch = '가';
		System.out.println(ch + " : 문자인가? " + Character.isLetter(ch));
		
		ch = ' ';
		System.out.println(ch + " : 공백인가? " + Character.isSpace(ch));
		System.out.println(ch + " : 공백인가? " + Character.isWhitespace(ch));
		// => 주로 isSpace() 보다는 isWhitespace() 메서드를 사용
		
	}

}









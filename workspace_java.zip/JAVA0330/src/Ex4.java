import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

public class Ex4 {

	public static void main(String[] args) {
		/*
		 * Collection Framework(컬렉션 프레임워크)
		 * - 컴퓨터 시스템에서 데이터를 효율적으로 저장 및 관리하는 방법 = 자료구조
		 *   => 자료구조를 자바에서 구현하여 제공하는 클래스들의 모음
		 * - Set, List, Map 인터페이스 계열로 구분됨
		 *   => Set 과 List 인터페이스는 공통적으로 Collection 인터페이스를 구현하므로
		 *      제공되는 메서드가 거의 동일함
		 * - java.util 패키지에 컬렉션 프레임워크 클래스들이 제공됨
		 *      
		 * 1. Set 계열
		 * - 저장 순서 유지 X, 데이터 중복 허용 X
		 *   => 주머니에 공을 무작위로 집어넣는 것과 유사한 방식(순서 유지와 중복 불가)
		 * - 주로 HashSet, TreeSet 클래스 사용
		 * - 인덱스를 사용하지 않음
		 */
		
		// HashSet 객체 생성 => Set 인터페이스 구현체이므로 업캐스팅 가능
//		Set set = new HashSet(); // HashSet -> Set 업캐스팅
		HashSet set = new HashSet(); // HashSet 클래스타입 그대로 사용 가능
		
		// 1. boolean isEmpty() : 컬렉션 객체가 비어있는지 여부 리턴
		System.out.println("set 객체가 비어있는가? " + set.isEmpty());
		
		// 2. int size() : 컬렉션 객체에 저장된 요소(데이터) 갯수 리턴
		System.out.println("set 객체에 저장된 요소 갯수 : " + set.size());
		
		// 3. boolean add(Object o) : 컬렉션 객체에 요소(데이터) 추가
		// => 파라미터가 Object 타입이므로 모든 데이터타입 추가 가능(기본형, 객체 모두)
		// => 리턴타입이 boolean 이므로 추가 성공 여부 리턴됨(중복데이터 추가 X)
		set.add(1);
		set.add("Two");
		set.add(3.14);
		
		System.out.println("set 객체가 비어있는가? " + set.isEmpty());
		System.out.println("set 객체에 저장된 요소 갯수 : " + set.size());
		
		// 4. String toString() : 컬렉션 객체에 저장된 요소(데이터) 모두 출력
		// => 저장된 순서가 유지되지 않으므로, 출력 결과는 다를 수 있다.
//		System.out.println("set 객체의 모든 요소 출력 : " + set.toString()); 
		System.out.println("set 객체의 모든 요소 출력 : " + set); // toString() 생략 가능
		
		// add() 메서드의 리턴타입이 boolean 이므로 데이터 추가 성공 여부가 리턴됨
		// => 중복된 데이터는 추가되지 않고 리턴값으로 false 리턴됨
		System.out.println("실수 3.14 추가 가능한가? " + set.add(3.14));
		System.out.println("set 객체의 모든 요소 출력 : " + set);
		
		System.out.println("문자 '4' 추가 가능한가? " + set.add('4'));
		System.out.println("set 객체의 모든 요소 출력 : " + set);
		
		set.add(5);
		set.add("육");
		System.out.println("set 객체에 저장된 요소 갯수 : " + set.size());
		System.out.println("set 객체의 모든 요소 출력 : " + set);
		
		
		// boolean contains(Object o) : 객체 내의 요소 o 포함 여부 리턴
		System.out.println("set 객체에 실수 3.14 가 존재하는가? " + set.contains(3.14));
		System.out.println("set 객체에 정수 3 이 존재하는가? " + set.contains(3));
		
		// boolean remove(Object o) : 객체 내의 요소 삭제 -> 삭제 후 결과 리턴
		System.out.println("set 객체 내의 실수 3.14 삭제 : " + set.remove(3.14));
		System.out.println("set 객체 내의 실수 3.14 삭제 : " + set.remove(3.14));
		System.out.println("set 객체의 모든 요소 출력 : " + set);
		
		// void clear()
//		set.clear();
//		System.out.println("set 객체의 모든 요소 출력 : " + set);
		
		System.out.println("----------------------------");
		// Set 또는 List 계열 객체 생성 시 각 객체 데이터 이전(복사) 가능
		Set set2 = new HashSet(set); // set 객체를 set2 객체에 전달(복사)
		System.out.println("set2 객체의 모든 요소 출력 : " + set2);
		
		// 객체 생성 후 addAll() 메서드를 통해 데이터 이전(복사)도 가능
		Set set3 = new HashSet();
		set3.addAll(set2);
		System.out.println("set3 객체의 모든 요소 출력 : " + set3);
		
		System.out.println("----------------------------");
		
		Set set4 = new HashSet();
		// 문자열 "1", "10", "30", "100", "200", "300" 추가 => 순서 섞어서 추가
//		set4.add("300");
//		set4.add("30");
//		set4.add("200");
//		set4.add("1");
//		set4.add("100");
//		set4.add("10");
		
		// 정수 1, 10, 30, 100, 200, 300 추가 => 순서 섞어서 추가
		set4.add(300);
		set4.add(30);
		set4.add(200);
		set4.add(1);
		set4.add(100);
		set4.add(10);
		System.out.println("set4 객체의 모든 요소 출력 : " + set4);
		
		// TreeSet 객체를 활용하면 같은 타입 데이터가 저장된 Set 객체 정렬 가능
		// => 수치데이터는 수치 순으로 정렬되며
		//    문자데이터는 문자 코드값 순으로 정렬되므로 정렬 결과가 다름!
		TreeSet treeSet = new TreeSet(set4);
		System.out.println("treeSet 객체의 모든 요소 출력 : " + treeSet);
		
		
	}

}





















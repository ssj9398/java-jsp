
public class Test3 {

	public static void main(String[] args) {
		// Character 클래스 활용
		// 1. char 타입 배열에 저장된 문자들을 
		// 대문자, 소문자, 숫자, 공백문자, 기타 로 구분하여 출력
		char[] chArr = {'t', '!', 'R', '1', ' '};
		
		for(char ch : chArr) {
			if(Character.isUpperCase(ch)) {
				System.out.println(ch + " : 대문자!");
			} else if(Character.isLowerCase(ch)) {
				System.out.println(ch + " : 소문자!");
			} else if(Character.isDigit(ch)) {
				System.out.println(ch + " : 숫자!");
			} else if(Character.isWhitespace(ch)) {
				System.out.println(ch + " : 공백문자!");
			} else {
				System.out.println(ch + " : 기타!");
			}
		}
		
		// 2. 문자열을 암호화
		// => 문자열을 char 타입으로 각각 하나씩 변환하여
		//    문자의 코드값에 3을 더한 문자를 다시 문자열로 결합하여 출력
		// ex) "Hello"(변환 전) => "Khoor"(변환 후) 
		String originalStr = "Hello, World!";
		// String 타입 문자열을 char[] 타입으로 변환하는 메서드 : toCharArray()
		char[] splitChar = originalStr.toCharArray();
		
		// 참고! char[] 타입에 저장된 문자들을 String 타입으로 변환하는 방법
//		String str = new String(splitChar); // String 객체 생성 파라미터로 char[] 타입 전달
		
		String encryptStr = "";
		// 반복문을 사용하여 char[] 타입 문자 하나하나의 값을 3만큼 증가시킨 후
		// encryptStr 변수에 문자열 결합하여 출력
		for(char ch : splitChar) {
			encryptStr += (char)(ch + 3); // 주의! char 타입으로 형변환 후 결합 필수!
		}
		
		System.out.println("암호화 결과 : " + encryptStr);
		
		// 암호화 된 문자열(encryptStr)을 원래대로 복호화하여 originalStr 에 저장, 출력
		originalStr = ""; // 초기화 필수!
		splitChar = encryptStr.toCharArray();
		
		for(char ch : splitChar) {
			originalStr += (char)(ch - 3); // 주의! char 타입으로 형변환 후 결합 필수!
		}
		
		System.out.println("복호화 결과 : " + originalStr);
		
		
		
	}

}

















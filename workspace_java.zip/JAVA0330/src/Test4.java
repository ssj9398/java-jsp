import java.util.Set;
import java.util.TreeSet;

public class Test4 {

	public static void main(String[] args) {
		// Set 계열을 사용하여 로또 번호 생성기 작성
		// 1, 10, 15, 19, 30, 45
		Set<Integer> thisWeekLotto = new TreeSet<Integer>(); // Set 객체 + 정렬 기능 포함
		thisWeekLotto.add(45);
		thisWeekLotto.add(15);
		thisWeekLotto.add(10);
		thisWeekLotto.add(19);
		thisWeekLotto.add(30);
		thisWeekLotto.add(1);
//		System.out.println(thisWeekLotto);
		
		Set<Integer> myLotto = new TreeSet<Integer>();
		// 1 ~ 45 사이의 난수 6개 저장
		// => Set 계열은 중복을 허용하지 않으므로 size() 가 6이 될때까지 반복
		while(myLotto.size() < 6) {
			int rNum = (int)(Math.random() * 45 + 1);
			myLotto.add(rNum);
		}
		
		System.out.println("나의 로또 번호 : " + myLotto);
		System.out.println("이번주 1등 당첨번호 : " + thisWeekLotto);
		
		// 당첨번호 갯수 카운팅
		int count = 0;
		
		for(int lottoNum : myLotto) { // myLotto 숫자를 하나씩 꺼내 lottoNum 에 저장
			// 꺼낸 번호를 1등 당첨번호 목록에서 일치 여부 판별
			if(thisWeekLotto.contains(lottoNum)) { // 일치하는 번호가 있을 경우
				System.out.println("일치하는 번호 : " + lottoNum);
				count++; // 카운트 증가
			}
		}
		
		System.out.println("일치하는 번호 갯수 : " + count + "개");
		
	}

}





















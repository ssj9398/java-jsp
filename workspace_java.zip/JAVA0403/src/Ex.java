import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class Ex {

	public static void main(String[] args) {
		/*
		 * 2. List 계열
		 * - 저장 데이터의 순서 유지, 중복 허용
		 * - 저장되는 데이터에는 자동으로 인덱스가 부여됨(0번부터 시작) = 배열과 동일
		 * - 구현체 클래스 : ArrayList, Vector
		 * - 기본적인 메서드 대부분 Set 계열과 동일(= 부모가 같기 때문)
		 */
		
		List list = new ArrayList();
		list.add("하나");
		list.add(2);
		list.add(3.14);
		System.out.println("List 객체가 비어있는가? " + list.isEmpty());
		System.out.println("List 객체 사이즈 : " + list.size());
		System.out.println("List 객체 모든 요소 출력 : " + list);
		
		System.out.println("중복 데이터 3.14 추가 가능한가? " + list.add(3.14));
		System.out.println("List 객체 모든 요소 출력 : " + list);
		
		// Object get(int index) : index 에 해당하는 요소 리턴
		// => 존재하지 않는 인덱스 지정 시 IndexOutOfBoundsException 발생
		System.out.println("List 객체의 3번 인덱스 요소 : " + list.get(3));
//		System.out.println("List 객체의 3번 인덱스 요소 : " + list.get(4)); // 오류
		
		System.out.println(list.indexOf("하나")); // 특정 요소가 존재하는 인덱스 리턴
		
//		list.remove(2); // 정수 데이터 2가 아닌 2번 인덱스를 지정하므로 3.14 삭제됨
		// 만약, 정수 2를 삭제하려면 1) 2의 인덱스 지정  또는  2) (Object)2 지정 필요
//		list.remove(1); // 1번 인덱스의 정수 2 삭제됨
//		list.remove((Object)2);
//		list.remove(list.indexOf(2)); // 정수 2를 찾아서 인덱스를 리턴받아 삭제
		System.out.println("List 객체 모든 요소 출력 : " + list);
		
		list.set(3, '4'); // 해당 인덱스의 요소를 교체(없는 인덱스일 경우 오류 발생)
		System.out.println("List 객체 모든 요소 출력 : " + list); 
		
		List subList = list.subList(1, 3); // 시작인덱스 ~ 끝인덱스-1 까지 요소 추출
		System.out.println("List 객체의 부분 리스트 모든 요소 출력 : " + subList);
		
		Object[] arr = list.toArray(); // 배열로 추출 가능
		
		// --------------------------------------------------
		
		List list2 = new ArrayList();
		list2.add(3);
		list2.add(4);
		list2.add(1);
		list2.add(6);
		list2.add(5);
		list2.add(2);
		System.out.println("정렬 전 : " + list2);
		
		// Collections 클래스의 static 메서드 sort() 사용 시 List 객체 정렬 가능
		Collections.sort(list2); // list2 객체 요소 정렬(같은 타입 요소만 가능)
		System.out.println("정렬 후 : " + list2);
		
		// Collections 클래스의 static 메서드 shuffle() 사용 시 List 객체 순서 뒤섞기
		Collections.shuffle(list2);
		System.out.println("Shuffle 후 : " + list2);
		
		
		// Arrays.asList() 메서드를 호출하여 데이터를 연속적으로 전달하면
		// List 타입 객체로 리턴됨(한번에 List 객체 데이터 추가 가능)
		List list3 = Arrays.asList(1, 2, 3, 4, 5, 5);
		System.out.println(list3);
		
		
	}

}










import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class Ex2 {

	public static void main(String[] args) {
		/*
		 * Map 계열
		 * - 키(Key) 와 값(Value) 을 한 쌍으로 갖는 자료구조
		 * - 키는 중복 불가능, 값은 중복 가능
		 * - 구현체 클래스 : HashMap, Properties 등
		 */
		
		Map map = new HashMap();
		
		// put(Object key, Object value) : 키에 해당하는 데이터 추가
		map.put(1, "자바");
		map.put(2, "JSP");
		map.put(3, "Android");
		System.out.println("Map 객체의 모든 키, 값 출력 : " + map);
		
		map.put(3, "Spring"); // 키 값이 중복될 경우 값(Value)을 덮어씀
		System.out.println("Map 객체의 모든 키, 값 출력 : " + map);
		
		// get(Object key) : 키에 해당하는 데이터 리턴(키가 없을 경우 null 값 리턴됨)
		System.out.println("정수 2에 해당하는 키의 데이터 : " + map.get(2));
		System.out.println("정수 4에 해당하는 키의 데이터 : " + map.get(4));
		
		// Set keySet() : Map 객체 내의 모든 키 리턴 -> Set 타입 객체로 리턴
		Set keySet = map.keySet(); // Set 타입 변수에 저장하거나 바로 출력 가능
		System.out.println("모든 키 : " + keySet);
		
		// values() : Map 객체 내의 모든 값 리턴 -> Collection 타입 객체로 리턴
		System.out.println("모든 값 : " + map.values());
		// Set 또는 List 계열 변수에 바로 저장 불가(다운캐스팅도 불가)
//		Set valueSet = (Set)map.values();
//		List valueList = (List)map.values();
		// Set 또는 List 계열 객체 생성 시 파라미터로 전달 가능
		Set valueSet = new HashSet(map.values());
		System.out.println(valueSet);
		
		System.out.println("---------------------------------");
		
		Map map2 = new HashMap();
		// 키 또는 값은 Object 타입이므로 모든 타입 사용 가능
		map2.put("딸기", 1000);
		map2.put("바나나", 500);
		map2.put("수박", 8000);
		
		System.out.println("수박의 가격은? " + map2.get("수박") + "원");
		
		System.out.println("과일 중에 바나나가 있습니까? " + map2.containsKey("바나나"));
		System.out.println("과일 중에 사과가 있습니까? " + map2.containsKey("사과"));
		
		System.out.println("500원짜리 과일 있습니까? " + map2.containsValue(500));
		System.out.println("5000원짜리 과일 있습니까? " + map2.containsValue(5000));
		
		System.out.println(map2); // toString() 메서드이므로 하나의 문자열로 결합됨
		// entrySet() : 각각의 키와 값을 한 쌍으로 갖는 Set 객체로 리턴
		System.out.println(map2.entrySet());
		Set set3 = map2.entrySet(); // 키와 값을 한 쌍으로 갖는 Set 객체 저장 가능
		System.out.println(set3);
		
		
		// 정상 추가 시 null 리턴
		System.out.println(map.put("andy", "1234")); 
		// 중복 키 존재하면 삭제되는 데이터("1234) 리턴
		System.out.println(map.put("andy", "4567")); 
		
	}

}




















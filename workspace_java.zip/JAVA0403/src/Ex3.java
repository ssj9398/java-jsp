import java.util.Stack;

public class Ex3 {

	public static void main(String[] args) {
		/*
		 * Stack(스택)
		 * - 하나의 상자에 데이터를 아래쪽(bottom)에서부터 차례대로 쌓는 자료구조
		 * - 데이터가 한쪽(top)에서만 삽입/삭제 이루어짐
		 * - FILO(First In Last Out) 또는 LIFO(Last In First Out) 구조라고 함
		 * - 2개의 스택을 사용하여 웹브라우저 뒤로/앞으로, 응용프로그램 Redo/Undo 구현
		 */
		Stack stack = new Stack();
		
		// push(Object o) : 데이터 추가
		stack.push("1 - www.itwillbs.co.kr");
		stack.push("2 - www.naver.com");
		stack.push("3 - www.nate.com");
		
		System.out.println("모든 요소 출력 : " + stack);
		
		// Object peek() : 맨 위의 요소를 꺼내서 확인(제거하지 않음)
		System.out.println("맨 위(Top)의 요소 출력 : " + stack.peek());
		System.out.println("맨 위(Top)의 요소 출력 : " + stack.peek());
		
		// Object pop() : 맨 위의 요소를 꺼내서 확인(제거함)
		System.out.println("맨 위(Top)의 요소 출력 : " + stack.pop());
		System.out.println("맨 위(Top)의 요소 출력 : " + stack.pop());
	}

}

















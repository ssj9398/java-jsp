import java.util.LinkedList;
import java.util.Queue;

public class Ex4 {

	public static void main(String[] args) {
		/*
		 * Queue(큐)
		 * - 한 쪽에선 추가, 반대쪽에선 삭제가 일어나는 자료구조(FIFO 또는 LILO 구조)
		 * - 구현체 클래스로 LinkedList 를 사용하며 
		 *   LinkedList 는 Queue 와 List 모두를 구현한 구현체
		 * - 주로 번호표 시스템(선착순)이나 최근 사용 문서 구현에 활용됨
		 */
		
		Queue q = new LinkedList();
		
		// offer(Object o) : 데이터 추가
		q.offer("1 - Ex.java");
		q.offer("2 - main.jsp");
		q.offer("3 - a.txt");
		System.out.println("모든 Queue 객체 출력 : " + q);
		
		// poll() : 데이터 꺼내기
		System.out.println("맨 처음 추가된 요소 출력(peek) : " + q.peek());
		System.out.println("맨 처음 추가된 요소 출력(peek) : " + q.peek());
		System.out.println("맨 처음 추가된 요소 출력(poll) : " + q.poll());
		System.out.println("맨 처음 추가된 요소 출력(poll) : " + q.poll());
		
	}

}


















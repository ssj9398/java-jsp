import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Ex5 {

	public static void main(String[] args) {
		/*
		 * 제네릭(Generic, 일반화)
		 * - 객체에서 사용할 타입을 미리 명시하여 사용하도록 하는 기법
		 */
		// Collection API 의 객체들은 파라미터로 Object 타입을 많이 사용
		// => 제네릭 타입을 생략할 경우 자동으로 Object 타입으로 지정되기 때문
		// 제네릭 타입을 지정하지 않은 ArrayList 객체 사용
		List list = new ArrayList(); 
		// => List<Object> list = new ArrayList<Object>(); 와 동일한 코드
		// Object 타입 파라미터를 사용하는 add() 메서드는 아무 타입이나 모두 저장 가능
		list.add(1);
		list.add("2");
		list.add(3.14);
		
		for(int i = 0; i < list.size(); i++) {
//			System.out.println(list.get(i));
//			int data = list.get(i); // 오류 발생(Object 타입이므로 저장 불가)
//			int data = (int)list.get(i); // 오류 발생(다른 데이터타입 포함됨)
//			Object data = list.get(i); // Object 타입으로는 사용 가능
//			System.out.println(data);
			
			// 타입 체크를 통해 각각 다른 타입 변수에 저장
			if(list.get(i) instanceof Integer) {
				int data = (int)list.get(i);
				System.out.println(data);
			} else if(list.get(i) instanceof String) {
				String data = (String)list.get(i);
				System.out.println(data);
			} else if(list.get(i) instanceof Double) {
				double data = (double)list.get(i);
				System.out.println(data);
			}   
			
		}
		
		System.out.println("----------------------------");
		
		// 제네릭 타입을 지정하여 ArrayList 객체 사용
		// 클래스명 뒤에 <> 기호를 명시하고 기호 사이에 참조형 타입을 지정
//		List<int> list2 = new ArrayList<int>(); // 기본형은 제네릭타입으로 사용 불가
		List<Integer> list2 = new ArrayList<Integer>();
		// => ArrayList 객체에 저장 가능한 타입이 Integer 타입으로 고정됨
		list2.add(1);
//		list2.add("이"); // 컴파일에러 발생! Integer 타입만 추가 가능
//		list3.add(3.14); // 컴파일에러 발생! Integer 타입만 추가 가능
		list2.add(2);
		list2.add(3);
		
		for(int i = 0; i < list2.size(); i++) {
			// 제네릭 타입을 지정할 경우 한가지 타입 변수에 모든 데이터 전달 가능
			// => 또한, 가져오는 시점에서 타입 체크가 불필요함
			int data = list2.get(i); // 형변환 없이, 타입 체크 없이 바로 저장
			System.out.println(data);
		}
		
		System.out.println("------------------------------");
		
		Map<String, Integer> map = new HashMap<String, Integer>();
		
	}

}

















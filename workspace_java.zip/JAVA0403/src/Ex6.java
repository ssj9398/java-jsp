import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class Ex6 {

	public static void main(String[] args) {
		NormalClass nc = new NormalClass();
		nc.setMember(1);
		nc.setMember("홍길동");
		
		System.out.println(nc.getMember());
		
		// Object 타입을 사용하여 관리하는 데이터는 가져올 때 체크 필요
		// => 잘못된 타입으로 변환할 경우 ClassCastException 발생
//		int num = (int)nc.getMember(); // 실행 시점에서 예외 발생
		
		System.out.println("=============================");
		
		// 제네릭을 사용한 클래스의 인스턴스 생성
		// => 클래스명 뒤에 제네릭 타입을 참조형으로 명시하여 고정시킴
		// => 어떤 타입이든 참조형 타입이면 모두 지정 가능하므로 Object 처럼 사용 가능
		// 1. 제네릭 타입 T 를 Integer 타입으로 지정
		GenericClass<Integer> gc = new GenericClass<Integer>();
		// => GenericClass 내의 모든 T 에 해당하는 타입이 Integer(정수)로 변경됨
		gc.setMember(1); // setMember(Integer member) 형태로 바뀌어 있음
//		gc.setMember("홍길동"); // Integer 타입이 아니므로 컴파일 에러 발생!
		
		int num = gc.getMember(); // Integer getMember() 형태로 바뀌어 있음
		
		// 2. 제네릭 타입 T 를 double 타입으로 지정
		GenericClass<Double> gc2 = new GenericClass<Double>();
		// => 모든 T 타입이 Double 타입으로 변경됨
		gc2.setMember(3.14);
		
		// 3. 제네릭 타입 T 를 String 타입으로 지정
		GenericClass<String> gc3 = new GenericClass<String>();
		gc3.setMember("홍길동");
		
		// 4. 제네릭 타입 T 를 Person 타입으로 지정
		GenericClass<Person> gc4 = new GenericClass<Person>();
		gc4.setMember(new Person("홍길동", 20));
		Person p = gc4.getMember();
		System.out.println(p.name + ", " + p.age);
		
		// 5. 제네릭 타입을 지정하지 않을 경우 => Object 타입으로 자동 지정됨
		GenericClass gc5 = new GenericClass();
		// 모든 데이터 타입을 다 사용할 수 있게 됨
		gc5.setMember(1);
		gc5.setMember("홍길동");
		
		// -------------------------------------------
		// 실제 제네릭을 적용한 Collection API 들
		List<String> list = new ArrayList<String>();
		Set<Integer> set = new HashSet<Integer>();
		Map<String, Integer> map = new HashMap<String, Integer>();
		
	}

}

/*
 * 제네릭을 사용한 클래스 정의
 * - 클래스 정의 시점에서 클래스명 뒤에 <> 기호를 사용하여 "가상의 자료형" 명시
 *   => 보통 1글자의 영문대문자를 사용(주로 E 또는 T 지정)
 * - 가상의 자료형이므로 클래스 정의 시점에서는 정확한 자료형을 알 수 없음
 *   => 단, 클래스 내에서 지정된 가상의 자료형을 실제 자료형 대신 사용 가능
 * - 해당 클래스의 인스턴스 생성 시점에서 가상의 자료형 대신 실제 자료형을 지정하면
 *   가상의 자료형이 명시되어있는 부분의 코드가 모두 실제 자료형으로 변환됨
 *   => 어떠한 자료형으로도 바꿀 수 있다!
 */
class GenericClass<T> {
	T member; // member 라는 변수의 데이터타입을 T 로 지정하여
	// Getter/Setter 등의 메서드에서도 명확한 타입 대신 T 라는 가상의 타입 사용하게 됨

	public T getMember() { // Getter 메서드의 리턴타입이 T
		return member;
	}

	public void setMember(T member) { // Setter 메서드의 파라미터 타입이 T
		this.member = member;
	}
	
}

class Person {
	String name;
	int age;
	
	public Person(String name, int age) {
		this.name = name;
		this.age = age;
	}
}


// 사용할 데이터를 Object 타입으로 관리하는 일반 클래스
class NormalClass {
	Object member;

	public Object getMember() {
		return member;
	}

	public void setMember(Object member) {
		this.member = member;
	}
	
}

















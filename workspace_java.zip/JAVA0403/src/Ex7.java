import java.util.Random;

public class Ex7 {

	public static void main(String[] args) {
		/*
		 * Random 클래스
		 * - 난수 발생 전용 클래스
		 * - 정수 뿐만 아니라 실수, boolean 타입까지 임의 생성 가능
		 */
		
		Random r = new Random();
		System.out.println("int 범위 난수 : " + r.nextInt());
		System.out.println("long 범위 난수 : " + r.nextLong());
		System.out.println("float 범위 난수 : " + r.nextFloat());
		System.out.println("double 범위 난수 : " + r.nextDouble()); // Math.random()
		System.out.println("boolean 범위 난수 : " + r.nextBoolean());
		
		// nextInt(int bound) 메서드를 많이 사용
		// => 0 <= x < bound 범위의 정수형 난수 발생(형변환도 필요없음)
		for(int i = 1; i <= 10; i++) {
//			int rNum = r.nextInt(10); // 0 ~ 9 사이의 난수
			int rNum = r.nextInt(10) + 1; // 1 ~ 10 사이의 난수
			System.out.println(rNum);
		}
		
	}

}













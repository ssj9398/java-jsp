import java.util.Date;

public class Ex {

	public static void main(String[] args) {
		/*
		 * java.util.Date 클래스
		 * - 날짜 관련 기능을 제공하는 클래스
		 * - 대부분의 메서드가 deprecated 처리되어 있음
		 *   => 다양한 API 들에서 여전히 Date 타입을 사용하는 경우가 많음
		 * - toString() 메서드가 오버라이딩 되어 있음 => 날짜 및 시각 정보 제공
		 *   
		 */
		// 기본 생성자를 호출하면 시스템의 현재 날짜 및 시각 정보를 사용하여 객체 생성
		Date d1 = new Date();
		System.out.println(d1);
		
		// 생성자에 long 타입 값을 전달하면 해당 값에 맞는 객체 생성
//		Date d2 = new Date(0); // 1970년 1월 1일 09시00분00초 기준
		Date d2 = new Date(2000000000000L); // 밀리초 단위의 long 타입 값을 전달하면
		// 기준 날짜 및 시각으로부터 해당 값만큼 뒤의 날짜 및 시각으로 설정
		System.out.println(d2);
		
		// 생성자에 연월일 등의 파라미터 전달 시 직관적인 날짜 지정이 아니므로 주의!
//		Date d3 = new Date(2000, 1, 1); // 2000년 1월 1일이 아님!
//		System.out.println(d3);
		
		int year = d1.getYear() + 1900; // 1900년을 기준으로 현재 연도 - 기준연도 값 리턴
		int month = d1.getMonth() + 1; // 0 ~ 11월 기준으로 현재 월 리턴
		int day = d1.getDay();
		System.out.println(year + "년 " + month + "월 " + day + "일");
		
		// getTime() 메서드는 long 타입 날짜 정보를 리턴하므로
		// 두 getTime() 결과를 연산하면 두 날짜 간의 차이를 계산 가능
		// => 목표날짜 - 현재날짜 > 0 일 경우 남은 일 수이며,
		//    목표날짜 - 현재날짜 < 0 일 경우 지난 일 수이다.
		long differentDate = d2.getTime() - d1.getTime();
//		System.out.println(differentDate); // long 타입 값(밀리초) 출력
		// 일 단위로 변경하려면 밀리초 -> 초 -> 분 -> 시 -> 일 순서로 변환해야함
//		System.out.println(differentDate / 1000 / 60 / 60 / 24 + "일");
		
		if(differentDate > 0) {
			System.out.println(differentDate / 1000 / 60 / 60 / 24 + "일 남았습니다.");
		} else if(differentDate < 0) {
			System.out.println(differentDate / 1000 / 60 / 60 / 24 + "일 지났습니다.");
		} else {
			System.out.println("오늘입니다!");
		}
		
		
	}

}





















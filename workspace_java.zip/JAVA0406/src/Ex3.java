import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.Month;
import java.time.format.DateTimeFormatter;
import java.time.format.TextStyle;
import java.util.Locale;

public class Ex3 {

	public static void main(String[] args) {
		/*
		 * java.time 패키지
		 * - 날짜 및 시각 정보를 관리하는 패키지로 JDK 8 부터 사용됨
		 * - LocalDate : 날짜 관련 기능
		 *   LocalTime : 시각 관련 기능
		 *   LocalDateTime : 날짜와 시각 관련 기능
		 * - toString() 오버라이딩 되어 있음
		 * - 각 클래스의 now() 메서드 호출 시 현재 시스템의 정보 가져옴
		 * - 각 클래스의 of() 메서드를 호출하면, 날짜 및 시각 정보 설정 가능
		 * - getXXX() 메서드를 호출하여 정보 가져오기
		 *   => XXX 은 가져올 정보의 종류(ex. 연도는 getYear(), 시각은 getHour())
		 */
		
		LocalDate date = LocalDate.now();
		System.out.println(date);
		
		LocalTime time = LocalTime.now();
		System.out.println(time);
		
		LocalDateTime dateTime = LocalDateTime.now();
		System.out.println(dateTime);
		
		LocalDate date2 = LocalDate.of(2000, 1, 1);
		System.out.println(date2);
		
		LocalTime time2 = LocalTime.of(9, 1, 30);
		System.out.println(time2);
		
		LocalDateTime dateTime2 = LocalDateTime.of(1999, 12, 31, 23, 59, 59);
		System.out.println(dateTime2);
		
		// ----------------------------------------------------------
		int year = date.getYear();
		int month = date.getMonthValue(); // 주의! getMonth() 메서드는 Month 객체 리턴
		int day = date.getDayOfMonth();
		
		int hour = time.getHour(); // 24시간제
		int min = time.getMinute();
		int sec = time.getSecond();
		
		System.out.println(
				year + "/" + month + "/" + day + " " + hour + ":" + min + ":" + sec);
		
		// Month 활용법
		Month eMonth = date.getMonth(); // Enum 타입 객체로 리턴됨
		System.out.println(eMonth); // 월 이름(영문) 바로 출력됨
		String monthName = eMonth.name(); // String 타입 변환 시 name() 메서드 호출
		
		// Month 객체를 한국 기준 표현법으로 변환할 경우
		System.out.println(eMonth.getDisplayName(TextStyle.SHORT, Locale.KOREAN));
		
		// ---------------------------------------------------------------------------
		// 날짜 또는 시각에 대한 연산 수행할 경우
		// 해당 객체의 plusXXX() 메서드 또는 minusXXX() 메서드를 호출하여 연산 가능
		LocalDate now = LocalDate.now();
		System.out.println(now);
		LocalDate afterTwoMonth = now.plusMonths(2);
		System.out.println(afterTwoMonth);
		LocalDate after10Day = now.plusDays(10);
		System.out.println(after10Day);
		
		// 빌더 패턴을 활용하여 리턴타입이 자기 자신인 객체의 다음 메서드 연결 가능
		System.out.println(now.plusMonths(1).plusDays(15)); // 1개월 15일 후 출력
		
		// ======================================================================
		System.out.println("현재 시각 : " + dateTime);
		/*
		 * DateTimeFormatter 와 LocalXXX
		 * - 날짜 및 시각에 대한 표현 기능을 위해 파싱 등의 기능 제공하여 
		 *   날짜 및 시각 표현에 대한 형식 변경 가능
		 * - 해당 기능 사용을 위해 ofPattern() 메서드에 패턴 문자열 설정 필요 
		 */
//		String nowStr = dateTime.toString();
		
		// 문자열로 이루어진 임의의 형식의 날짜 및 시각 정보를
		// LocalDate 등의 객체 형태로 파싱
//		String nowStr = "1999년 12월 31일(금요일) 오후 23:59:59"; // 문자열 날짜
//		String pattern = "yyyy년 MM월 dd일(EEEE) a HH:mm:ss"; // 패턴
		
		String nowStr = "99-12-31 23시59분59초"; // 문자열 날짜
		String pattern = "yy-MM-dd HH시mm분ss초"; // 패턴
		
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern(pattern); // 패턴 지정
		// 패턴을 적용하여 파싱한 결과를 LocalDateTime 객체로 리턴
		LocalDateTime parsingDate = LocalDateTime.parse(nowStr, dtf); 
		System.out.println(parsingDate);
		System.out.println(parsingDate.getHour() + "시");
		
		// 패턴을 적용하여 LocalDateTime 객체를 원하는 형식의 문자열로 리턴
		System.out.println(parsingDate.format(dtf));
		
		
	}

}

















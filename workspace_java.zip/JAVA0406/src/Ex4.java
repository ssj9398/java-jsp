import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;

public class Ex4 {

	public static void main(String[] args) {
		/*
		 * 날짜 및 시각 정보에 대한 형식화(Formatting)
		 * - SimpleDateFormat 클래스와 DateTimeFomatter 클래스 사용
		 *   1) SimpleDateFormat : Date 타입 객체에 대한 형식화
		 *   2) DateTimeFormatter : LocalDate, LocalTime, LocalDateTime 타입 형식화
		 */
		
		// 1. SimpleDateFormat 클래스 사용
		Date today = new Date();
		System.out.println(today);
		
		String pattern = "yyyy년 MM월 dd일"; // 형식 적용을 위한 패턴 문자열
		
		// 1-1. SimpleDateFormat 클래스 객체 생성
		//      => 파라미터로 패턴 문자열 전달
		SimpleDateFormat sdf = new SimpleDateFormat(pattern);
		// 1-2. SimpleDateFormat 객체의 format() 메서드를 호출하여 Date 객체 전달
//		System.out.println(sdf.format(today)); // 바로 출력하거나
		String formatToday = sdf.format(today); // String 타입으로 저장 가능
		System.out.println(formatToday);
		
		System.out.println("----------------------------------------");
		// 2. DateTimeFormatter 클래스 사용
		LocalDate today2 = LocalDate.now();
		System.out.println(today2);
		// 1-1. DateTimeFormatter 객체를 가져오기 위해 ofPattern() 메서드 호출
		//      => 파라미터로 패턴 문자열 전달
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern(pattern);
		// 1-2. LocalDate 등의 날짜 및 시각 클래스 객체의 format() 메서드 호출하여
		//      DateTimeFormatter 객체(패턴)를 전달
		System.out.println(today2.format(dtf));
		
		System.out.println("----------------------------------------");
		
		String messagePattern = "이름 : {0}, Java : {1}, HTML : {2}, Script : {3}";
//		String src = "홍길동:100:90:95,이순신:100:100:100,강감찬:50:50:50";
//		String[] studentInfo = src.split(",");
//		for(String student : studentInfo) {
////			System.out.println(student);
//			System.out.println(MessageFormat.format(messagePattern, student.split(":")));
//		}
		
		System.out.println(MessageFormat.format(messagePattern,"홍길동", 100, 90, 95));
		
	}

}






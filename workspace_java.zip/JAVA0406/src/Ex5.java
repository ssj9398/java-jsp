import java.util.regex.Pattern;

public class Ex5 {

	public static void main(String[] args) {
		/*
		 * Pattern 클래스
		 * - 정규표현식 문자열을 객체로 관리하는 클래스
		 * - compile() 메서드를 사용하여 정규표현식에 대한 객체 생성
		 * - matches() 메서드를 사용하여 특정 문자열에 대한 정규표현식 패턴 검사 실시
		 */
		
		// 정규표현식으로 사용할 패턴 문자열 작성
		// => 주의! \ 기호 사용 시 이스케이프 문자로 인식되므로 \\ 형태로 사용
		//    또한, 마침표(.) 기호도 \\. 형태로 사용
		
		/*
		 * 1. 전화번호 형식 검증
		 *    - (010|011) : 010 또는 011
		 *    - [-\s]? : - 기호 또는 공백이 올 수도 있고 안 올 수도 있음
		 *    - \d{3,4} : 숫자 3자리 ~ 4자리
		 *    - \d{4} : 숫자 4자리
		 *    => 010 또는 011로 시작하고, 다음에 - 또는 공백이 있거나 없거나,
		 *       다음에 숫자 3자리 ~ 4자리, 다음에 - 또는 공백이 있거나 없거나,
		 *       다음에 숫자 4자리로 끝
		 */
		String regex = "^(010|011)[-\\s]?\\d{3,4}[-\\s]?\\d{4}$";
		
//		String number = "010-1234-56789";
//		boolean result = Pattern.matches(regex, number);
//		System.out.println(number + " 유효한 전화번호인가? " + result);
		
		// 전화번호 배열 사용
		String[] numbers = {
				"010-1234-56789", "010-1234-5678", "01012345678",
				"010 1234 5678", "010)1234-5678", "010-1234-567a"
		};
		
		// 반복문 사용하여 유효성 검사 결과 출력
		for(String number : numbers) {
			boolean result = Pattern.matches(regex, number);
			System.out.println(number + " 유효성 검사 결과 : " + result);
		}
		
		
	}

}

















import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Ex6 {

	public static void main(String[] args) {
		/*
		 * Matcher 클래스
		 * - 정규표현식에 해당하는 패턴 해석 및 문자열 일치여부 파악
		 * - Pattern 클래스의 matcher() 메서드를 통해 Matcher 객체 얻어오기 가능
		 * - Pattern 클래스는 전체에 대한 검증만 수행하지만, 
		 *   Matcher 클래스는 부분 검증 등도 가능
		 */
		String source = "JAVA and Javascript has no relation"; // 원본 문자열
		String regex = "JAVA"; // 정규표현식으로 사용할 패턴
		
		// 정규표현식 문자열을 Pattern 객체로 변환
		Pattern pattern = Pattern.compile(regex);
		
		// 정규표현식이 포함된 Pattern 객체의 matcher() 메서드에 
		// 원본 문자열을 전달하여 Matcher 객체 리턴받음
		Matcher matcher = pattern.matcher(source);
		
		System.out.println(
				"문자열이 정규표현식에 완전히 부합되는가? " + matcher.matches());
		// => 정규표현식에 있는 문자열 "JAVA" 와 원본 문자열은 100% 일치하지 않음
		
		System.out.println(
				"문자열이 정규표현식으로 시작되는가? " + matcher.lookingAt());
		// => 첫 단어가 "JAVA" 로 시작하기 때문에 true
		
		// 만약, lookingAt() 메서드 등을 사용하여 부분 검색 후에는 
		// 시작 인덱스가 변경되므로 리셋 필요
		matcher.reset(); // Matcher 객체의 정보 리셋하여 인덱스를 0으로 다시 설정
		System.out.println(
				"문자열이 정규표현식을 포함하는가? " + matcher.find());
		
	}

}

















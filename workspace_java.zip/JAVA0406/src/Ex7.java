import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Ex7 {

	public static void main(String[] args) {
		/*
		 * 정규표현식을 활용한 패스워드 유효성 검사
		 * 1. 패스워드 길이 : 8자 이상 16자 이하
		 * 2. 영문자, 숫자, 특수문자 조합
		 * 3. 영문자는 대문자 또는 소문자 사용 가능
		 * 4. 특수문자는 !@#$% 기호만 사용 가능
		 * 5. 영문자, 숫자, 특수문자 중 2가지 이상 조합해야함
		 */
		
		String lenRegex = "[A-Za-z0-9!@#$%]{8,16}"; // 패스워드 길이 정규표현식(8자리 ~ 16자리)
		String engRegex = "[A-Za-z]"; // 영문자 정규표현식(대문자 또는 소문자 1자리)
		String engUpperRegex = "[A-Z]"; // 영문자 대문자 정규표현식
		String engLowerRegex = "[a-z]"; // 영문자 소문자 정규표현식
		String numRegex = "[0-9]"; // 숫자 정규표현식(0 ~ 9 1자리)
		String specRegex = "[!@#$%]"; // 특수문자 정규표현식(!@#$% 기호 1개)
		
		String password = "Admin99999";
		// 길이 검사를 위해서는 전체 문자열에 대한 일치 여부 검사 필요
		// => Pattern.matches() 메서드 사용
//		System.out.println(
//				"패스워드 길이 체크 결과 : " + Pattern.matches(lenRegex, password));
		
		int has = 0;
		
		if(Pattern.matches(lenRegex, password)) { // 패스워드 길이 체크
			// Pattern.compile() 메서드를 사용하여 해당 정규표현식에 대한 객체 생성
//			Pattern engPattern = Pattern.compile(engRegex);
//			// Pattern 객체의 matcher() 메서드를 사용하여 Matcher 객체 리턴받기
//			// => 파라미터로 검사할 문자열 전달
//			Matcher matcher = engPattern.matcher(password);
//			// Matcher 객체의 find() 메서드를 호출하여
//			// 정규표현식에 부합되는 내용이 해당 문자열에 포함되는지 판별
//			if(matcher.find()) {
//				has++;
//			}
			
			// 위의 코드를 한 줄로 압축 가능
			// => 각 리턴되는 객체를 다시 메서드 호출을 통해 연결
			// 1. 영문자 체크
//			has += Pattern.compile(engRegex).matcher(password).find() ? 1 : 0;
			has += Pattern.compile(engUpperRegex).matcher(password).find() ? 1 : 0;
			has += Pattern.compile(engLowerRegex).matcher(password).find() ? 1 : 0;
			// 2. 숫자 체크
			has += Pattern.compile(numRegex).matcher(password).find() ? 1 : 0;
			// 3. 특수문자 체크
			has += Pattern.compile(specRegex).matcher(password).find() ? 1 : 0;
			
			// 패스워드 적합도 체크 결과 판별
			if(has < 3) { // 조합된 항목이 2가지 이하일 경우
				System.out.println(
						password + " : 영문 대문자, 소문자, 숫자, 특수문자 3가지 이상 조합 필수!");
			} else {
				System.out.println(password + " : 적합한 패스워드!");
			}
		} else {
			System.out.println(
					password + " : 패스워드 규칙 부적합(8 ~ 16자의 영문자, 숫자, 특수문자)");
		}
		
		
		
		
		
	}

}













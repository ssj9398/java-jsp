
public class Ex {

	public static void main(String[] args) {
		/*
		 * 예외(Exception)
		 * - 개발자가 의도하지 않은 상황에서 발생하는 문제로 프로그램이 비정상적으로 종료됨
		 *   => 예외가 발생한 위치부터 아래쪽의 코드들은 실행되지 못함
		 * - 오류(Error)와 달리 심각도가 낮으며, 예외 처리(Exception Handling)를 통해
		 *   예외 발생 시 해결책을 기술하여 프로그램의 비정상적인 종료를 막을 수 있음
		 * - try ~ catch 문을 사용하여 예외 처리 작업을 수행
		 *   => try 블록 내에서 예외 발생 가능성이 있는 코드들을 감시하고
		 *      예외가 발생하면 JVM 에 의해 해당 예외 객체를 전달받아
		 *      catch 블록 중 일치하는 타입에 대한 블록을 실행하여 예외 처리함
		 *   => 만약, 일치하는 catch 블록이 없을 경우 프로그램은 그대로 비정상 종료됨
		 * - Exception 클래스 또는 그 하위 클래스를 사용하여 예외 처리 가능
		 * - 컴파일(번역) 시점에서 예외 발생 여부를 알 수 있는 
		 *   Compile Checked Exception 계열(SQLException, IOException 등)과
		 *   실행 시점에서 예외 발생 여부를 알 수 있는 
		 *   Compile Unchecked Exception 계열(RuntimeException 계열) 로 구분됨    
		 * 
		 * < 기본 문법 >
		 * try {
		 * 		// 예외가 발생할 것으로 예상되는 범위의 코드들...
		 *      // => 예외 발생 코드 아래쪽의 나머지 try 블록 코드들은 실행되지 못함
		 * } catch(예외클래스명 변수명) {
		 * 		// 예외클래스에 해당하는 예외 발생 시 처리할 코드들...
		 * } finally {
		 * 		// 예외 발생 여부와 관계없이 무조건 실행할 문장들...
		 *      // (ex. DB 자원 반환, I/O 자원 반환 등)
		 * }
		 */
		
//		int num = 3;
//		int num2 = 0;
//		System.out.println(num / num2);
		// => 나눗셈 피연산자가 0인 경우 ArithmeticException 예외 발생
		// => Exception in thread "main" java.lang.ArithmeticException: / by zero
		//    at Ex.main(Ex.java:16)
		
//		int[] arr = {1, 2, 3};
//		System.out.println(arr[3]);
		// => 배열에 존재하지 않는 인덱스 접근 시 ArrayIndexOutOfBoundsException 발생
		// => Exception in thread "main" java.lang.ArrayIndexOutOfBoundsException: 3
		//    at Ex.main(Ex.java:22)
		
//		String str = null;
//		System.out.println(str.length());
		// => 객체를 저장하고 있지 않은(null) 참조변수에 접근 시 NullPointerException 발생
		// => Exception in thread "main" java.lang.NullPointerException
		//    at Ex.main(Ex.java:28)
		
		// =========================================================
		// 예외 처리
		System.out.println("프로그램 시작!");
		
		try {
			// 예외가 발생할 것으로 예상되는 코드들을 try 블록 내에 위치시킴
//			int num = 3;
//			int num2 = 0; // ArithmeticException 발생 원인 위치
//			// => 예외가 발생하는 코드를 수정하는 것은 예외 처리가 아니다!
//			System.out.println(num / num2);
			
			int[] arr = {1, 2, 3};
			System.out.println(arr[3]);
			// => 하나의 try 블록 내에서 2개 이상의 예외가 발생하는 경우
			//    다중 catch 문을 사용하여 복수개의 예외를 각각 처리할 수 있다.
			// => 또는, 복수개의 예외를 업캐스팅을 통해 하나로 묶어서 처리도 가능
			//    (ex. 모든 예외 처리 가능한 클래스 : Exception 클래스)
			
			System.out.println("try 블록 끝!");
		} catch(ArithmeticException e) {
			// catch 문에서 예외 발생 시 전달되는 예외 객체를 저장하는 
			// 예외 클래스 타입 변수 선언하고
			// catch 블록 내에서 해당 예외 발생 시 처리할 코드를 기술
			System.out.println("0으로 나눌 수 없습니다! - " + e.getMessage());
			// => e.getMessage() : 예외 발생 시 전달받은 원인 메세지 리턴
			e.printStackTrace();
			// => 예외 발생 상황에 대한 정보(예외 클래스명, 메세지, 발생 위치 출력)
		} catch(ArrayIndexOutOfBoundsException e) {
			System.out.println("배열 인덱스가 잘못 지정됐습니다! - " + e.getMessage());
		} catch(Exception e) {
			// 위의 catch 블록에서 처리하지 못하는 나머지 예외들을
			// Exception 클래스로 모두 한꺼번에 처리 가능(업캐스팅에 의한 객체 전달)
			System.out.println("나머지 모든 예외 처리! - " + e.getMessage());
//		} catch(NullPointerException e) {
//			// => Exception 예외 처리 아래쪽에 다른 예외 클래스 지정 불가능
			//    if문과 마찬가지로 위에서부터 차례대로 체크하므로 
			//    하위클래스부터 상위클래스 순으로 예외 처리 필수!
		}
		
		System.out.println("프로그램 종료!");
		
	}

}


















public class Ex2 {

	public static void main(String[] args) {
		/*
		 * finally 블록
		 * => 예외 발생 여부와 관계없이 무조건 수행해야하는 문장을 기술
		 */
		System.out.println("프로그램 시작!");
		
		try {
			String str = null;
			System.out.println(str.length());
		} catch (Exception e) {
			System.out.println("NullPointException 예외 처리!");
//			e.printStackTrace();
		} finally {
			System.out.println("finally - 예외 발생 여부와 관계없이 실행할 블록");
		}
		
		System.out.println("프로그램 끝!");
		
		System.out.println("--------------------------------");
		
		System.out.println("프로그램 시작2");
		
		int num = 1;
		method(num);
		
		System.out.println("프로그램 끝2");
	}
	
	public static void method(int num) {
		System.out.println("메서드 시작");
		
		try {
			
			if(num != 0) {
				return;
				// return 문에 의해 현재 메서드를 종료하고 돌아가야하므로
				// 아래쪽 try 블록 내의 문장은 물론 try 블록 바깥의 문장도 실행 X
				// => 그러나! finally 블록 내의 문장은 실행 후에 리턴됨
			}
			
			System.out.println(3 / num);
		} catch (Exception e) {
			System.out.println("ArithmeticException 예외 처리!");
		} finally {
			System.out.println("finally - 예외 발생 여부와 관계없이 실행할 블록");
		}
		
		System.out.println("메서드 끝");
	}
	

}






















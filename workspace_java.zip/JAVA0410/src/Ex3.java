
public class Ex3 {

	public static void main(String[] args) {
		/*
		 * 예외 처리 위임
		 * - 자신이 직접 예외를 처리하지 않고 자신의 메서드를 호출한 곳으로
		 *   throws 키워드를 사용하여 예외 처리를 위임(전달)
		 */
		
//		팀장();
		// => 팀장() 으로부터 예외를 위임받은 곳이 main() 메서드 일 경우
		//    더 이상 위임할 곳이 없으므로 최종적으로 main() 메서드에서 예외 처리 필요!
		
		try {
			팀장();
		} catch (Exception e) {
			System.out.println("main() 메서드에서 예외 처리!");
		}
	}
	
	public static void 팀장() throws Exception {
//		대리();
		// => 대리() 에서 발생한 예외를 위임받았을 경우
		//    대리() 메서드 호출 코드에서 예외 처리에 대한 책임이 발생한다!
		// => 따라서, 예외를 위임받은 곳에서 예외 처리를 직접 수행하거나
		//    또는, 다시 예외를 위임할 수 있다.
		
//		try {
//			대리();
//		} catch (ClassNotFoundException e) {
//			System.out.println("팀장이 대신 예외 처리!");
//		}
		
		대리();
		
	}
	
	public static void 대리() throws ClassNotFoundException {
//		try {
//			Class.forName("클래스"); // 예외 발생 코드
//		} catch (ClassNotFoundException e) {
//			System.out.println("대리가 직접 예외 처리!");
//		} 
		
		// 예외를 위임하는 경우
		Class.forName("클래스"); // 예외 발생 코드
		// => 직접 예외 처리를 하지 않고 위임하는 경우
		//    메서드 헤더의 마지막 부분에 throws 키워드를 쓰고 뒷부분에
		//    예외 클래스명을 명시함(1개 또는 복수개 지정 가능)
		
	}

}























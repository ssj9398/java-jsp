
public class Ex4 {

	public static void main(String[] args) {
		int score = 185;
		try {
			grade(score); // Exception 클래스 타입 예외처리 책임 발생
		} catch (Exception e) {
//			e.printStackTrace();
			System.out.println(e.getMessage());
			// => 생성자에 전달한 메세지가 예외 원인 메세지 부분에 출력됨
		}
	}
	
	public static void grade(int score) throws Exception {
		
		if(score < 0 || score > 100) {
//			System.out.println("점수 입력 오류!");
			// 사용자 기준에서의 예외를 직접 발생시키기 위해
			// throw 키워드 뒤에 예외 클래스 객체를 생성하여 던짐(throw)
			// => 이 때, 파라미터로 예외 메세지도 함께 전달 가능
			throw new Exception("점수 입력 오류(0 ~ 100 사이 값 입력 필수!) ");
			// => 직접 예외를 처리하지 않고 throws 키워드로 호출한 곳으로 예외 전달
		} else if(score >= 90 && score <= 100) {
			System.out.println("A학점");
		} else if(score >= 80) {
			System.out.println("B학점");
		}
		
	}

}

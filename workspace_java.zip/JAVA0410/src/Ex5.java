public class Ex5 {

	public static void main(String[] args) {
		/*
		 * 사용자 정의 예외 클래스
		 * - 기존의 API 에서 제공하는 클래스 외에 별도의 예외를 처리하는 클래스
		 * - 주로 Exception 클래스를 상속받아 정의
		 */
		
		Ex5 ex = new Ex5();
		
		System.out.println("로그인 시작!");
		
		try {
			boolean result = ex.isLogin("root", "1234");
		} catch (LoginFailException e) {
//			e.printStackTrace();
			System.out.println(e.getLocalizedMessage());
		}
		
		System.out.println("로그인 끝!");
		
	}
	
	public boolean isLogin(String id, String password) throws LoginFailException {
		String serverId = "admin";
		String serverPassword = "1234";
		
		// 아이디 또는 패스워드가 틀렸을 경우 boolean 타입을 리턴하는 것이 아니라
		// 사용자 정의 예외 클래스를 생성하여 던짐(throw)
		if(!id.equals(serverId)) {
			throw new LoginFailException(
					LoginFailException.ErrorCode.INVALID_ID, id);
		} else if(!password.equals(serverPassword)) {
			throw new LoginFailException(
					LoginFailException.ErrorCode.INVALID_PASSWORD, password);
		}
		
		return true;
		
	}

}

class LoginFailException extends Exception {
	enum ErrorCode { // ID, Password 중 실패한 항목을 저장할 enum 상수 지정
		INVALID_ID, INVALID_PASSWORD
	}
	
	ErrorCode errorCode;

	public LoginFailException(ErrorCode errorCode, String message) {
		super(message);
		this.errorCode = errorCode;
	}

	
	// 예외 메세지를 수정하기 위해 getMessage() 가 아닌 
	// getLocalizedMessage() 메서드 오버라이딩
	@Override
	public String getLocalizedMessage() {
		String msg = getMessage(); // 기존 메세지 가져오기
		
		switch (errorCode) {
			case INVALID_ID:
				msg += " : 아이디를 확인하세요!";
				break;
			case INVALID_PASSWORD:
				msg += " : 패스워드를 확인하세요!";
				break;
		}
		
		return msg; // 전달할 메세지 리턴
	}
	
	
	
}











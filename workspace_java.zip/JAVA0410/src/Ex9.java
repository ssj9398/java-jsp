import java.time.LocalTime;

public class Ex9 {

	public static void main(String[] args) {
		for(int i = 1; i <= 60; i++) {
			System.out.println(LocalTime.now());
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

}

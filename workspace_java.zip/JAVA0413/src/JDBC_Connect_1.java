
public class JDBC_Connect_1 {

	public static void main(String[] args) {
		/*
		 * JDBC(Java DataBase Connectivity)
		 * - 자바에서 데이터베이스에 접근하기 위한 API
		 * 
		 * < JDBC 구현 4단계 >
		 * 1. 드라이버 로드
		 *    - Class.forName() 메서드를 호출하여 DB 연결에 필요한 드라이버 클래스 로드
		 *      => ex) MySQL 의 경우 com.mysql.jdbc.Driver 클래스를 지정
		 *             단, 미리 해당 드라이버가 포함된 jar 파일이 추가되어 있어야 함
		 *             (MySQL : mysql-connector-XXX.jar, Oracle : ojdbcX.jar 등)
		 *    - 드라이버 클래스 위치가 잘못 지정되었거나 클래스 파일이 없을 경우
		 *      ClassNotFoundException 예외 발생
		 *      
		 * 2. DB 연결
		 * 3. PreparedStatement 객체를 Connection 객체와 연결하여 SQL 구문 전달
		 * 4. SQL 구문 실행 및 결과 처리
		 */
		try {
			// 1단계. 드라이버 로드
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("드라이버 로드 성공!");
		} catch (ClassNotFoundException e) {
			System.out.println("드라이버 로드 실패!");
		}
	}

}

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class JDBC_Connect_2 {

	public static void main(String[] args) {
		/*
		 * JDBC(Java DataBase Connectivity)
		 * - 자바에서 데이터베이스에 접근하기 위한 API
		 * 
		 * < JDBC 구현 4단계 >
		 * 1. 드라이버 로드
		 *    - Class 클래스의 static 메서드 forName() 메서드를 호출하여 
		 *      DB 연결에 필요한 드라이버 클래스 로드
		 *      => ex) MySQL 의 경우 com.mysql.jdbc.Driver 클래스를 지정
		 *             단, 미리 해당 드라이버가 포함된 jar 파일이 추가되어 있어야 함
		 *             (MySQL : mysql-connector-XXX.jar, Oracle : ojdbcX.jar 등)
		 *    - 드라이버 클래스 위치가 잘못 지정되었거나 클래스 파일이 없을 경우
		 *      ClassNotFoundException 예외 발생
		 *      
		 * 2. DB 연결
		 *    - DriverManager 클래스의 static 메서드인 
		 *      getConnection() 메서드를 호출하여 DB 연결(접속)을 수행
		 *      => 파라미터로 DB 접속 URL, DB 계정명, DB 패스워드를 전달
		 *      => ex) MySQL 의 URL = "jdbc:mysql://DB접속주소:포트번호/DB명"
		 *    - 연결에 성공하면 DB 연결 정보를 담은 Connection 타입 객체가 리턴됨
		 * 
		 * 3. PreparedStatement 객체를 Connection 객체와 연결하여 SQL 구문 전달
		 * 
		 * 4. SQL 구문 실행 및 결과 처리
		 * 
		 */
		
		Connection con = null;
		
		try {
			// 1단계. 드라이버 로드
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("드라이버 로드 성공!");
			
			// 2단계. DB 연결
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/java", "root", "1234");
			System.out.println("DB 연결 성공!");
		} catch (ClassNotFoundException e) {
			System.out.println("드라이버 로드 실패! - " + e.getMessage());
		} catch (SQLException e) {
			System.out.println("DB 연결 실패! - " + e.getMessage());
		} finally {
			// finally 블록 내에서 DB 관련 자원 반환 필수!
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		
	}

}

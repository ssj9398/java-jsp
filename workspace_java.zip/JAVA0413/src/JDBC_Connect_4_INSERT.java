import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

public class JDBC_Connect_4_INSERT {

	public static void main(String[] args) {
		/*
		 * JDBC(Java DataBase Connectivity)
		 * - 자바에서 데이터베이스에 접근하기 위한 API
		 * 
		 * < JDBC 구현 4단계 >
		 * 1. 드라이버 로드
		 *    - Class 클래스의 static 메서드 forName() 메서드를 호출하여 
		 *      DB 연결에 필요한 드라이버 클래스 로드
		 *      => ex) MySQL 의 경우 com.mysql.jdbc.Driver 클래스를 지정
		 *             단, 미리 해당 드라이버가 포함된 jar 파일이 추가되어 있어야 함
		 *             (MySQL : mysql-connector-XXX.jar, Oracle : ojdbcX.jar 등)
		 *    - 드라이버 클래스 위치가 잘못 지정되었거나 클래스 파일이 없을 경우
		 *      ClassNotFoundException 예외 발생
		 *      
		 * 2. DB 연결
		 *    - DriverManager 클래스의 static 메서드인 
		 *      getConnection() 메서드를 호출하여 DB 연결(접속)을 수행
		 *      => 파라미터로 DB 접속 URL, DB 계정명, DB 패스워드를 전달
		 *      => ex) MySQL 의 URL = "jdbc:mysql://DB접속주소:포트번호/DB명"
		 *    - 연결에 성공하면 DB 연결 정보를 담은 Connection 타입 객체가 리턴됨
		 * ------------------- 2단계까지는 DB 제품별로 달라지는 부분 -----------------
		 * ------------------- 3단계부터는 모든 DB 에 대해 공통적인 부분 -----------------
		 * 3. SQL 구문 실행
		 *    - Connection 객체의 prepareStatement() 메서드를 호출하여
		 *      파라미터로 SQL 구문을 전달하여 PreparedStatement 객체 연결
		 *      => PreparedStatement 타입 객체 리턴됨 
		 *    - PreparedStatement 객체의 executeXXX() 메서드를 호출하여 SQL 구문 실행
		 *      => DB 에 조작을 가하는 SQL 문장 실행 시 : executeUpdate()
		 *         ex) CREATE, INSERT, UPDATE, DELETE 등
		 *      => DB 레코드 조회를 수행하는 SQL 문장 실행 시 : executeQuery()
		 *         ex) SELECT
		 *    - PreparedStatement 객체에 전달하는 쿼리문은 외부로부터 전달받은 데이터를
		 *      쿼리문에 삽입하기 위해 변수와 문자열 결합을 수행할 수도 있지만
		 *      SQL 삽입 공격을 방지하기 위해 데이터 자리를 만능문자(?)로 표시하고
		 *      별도의 setXXX() 메서드를 호출하여 데이터를 대체하면서 입력값 검증 수행
		 *      => setXXX() 메서드의 XXX 은 전달할 데이터의 자바 데이터타입명
		 *      => 파라미터로 만능문자(?)의 순서번호와 전달할 데이터를 전달
		 *      ex) 정수형 데이터 idx 변수값을 첫번째 ? 부분에 전달할 경우
		 *          pstmt.setInt(1, idx);
		 * 
		 * 4. 결과 처리
		 *    - PreparedStatement 객체의 executeXXX() 메서드를 호출할 경우
		 *      메서드 종류에 따라 각각 다른 리턴값이 리턴됨
		 *    1) executeUpdate() : int형 데이터 리턴됨. 작업 완료된 레코드 수 리턴
		 *    2) executeQuery() : ResultSet 타입 객체 리턴됨. 조회된 레코드 목록 리턴
		 * 
		 */
		// 외부로부터 전달받은 번호(idx)를 INSERT 하는 문장 작성
		int idx = 10;
		
		// JDBC 사용에 필요한 4가지 문자열
		// 드라이버 위치, URL, 계정명, 패스워드
		String driver = "com.mysql.jdbc.Driver";
		String url = "jdbc:mysql://localhost:3306/java";
		String user = "root";
		String password = "1234";
		
		Connection con = null;
		PreparedStatement pstmt = null;
		
		try {
			// 1단계. 드라이버 로드
			Class.forName(driver);
			System.out.println("드라이버 로드 성공!");
			
			// 2단계. DB 연결
			con = DriverManager.getConnection(url, user, password);
			System.out.println("DB 연결 성공!");
			
			// 3. PreparedStatement 객체 생성
//			String sql = "INSERT INTO test VALUES(" + idx + ")";
			String sql = "INSERT INTO test VALUES(?)";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, idx);
			
			int result = pstmt.executeUpdate(); // 실행 결과 리턴(INSERT 된 레코드 수)
			System.out.println("SQL 구문 실행 성공!");
			
			// 4. 실행 결과 처리
			if(result > 0) {
				System.out.println("INSERT 작업 성공! - " + result + "개 레코드");
			}
			
		} catch (ClassNotFoundException e) {
			System.out.println("드라이버 로드 실패! - " + e.getMessage());
		} catch (SQLException e) {
			// getConnection() 호출에 실패하거나 executeXXX() 메서드 호출에 실패할 경우
			System.out.println("DB 연결 실패! 또는 SQL 구문 오류 발생! - " + e.getMessage());
		} finally {
			// finally 블록 내에서 DB 관련 자원 반환 필수!
			try {
				// 생성된 순서의 역순으로 반환
				pstmt.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		
	}

}

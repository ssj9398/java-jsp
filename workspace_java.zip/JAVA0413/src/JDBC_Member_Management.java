import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class JDBC_Member_Management {
	// JDBC 사용에 필요한 4가지 문자열
	// 드라이버 위치, URL, 계정명, 패스워드
	String driver = "com.mysql.jdbc.Driver";
	String url = "jdbc:mysql://localhost:3306/java";
	String user = "root";
	String password = "1234";
	
	// JDBC 작업에 필요한 변수 선언
	Connection con = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	
	public JDBC_Member_Management() {
//		insert();
//		update();
		delete();
		select();
	}
	
//	public void init() {}
	
	// 1단계, 2단계를 공통으로 수행하여 Connection 객체를 리턴하는 메서드 정의
	public void getConnection() {
		try {
			// 1단계. 드라이버 로드
			Class.forName(driver);
			System.out.println("드라이버 로드 성공!");
			
			// 2단계. DB 연결
			con = DriverManager.getConnection(url, user, password);
			System.out.println("DB 연결 성공!");
		} catch (ClassNotFoundException e) {
			System.out.println("드라이버 로드 실패! - " + e.getMessage());
		} catch (SQLException e) {
			System.out.println("DB 연결 실패! - " + e.getMessage());
		}
	}
	
	public void insert() {
		// 외부로부터 전달받은 이름, 나이, E-Mail, 주민번호를 추가
		String name = "홍길동";
		int age = 20;
		String email = "hong@hong.com";
		String jumin = "901010-1234567";
		
		try {
			// Connection 객체 확보를 위해 별도의 작업을 수행하는 메서드 호출
			getConnection();
			
			// 3. SQL 구문 실행
			String sql = "INSERT INTO member VALUES(null,?,?,?,?)";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, name);
			pstmt.setInt(2, age);
			pstmt.setString(3, email);
			pstmt.setString(4, jumin);
			
			int result = pstmt.executeUpdate(); // 실행 결과 리턴(INSERT 된 레코드 수)
			System.out.println("SQL 구문 실행 성공!");
			
			// 4. 실행 결과 처리
			if(result > 0) {
				System.out.println("INSERT 작업 성공! - " + result + "개 레코드");
			}
			
		} catch (SQLException e) {
			// executeXXX() 메서드 호출에 실패할 경우
			System.out.println("SQL 구문 오류 발생! - " + e.getMessage());
		} finally {
			// finally 블록 내에서 DB 관련 자원 반환 필수!
			try {
				// 생성된 순서의 역순으로 반환
				pstmt.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public void update() {
		// 외부로부터 이름, 주민번호를 전달받아 E-Mail 을 변경
		String name = "홍길동";
		String jumin = "901010-1234567";
		String email = "hongildong@hong.com"; // 변경할 E-Mail
		
		try {
			getConnection();
			
			// 3. SQL 구문 실행
			String sql = "UPDATE member SET email=? WHERE name=? AND jumin=?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, email);
			pstmt.setString(2, name);
			pstmt.setString(3, jumin);
			
			int result = pstmt.executeUpdate(); // 실행 결과 리턴(INSERT 된 레코드 수)
			System.out.println("SQL 구문 실행 성공!");
			
			// 4. 실행 결과 처리
			if(result > 0) {
				System.out.println("UPDATE 작업 성공! - " + result + "개 레코드");
			} else {
				System.out.println("UPDATE 작업 실패! - " + result + "개 레코드");
			}
			
		} catch (SQLException e) {
			// executeXXX() 메서드 호출에 실패할 경우
			System.out.println("SQL 구문 오류 발생! - " + e.getMessage());
		} finally {
			// finally 블록 내에서 DB 관련 자원 반환 필수!
			try {
				// 생성된 순서의 역순으로 반환
				pstmt.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public void delete() {
		// 외부로부터 번호(idx)를 전달받아 삭제
		int idx = 31;
		
		try {
			getConnection();
			
			// 3. SQL 구문 실행
			String sql = "DELETE FROM member WHERE idx=?";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, idx);
			
			int result = pstmt.executeUpdate(); // 실행 결과 리턴(INSERT 된 레코드 수)
			System.out.println("SQL 구문 실행 성공!");
			
			// 4. 실행 결과 처리
			if(result > 0) {
				System.out.println("DELETE 작업 성공! - " + result + "개 레코드");
			} else {
				System.out.println("DELETE 작업 실패! - " + result + "개 레코드");
			}
			
		} catch (SQLException e) {
			// executeXXX() 메서드 호출에 실패할 경우
			System.out.println("SQL 구문 오류 발생! - " + e.getMessage());
		} finally {
			// finally 블록 내에서 DB 관련 자원 반환 필수!
			try {
				// 생성된 순서의 역순으로 반환
				pstmt.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	
	}
	
	public void select() {
		// 모든 레코드를 조회하여 출력
		try {
			getConnection();
			
			// 3. SQL 구문 실행
			// 모든 테이블 레코드 조회
			String sql = "SELECT * FROM member";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			// 4. 실행 결과 처리
			while(rs.next()) {
				int idx = rs.getInt("idx");
				String name = rs.getString("name");
				int age = rs.getInt("age");
				String email = rs.getString("email");
				String jumin = rs.getString("jumin");
				
				System.out.println(
						idx + " " + name + " " + age + " " + email + " " + jumin);
			}
			
		} catch (SQLException e) {
			// executeXXX() 메서드 호출에 실패할 경우
			System.out.println("SQL 구문 오류 발생! - " + e.getMessage());
		} finally {
			// finally 블록 내에서 DB 관련 자원 반환 필수!
			try {
				// 생성된 순서의 역순으로 반환
				rs.close();
				pstmt.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public static void main(String[] args) {
		new JDBC_Member_Management();
	}

}

import java.awt.Dimension;

import javax.swing.JFrame;

public class Ex extends JFrame { // JFrame 클래스를 상속받아 창을 생성하는 방법
	/*
	 * 자바 Swing(스윙)
	 * - 자바에서 GUI 구현을 담당하는 API 모음
	 * - 대부분 javax.swing 패키지 내에 클래스들이 존재
	 *   (이벤트 처리를 위한 클래스 등은 별도의 패키지에 존재) 
	 * - JFrame 클래스를 상속받아 사용하거나 인스턴스 생성하여 사용 => 창 관리
	 */
	
	public Ex() {
//		setSize(300, 200); // 창 크기 지정. setSize(가로픽셀크기, 세로픽셀크기)
		// 픽셀 : 화면을 구성하는 점(= 화소)
		// 해상도 : 가로픽셀 * 세로픽셀
		
		// setSize() 메서드의 파라미터로 Dimension 객체 사용 가능
		// => width, height 값을 관리하는 객체
		Dimension d = new Dimension(300, 200); // Dimension 객체 생성
		setSize(d);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // 창 닫기 버튼 기능 설정 
		setVisible(true); // 창 표시 설정
	}
	

	public static void main(String[] args) {
		new Ex();
	}

}

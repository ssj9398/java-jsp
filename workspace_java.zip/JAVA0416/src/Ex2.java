import java.awt.Point;
import java.awt.Rectangle;

import javax.swing.JFrame;

public class Ex2 {
	
	public Ex2() {
		// JFrame 인스턴스를 생성하여 창을 생성하는 방법
//		JFrame f = new JFrame("JFrame 기초"); 
		// => 생성자에 텍스트 전달 시 창의 제목표시줄에 표시
		// => 생성자에 전달하지 않고 setTitle() 메서드에 전달해도 동일함
		JFrame f = new JFrame(); 
		f.setTitle("JFrame 기초");
		f.setSize(400, 300);
		
		// setLocation(x, y) : x, y 좌표 위치에 창을 위치시킴
		// => 기본값은 0, 0 으로 좌측 상단 구석이 기본으로 설정되어 있음
//		f.setLocation(600, 400);
		
		// setLocation() 메서드 파라미터로 Point 객체 전달 가능
		// => Point 객체 : x, y 좌표를 관리하는 객체
//		Point p = new Point(600, 400);
//		f.setLocation(p);
		
		// setBounds(x, y, width, height) = setLocation() + setSize()
		f.setBounds(600, 400, 400, 300);
		
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.setVisible(true);
	}

	public static void main(String[] args) {
		new Ex2();
	}

}

import javax.swing.JFrame;

public class Ex3 {
	
	public Ex3() {
		/*
		 * setDefaultCloseOperation() 메서드
		 * - 프레임 닫기 버튼에 대한 동작 지정
		 * - 파라미터로 JFrame 클래스의 상수를 사용 가능
		 *   1) JFrame.DO_NOTHING_ON_CLOSE : 닫기 버튼에 대한 동작 X
		 *   2) JFrame.HIDE_ON_CLOSE : 현재 창(JFrame 객체)을 숨김(종료 X) - 기본값
		 *   3) JFrame.DISPOSE_ON_CLOSE : 현재 창 종료. 다른 창(JFrame 객체)은 유지됨
		 *   4) JFrame.EXIT_ON_CLOSE : 현재 어플리케이션 종료. 모든 창(JFrame 객체) 종료
		 */
		JFrame f = new JFrame("프레임1");
		f.setBounds(300, 300, 400, 300);
		f.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		f.setVisible(true);
		
		// 또 다른 창을 생성하려면 새로운 JFrame 객체 생성
		JFrame f2 = new JFrame("프레임2");
		f2.setBounds(800, 300, 400, 300);
		f2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f2.setVisible(true);
		
	}

	public static void main(String[] args) {
		new Ex3();
	}

}

















import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;

public class Ex4 {
	
	public Ex4() {
		JFrame f = new JFrame("버튼 생성 연습");
		f.setBounds(600, 400, 300, 200);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		/*
		 * javax.swing.JButton 클래스
		 * - 버튼 기능을 담당하는 클래스
		 * - 생성자에 문자열 전달 시 Button 에 표시할 텍스트 지정 가능
		 * - 생성 후 프레임 또는 패널 등의 컨테이너 객체에 부착(추가)해서 사용
		 *   => 해당 컨테이너 객체의 add() 메서드를 사용
		 */
		JButton btn = new JButton("버튼");
		f.add(btn);
		
		btn.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				System.out.println("버튼 클릭!");
			}
		});
		
		
		f.setVisible(true);
	}

	public static void main(String[] args) {
		new Ex4();
	}

}

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class JDBC_Member_Management {
	// JDBC 사용에 필요한 4가지 문자열
	// 드라이버 위치, URL, 계정명, 패스워드
	String driver = "com.mysql.jdbc.Driver";
	String url = "jdbc:mysql://localhost:3306/java";
	String user = "root";
	String password = "1234";
	
	// JDBC 작업에 필요한 변수 선언
	Connection con = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	
	public JDBC_Member_Management() {
//		insert();
//		update();
		delete();
		select();
	}
	
//	public void init() {}
	
	// 1단계, 2단계를 공통으로 수행하여 Connection 객체를 리턴하는 메서드 정의
	public void getConnection() {
		try {
			// 1단계. 드라이버 로드
			Class.forName(driver);
			System.out.println("드라이버 로드 성공!");
			
			// 2단계. DB 연결
			con = DriverManager.getConnection(url, user, password);
			System.out.println("DB 연결 성공!");
		} catch (ClassNotFoundException e) {
			System.out.println("드라이버 로드 실패! - " + e.getMessage());
		} catch (SQLException e) {
			System.out.println("DB 연결 실패! - " + e.getMessage());
		}
	}
	
	public void insert() {
		// 외부로부터 전달받은 이름, 나이, E-Mail, 주민번호를 추가
		String name = "호길동";
		int age = 20;
		String email = "ho@ho.com";
		String jumin = "901010-1234566";
		
		// DTO 객체 생성하여 전달할 데이터 저장
		MemberDTO dto = new MemberDTO(0, name, age, email, jumin);
		
		// DAO 객체 생성하여 insert() 메서드 호출
		// 파라미터 : MemberDTO 객체, 리턴타입 int로 리턴받기
		MemberDAO dao = new MemberDAO();
		int insertCount = dao.insert(dto);
		
		if(insertCount > 0) {
			System.out.println("회원 추가 성공!");
		} else {
			System.out.println("회원 추가 실패!");
		}
	}
	
	public void update() {
		// 외부로부터 이름, 주민번호를 전달받아 E-Mail 을 변경
		String name = "홍길동";
		String jumin = "901010-1234567";
		String email = "hongildong@hong.com"; // 변경할 E-Mail
		
		// DTO 객체 생성하여 전달할 데이터 저장
		MemberDTO dto = new MemberDTO(0, name, 0, email, jumin);
		
		// DAO 객체 생성하여 update() 메서드 호출
		// 파라미터 : MemberDTO 객체, 리턴타입 int로 리턴받기
		MemberDAO dao = new MemberDAO();
		int updateCount = dao.update(dto);
		
		if(updateCount > 0) {
			System.out.println("회원 수정 성공!");
		} else {
			System.out.println("회원 수정 실패!");
		}
		
	}
	
	public void delete() {
		// 외부로부터 번호(idx)를 전달받아 삭제
		int idx = 33;
		
		// DTO 객체 생성하여 전달할 데이터 저장
		MemberDTO dto = new MemberDTO(idx, null, 0, null, null);
		
		// DAO 객체 생성하여 delete() 메서드 호출
		// 파라미터 : MemberDTO 객체, 리턴타입 int로 리턴받기
		MemberDAO dao = new MemberDAO();
		int deleteCount = dao.delete(dto);
		
		if(deleteCount > 0) {
			System.out.println("회원 삭제 성공!");
		} else {
			System.out.println("회원 삭제 실패!");
		}
	
	}
	
	public void select() {
		// 모든 레코드를 조회하여 출력
		MemberDAO dao = new MemberDAO();
		
		// select() 메서드 호출하여 조회 결과를 ArrayList 객체로 리턴받아 출력
		ArrayList<MemberDTO> list = dao.select();
		
		for(MemberDTO dto : list) {
			int idx = dto.getIdx();
			String name = dto.getName();
			int age = dto.getAge();
			String email = dto.getEmail();
			String jumin = dto.getJumin();
			
			System.out.println(
					idx + " " + name + " " + age + " " + email + " " + jumin);
		}
		
	}

	public static void main(String[] args) {
		new JDBC_Member_Management();
	}

}

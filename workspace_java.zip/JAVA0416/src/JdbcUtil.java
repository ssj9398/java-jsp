import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.commons.dbcp2.BasicDataSource;

public class JdbcUtil {
	// DB 작업을 위한 부가적인 작업(Connection 객체 생성, 자원 반환 등)을 수행하는 클래스
	BasicDataSource ds = null;
	
	public JdbcUtil() {
		// JDBC 사용에 필요한 4가지 문자열
		// 드라이버 위치, URL, 계정명, 패스워드
		String driver = "com.mysql.jdbc.Driver";
		String url = "jdbc:mysql://localhost:3306/java";
		String user = "root";
		String password = "1234";
		
		// DBCP 를 사용하여 Connection Pool 생성
		// 1. BasicDataSource 객체 생성
		ds = new BasicDataSource();
		// 2. BasicDataSource 객체를 사용하여 Connection 을 위한 설정
		ds.setDriverClassName(driver);
		ds.setUrl(url);
		ds.setUsername(user);
		ds.setPassword(password);
		ds.setInitialSize(4); // 기본 Connection 객체 4개 생성하여 공유하도록 지정
	}
	
	public Connection getConnection() {
		// DB 연결 객체인 Connection 객체를 가져오는 작업
		Connection con = null;
		
		try {
			// BasicDataSource 객체(커넥션풀)로부터 Connection 객체 가져오기
			con = ds.getConnection();
			
			// JDBC 에서 기본 설정값인 Auto Commit 기능 해제
			con.setAutoCommit(false);
		} catch (SQLException e) {
//			e.printStackTrace();
			System.out.println("DB 연결 실패! - " + e.getMessage());
		}
		
		return con;
	}
	
	// commit, rollback, close 기능을 수행하는 메서드 정의
	public void commit(Connection con) {
		try {
			con.commit();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void rollback(Connection con) {
		try {
			con.rollback();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void close(Connection con) {
		try {
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void close(PreparedStatement pstmt) {
		try {
			pstmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void close(ResultSet rs) {
		try {
			rs.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	
}
























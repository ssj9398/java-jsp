import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class MemberDAO {

	// 회원 추가 작업에 필요한 DTO 객체를 전달받아 INSERT 작업 수행
	public int insert(MemberDTO dto) {
		JdbcUtil jdbcUtil = new JdbcUtil();
		Connection con = jdbcUtil.getConnection();
		
		PreparedStatement pstmt = null;
		
		int insertCount = 0;
		
		try {
			// 3. SQL 구문 실행
			String sql = "INSERT INTO member VALUES(null,?,?,?,?)";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, dto.getName());
			pstmt.setInt(2, dto.getAge());
			pstmt.setString(3, dto.getEmail());
			pstmt.setString(4, dto.getJumin());
			
			insertCount = pstmt.executeUpdate(); // 실행 결과 리턴(INSERT 된 레코드 수)
			System.out.println("SQL 구문 실행 성공!");
			
			// insertCount > 0 일 때 성공이므로 commit() 수행
			// 아니면 rollback() 수행
			if(insertCount > 0) {
				con.commit();
			} else {
				con.rollback();
			}
			
		} catch (SQLException e) {
			// executeXXX() 메서드 호출에 실패할 경우
			System.out.println("SQL 구문 오류 발생! - " + e.getMessage());
		} finally {
			// finally 블록 내에서 DB 관련 자원 반환 필수!
			jdbcUtil.close(pstmt);
			jdbcUtil.close(con);
		}
		
		return insertCount;
		
	}
	
	public int update(MemberDTO dto) {
		JdbcUtil jdbcUtil = new JdbcUtil();
		Connection con = jdbcUtil.getConnection();
		
		PreparedStatement pstmt = null;
		
		int updateCount = 0;
		
		try {
			// 3. SQL 구문 실행
			String sql = "UPDATE member SET email=? WHERE name=? AND jumin=?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, dto.getEmail());
			pstmt.setString(2, dto.getName());
			pstmt.setString(3, dto.getJumin());
			
			updateCount = pstmt.executeUpdate(); // 실행 결과 리턴(UPDATE 된 레코드 수)
			System.out.println("SQL 구문 실행 성공!");
			
			// updateCount > 0 일 때 성공이므로 commit() 수행
			// 아니면 rollback() 수행
			if(updateCount > 0) {
				con.commit();
			} else {
				con.rollback();
			}
			
		} catch (SQLException e) {
			// executeXXX() 메서드 호출에 실패할 경우
			System.out.println("SQL 구문 오류 발생! - " + e.getMessage());
		} finally {
			// finally 블록 내에서 DB 관련 자원 반환 필수!
			jdbcUtil.close(pstmt);
			jdbcUtil.close(con);
		}
		
		return updateCount;
	}
	
	public int delete(MemberDTO dto) {
		JdbcUtil jdbcUtil = new JdbcUtil();
		Connection con = jdbcUtil.getConnection();
		
		PreparedStatement pstmt = null;
		
		int deleteCount = 0;
		
		try {
			// 3. SQL 구문 실행
			String sql = "DELETE FROM member WHERE idx=?";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, dto.getIdx());
			
			deleteCount = pstmt.executeUpdate(); // 실행 결과 리턴(DELETE 된 레코드 수)
			System.out.println("SQL 구문 실행 성공!");
			
			// deleteCount > 0 일 때 성공이므로 commit() 수행
			// 아니면 rollback() 수행
			if(deleteCount > 0) {
				con.commit();
			} else {
				con.rollback();
			}
			
		} catch (SQLException e) {
			// executeXXX() 메서드 호출에 실패할 경우
			System.out.println("SQL 구문 오류 발생! - " + e.getMessage());
		} finally {
			// finally 블록 내에서 DB 관련 자원 반환 필수!
			jdbcUtil.close(pstmt);
			jdbcUtil.close(con);
		}
		
		return deleteCount;
	}
	
	public ArrayList<MemberDTO> select() {
		JdbcUtil jdbcUtil = new JdbcUtil();
		Connection con = jdbcUtil.getConnection();
		
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		ArrayList<MemberDTO> list = null;
		
		try {
			// 3. SQL 구문 실행
			// 모든 테이블 레코드 조회
			String sql = "SELECT * FROM member";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			// 4. 실행 결과 처리
			// 조회 결과를 레코드별로 MemberDTO 객체에 담은 후
			// MemberDTO 객체를 ArrayList 객체에 저장하여 리턴
			list = new ArrayList<MemberDTO>();
			
			while(rs.next()) {
				// 1개 레코드 조회 결과를 MemberDTO 객체에 저장
				int idx = rs.getInt("idx");
				String name = rs.getString("name");
				int age = rs.getInt("age");
				String email = rs.getString("email");
				String jumin = rs.getString("jumin");
				
				MemberDTO dto = new MemberDTO(idx, name, age, email, jumin);
				// MemberDTO 객체를 ArrayList 객체에 추가
				list.add(dto);
			}
		} catch (SQLException e) {
			// executeXXX() 메서드 호출에 실패할 경우
			System.out.println("SQL 구문 오류 발생! - " + e.getMessage());
		} finally {
			// finally 블록 내에서 DB 관련 자원 반환 필수!
			jdbcUtil.close(rs);
			jdbcUtil.close(pstmt);
			jdbcUtil.close(con);
		}
		
		return list;
	}
	
}

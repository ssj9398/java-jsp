
public class MemberDTO {
	/*
	 * DTO(Data Transfer Object, 데이터 전송 객체)
	 * - Presentation Logic 과 Business Logic 사이에서 작업에 필요한 데이터를
	 *   저장하여 전송하는데 사용되는 객체
	 * - XXXDTO 또는 XXXBean 클래스 형태의 이름을 갖는다
	 * - 멤버변수, 생성자, Getter/Setter 메서드로 구성
	 */
	// 멤버변수 선언 - DB 테이블 컬럼과 동일하게 선언
	private int idx;
	private String name;
	private int age;
	private String email;
	private String jumin;
	
	// 생성자 정의 - 필요에 따라 기본생성자와 파라미터생성자 정의
	public MemberDTO() {}
	
	public MemberDTO(int idx, String name, int age, String email, String jumin) {
		this.idx = idx;
		this.name = name;
		this.age = age;
		this.email = email;
		this.jumin = jumin;
	}

	// Getter/Setter 정의
	public int getIdx() {
		return idx;
	}
	
	public void setIdx(int idx) {
		this.idx = idx;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public int getAge() {
		return age;
	}
	
	public void setAge(int age) {
		this.age = age;
	}
	
	public String getEmail() {
		return email;
	}
	
	public void setEmail(String email) {
		this.email = email;
	}
	
	public String getJumin() {
		return jumin;
	}
	
	public void setJumin(String jumin) {
		this.jumin = jumin;
	}
	
}
























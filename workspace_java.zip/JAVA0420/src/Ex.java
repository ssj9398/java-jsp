

import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Ex extends JFrame {
	
	public Ex() {
		showFrame();
	}
	
	public void showFrame() {
		/*
		 * Layout(레이아웃)
		 * - 화면을 구성하는 형태(배치)
		 * 
		 * BorderLayout
		 * - 대상 컨테이너를 동, 서, 남, 북, 중앙 5개의 영역으로 분할하여 컴포넌트 배치
		 * - JFrame 객체(프레임)의 기본 레이아웃(별도 설정 없으면 BorderLayout 적용됨)
		 * - 한 영역 당 1개의 컨테이너 또는 컴포넌트 배치 가능
		 *   => 한 영역에 두 개 이상의 컴포넌트 등을 배치할 경우
		 *      마지막에 배치된 대상이 표시됨(나머지는 뒤에 가려서 보이지 않음)
		 * - 배치할 영역을 지정하는 경우 BorderLayout.XXX 형태의 상수로 지정
		 *   (ex. 가운데 : BorderLayout.CENTER, 우측 : BorderLayout.EAST)
		 * - BorderLayout 이 지정된 대상의 크기를 변경하더라도
		 *   배치된 컴포넌트 크기만 변경되고, 배열 위치는 변경되지 않는다!
		 */
		
		setBounds(600, 400, 300, 200);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		
		JButton btnCenter = new JButton("CENTER");
		btnCenter.setBackground(Color.MAGENTA);
		// JFrame 등의 컨테이너에 JButton 등의 컴포넌트를 부착할 때
		// add() 메서드를 호출하여 부착할 컴포넌트 지정
		// => 이 때, BorderLayout 의 경우 부착 시 부착할 영역 이름을 명시해야하며
		//    영역 명시를 생략할 경우 기본 부착 위치는 CENTER 영역이 됨
//		add(btnCenter); // CENTER 영역 지정이 생략되어 있음
		getContentPane().add(btnCenter, BorderLayout.CENTER); // CENTER 영역 지정하여 부착
		
		JButton btnEast = new JButton("EAST");
//		add(btnEast); // CENTER 영역이므로 버튼이 중복되어 EAST 버튼만 중앙에 표시됨
		getContentPane().add(btnEast, BorderLayout.EAST);
		
		JButton btnWest = new JButton("WEST");
		getContentPane().add(btnWest, BorderLayout.WEST);
		
		JButton btnNorth = new JButton("NORTH");
		getContentPane().add(btnNorth, BorderLayout.NORTH);
		
		JButton btnSouth = new JButton("SOUTH");
		getContentPane().add(btnSouth, BorderLayout.SOUTH);
		
		
		// 버튼 5개에 각각 ActionListener 를 연결하여 버튼 클릭 이벤트 처리
		// => 5단계 방식으로 처리
//		btnCenter.addActionListener(new ActionListener() {
//			
//			@Override
//			public void actionPerformed(ActionEvent e) {
//				System.out.println("CENTER 버튼 클릭!");
//			}
//		});
//
//		btnEast.addActionListener(new ActionListener() {
//			
//			@Override
//			public void actionPerformed(ActionEvent e) {
//				System.out.println("EAST 버튼 클릭!");
//			}
//		});
//
//		btnWest.addActionListener(new ActionListener() {
//			
//			@Override
//			public void actionPerformed(ActionEvent e) {
//				System.out.println("WEST 버튼 클릭!");
//			}
//		});
//
//		btnNorth.addActionListener(new ActionListener() {
//			
//			@Override
//			public void actionPerformed(ActionEvent e) {
//				System.out.println("NORTH 버튼 클릭!");
//			}
//		});
//
//		btnSouth.addActionListener(new ActionListener() {
//			
//			@Override
//			public void actionPerformed(ActionEvent e) {
//				System.out.println("SOUTH 버튼 클릭!");
//			}
//		});
		
		
		// 4단계 방식으로 이벤트 처리
		ActionListener listener = new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				System.out.println("버튼 클릭!");
			}
		};
		
		btnCenter.addActionListener(listener);
		btnEast.addActionListener(listener);
		btnWest.addActionListener(listener);
		btnNorth.addActionListener(listener);
		btnSouth.addActionListener(listener);
		
		
		
		setVisible(true);
		
	}

	public static void main(String[] args) {
		new Ex();
	}

}

















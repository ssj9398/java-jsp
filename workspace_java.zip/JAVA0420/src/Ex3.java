

import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JLabel;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

public class Ex3 extends JFrame {
	
	public Ex3() {
		showFrame();
	}
	
	public void showFrame() {
		setBounds(600, 400, 300, 200);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JLabel lbl = new JLabel();
		getContentPane().add(lbl, BorderLayout.SOUTH);
		
		// 마우스 움직임을 감지하는 리스너 : MouseListener
		addMouseListener(new MouseListener() {
			
			@Override
			public void mouseReleased(MouseEvent e) {
				System.out.println("mouseReleased");
			}
			
			@Override
			public void mousePressed(MouseEvent e) {
				System.out.println("mousePressed");
			}
			
			@Override
			public void mouseExited(MouseEvent e) {
				System.out.println("mouseExited");
			}
			
			@Override
			public void mouseEntered(MouseEvent e) {
				System.out.println("mouseEntered");
			}
			
			@Override
			public void mouseClicked(MouseEvent e) {
				System.out.println("mouseClicked");
			}
		});
		
		addMouseMotionListener(new MouseMotionListener() {
			
			@Override
			public void mouseMoved(MouseEvent e) {
//				System.out.println("mouseMoved");
				lbl.setText("X : " + e.getX() + ", Y : " + e.getY());
			}
			
			@Override
			public void mouseDragged(MouseEvent e) {
				System.out.println("mouseDragged");
			}
		});
		
		setVisible(true);
		
	}

	public static void main(String[] args) {
		new Ex3();
	}

}

















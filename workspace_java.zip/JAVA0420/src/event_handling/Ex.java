package event_handling;

import javax.swing.JFrame;

public class Ex extends JFrame {
	
	public Ex() {
		showFrame();
	}
	
	public void showFrame() {
		setBounds(600, 400, 300, 200);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		
		
		setVisible(true);
	}

	public static void main(String[] args) {
		new Ex();
	}

}

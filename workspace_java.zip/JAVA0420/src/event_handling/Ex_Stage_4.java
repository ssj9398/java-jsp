package event_handling;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

import javax.swing.JFrame;

public class Ex_Stage_4 extends JFrame {
	
	public Ex_Stage_4() {
		showFrame();
	}
	
	public void showFrame() {
		setTitle("이벤트 처리 - 4단계");
		setBounds(600, 400, 300, 200);
		
		// 이벤트 처리 4단계.
		// 익명 내부 클래스 형태로 정의
		// => 리스너 인터페이스 또는 어댑터 클래스의 이름을 사용하여
		//    변수선언 및 인스턴스 생성과 추상메서드 구현까지 동시에 수행하는 방법
		// => 개발자가 별도의 이름을 부여하지 않으므로 이름이 없다는 뜻의 익명 클래스가 됨
		WindowAdapter listener = new WindowAdapter() {

			@Override
			public void windowClosing(WindowEvent e) {
				System.out.println("windowClosing");
				System.exit(0);
			}
			
		};
		// => 메서드 내에서 정의한 익명 로컬 내부 클래스이므로
		//    다른 메서드에서는 접근이 불가능하고, 현재 메서드에서만 접근 가능한 객체

		// 이벤트 처리 4단계. 익명 내부 클래스 사용
		// => 별도의 인스턴스 생성 없이 바로 익명클래스 타입 변수 사용
		addWindowListener(listener);
		
		setVisible(true);
	}
	
	public static void main(String[] args) {
		new Ex_Stage_4(); 
	}
	
	// 이벤트 처리 4단계.
	// 익명 내부 클래스 형태로 정의
	// => 리스너 인터페이스 또는 어댑터 클래스의 이름을 사용하여
	//    변수선언 및 인스턴스 생성과 추상메서드 구현까지 동시에 수행하는 방법
	// => 개발자가 별도의 이름을 부여하지 않으므로 이름이 없다는 뜻의 익명 클래스가 됨
//	WindowAdapter listener = new WindowAdapter() {
//
//		@Override
//		public void windowClosing(WindowEvent e) {
//			System.out.println("windowClosing");
//			System.exit(0);
//		}
//		
//	};
	// => 익명 인스턴스 내부 클래스 형태로 정의되었으므로
	//    다른 메서드에서도 접근 가능한 객체
	
	// WindowListener 인터페이스를 사용한 익명 내부 클래스
	WindowListener myWinListener = new WindowListener() {
		
		@Override
		public void windowOpened(WindowEvent e) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void windowIconified(WindowEvent e) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void windowDeiconified(WindowEvent e) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void windowDeactivated(WindowEvent e) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void windowClosing(WindowEvent e) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void windowClosed(WindowEvent e) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void windowActivated(WindowEvent e) {
			// TODO Auto-generated method stub
			
		}
	};
	

}






















package event_handling;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

import javax.swing.JFrame;

public class Ex_Stage_5 extends JFrame {
	
	public Ex_Stage_5() {
		showFrame();
	}
	
	public void showFrame() {
		setTitle("이벤트 처리 - 5단계");
		setBounds(600, 400, 300, 200);
		
		// 이벤트 처리 5단계.
		// 익명 내부 클래스의 임시 객체 형태로 정의하여 사용
		// => 익명 내부 클래스 형태는 동일하나 객체를 한 번 사용하고 끝낼 경우
		//    객체의 주소를 저장하는 참조변수도 필요없으므로
		//    객체가 필요한 파라미터에 객체 생성 코드를 바로 명시하는 것
		// => 동일한 객체를 사용해야할 경우 객체 생성 코드를 중복으로 작성해야함
		addWindowListener(new WindowAdapter() {
			
			@Override
			public void windowClosing(WindowEvent e) {
				System.out.println("windowClosing");
				System.exit(0);
			}
			
		});
		
		setVisible(true);
	}
	
	public static void main(String[] args) {
		new Ex_Stage_5(); 
	}
	
	

}






















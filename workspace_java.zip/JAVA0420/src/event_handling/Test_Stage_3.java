package event_handling;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;

public class Test_Stage_3 extends JFrame {
	
	public Test_Stage_3() {
		showFrame();
	}
	
	public void showFrame() {
		setTitle("3단계 이벤트 처리");
		setBounds(600, 400, 300, 200);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		// JButton 컴포넌트 생성 및 부착
		JButton btn = new JButton("버튼");
		add(btn);
		
		// JButton 컴포넌트에 ActionListener 를 연결하여 이벤트 처리
		// => addXXXListener() 메서드 호출
		// 3단계. 내부클래스 사용
		MyActionListener listener = new MyActionListener();
		btn.addActionListener(listener);
		
		setVisible(true);
	}

	public static void main(String[] args) {
		new Test_Stage_3();
	}

	// 3단계. 내부 클래스 형태로 정의
	class MyActionListener implements ActionListener {
		
		@Override
		public void actionPerformed(ActionEvent e) {
			// 버튼 클릭 시 자동으로 호출되는 메서드
			System.out.println("버튼 클릭!");
		}
		
	}
	
}

















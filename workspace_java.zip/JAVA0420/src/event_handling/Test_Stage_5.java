package event_handling;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;

public class Test_Stage_5 extends JFrame {
	
	public Test_Stage_5() {
		showFrame();
	}
	
	public void showFrame() {
		setTitle("5단계 이벤트 처리");
		setBounds(600, 400, 300, 200);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		// JButton 컴포넌트 생성 및 부착
		JButton btn = new JButton("버튼");
		add(btn);
		
		// JButton 컴포넌트에 ActionListener 를 연결하여 이벤트 처리
		// => addXXXListener() 메서드 호출
		// 5단계. 익명 내부클래스의 임시 객체 사용
		btn.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				System.out.println("버튼 클릭!");
			}
		});
		
		setVisible(true);
	}

	public static void main(String[] args) {
		new Test_Stage_5();
	}

	// 4단계. 익명 인스턴스 내부 클래스 형태로 정의
//	ActionListener listener = new ActionListener() {
//		
//		@Override
//		public void actionPerformed(ActionEvent e) {
//			System.out.println("버튼 클릭!");
//		}
//	};
	
}

















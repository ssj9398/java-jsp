import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.GridLayout;

public class Ex5 extends JFrame {
	
	public Ex5() {
		showFrame();
	}
	
	public void showFrame() {
		setBounds(600, 400, 300, 200);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		
		JPanel p = new JPanel();
		getContentPane().add(p, BorderLayout.CENTER);
		p.setLayout(new GridLayout(3, 1, 0, 5));
		
		JButton btn1 = new JButton("1");
		p.add(btn1);
		
		JButton btn2 = new JButton("2");
		p.add(btn2);
		
		JButton btn3 = new JButton("3");
		p.add(btn3);
		
		// 익명 로컬 내부클래스 형태로 버튼 3개 이벤트 동시에 처리 - 4단계
		ActionListener listener = new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// 이벤트가 발생한 컴포넌트 객체가 ActionEvent 타입 객체로 전달됨
				// 1. getActionCommand() : 해당 컴포넌트의 값(이름 등) 리턴
//				System.out.println(e.getActionCommand()); // 버튼 텍스트 출력됨
				// 2. getSource() : 해당 컴포넌트의 객체 정보 리턴
//				System.out.println(e.getSource());
				
				// getSource() 결과와 버튼 객체를 비교하여 버튼 판별 가능
				if(btn1.equals(e.getSource())) {
					System.out.println("1번 버튼!");
				} else if(btn2.equals(e.getSource())) {
					System.out.println("2번 버튼!");
				} else if(btn3.equals(e.getSource())) {
					System.out.println("3번 버튼!");
				}
				
			}
		};
		
		// 3개의 버튼 모두 1개의 ActionListener 로 처리 - listener 변수 전달
		btn1.addActionListener(listener);
		btn2.addActionListener(listener);
		btn3.addActionListener(listener);
		
		
		setVisible(true);
	}

	public static void main(String[] args) {
		new Ex5();
	}

}

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.GridLayout;
import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;

public class Ex6 extends JFrame {
	
	public Ex6() {
		showFrame();
	}
	
	public void showFrame() {
		setBounds(600, 400, 300, 200);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		// JCheckBox 와 JRadioButton
		// 다중 선택이 가능한 체크박스 : JCheckBox
		// 단일 선택만 가능한 라디오버튼 : JRadioButton
		// => JRadioButton 객체를 ButtonGroup 객체에 추가해야만 단일 선택으로 동작함
//		JPanel p = new JPanel(new GridLayout(3, 1));
//		add(p, BorderLayout.CENTER);
		
		// JFrame 자체를 GridLayout 으로 변경 가능함
		getContentPane().setLayout(new GridLayout(3, 1));
		
		// JPanel 3개를 각 GridLayout 에 부착
		JPanel p1 = new JPanel();
		getContentPane().add(p1);
		
		// 체크박스 또는 라디오버튼 생성 시 텍스트와 함께 boolean 타입 값을 넣으면
		// 기본 선택 여부를 변경할 수 있다.
		JCheckBox cbJava = new JCheckBox("JAVA", true); // 기본으로 체크되도록 지정
		p1.add(cbJava);

		JCheckBox cbJsp = new JCheckBox("JSP");
		cbJsp.setSelected(true); // 별도로 체크 여부 변경 가능
		p1.add(cbJsp);

		JCheckBox cbAndroid = new JCheckBox("ANDROID");
		p1.add(cbAndroid);
		
		
		
		
		JPanel p2 = new JPanel();
		getContentPane().add(p2); 
		
		JRadioButton rbMale = new JRadioButton("남");
		p2.add(rbMale);

//		JRadioButton rbFemale = new JRadioButton("여");
		JRadioButton rbFemale = new JRadioButton("여", true); // 체크 상태를 기본 설정
		p2.add(rbFemale);
		
		
		
		// 라디오버튼 단일 선택을 위해서는 그룹화 필수!
		// => ButtonGroup 객체를 생성한 후 ButtonGroup 객체에 라디오버튼을 추가
		ButtonGroup rGroup = new ButtonGroup();
		rGroup.add(rbMale);
		rGroup.add(rbFemale);
		// 체크박스 객체를 그룹화할 경우 체크박스도 단일선택으로 동작
//		rGroup.add(cbJava);
//		rGroup.add(cbJsp);
//		rGroup.add(cbAndroid);
		
		
		
		// 체크박스 이벤트 처리
		cbJava.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
//				System.out.println("JAVA 클릭");
//				System.out.println(cbJava.isSelected());
				if(cbJava.isSelected()) {
					System.out.println(cbJava.getText() + " 체크됨!");
				} else if(!cbJava.isSelected()) {
					System.out.println(cbJava.getText() + " 체크 해제됨!");
				}
				
			}
		});
		
		cbJsp.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
//				System.out.println("JSP 클릭");
//				System.out.println(cbJsp.isSelected());
				
				// 체크박스 객체의 isSelected() 메서드를 호출하면 체크 여부 판별 가능
//				if(cbJsp.isSelected()) {
//					System.out.println(cbJsp.getText() + " 체크됨!");
//				} else if(!cbJsp.isSelected()) {
//					System.out.println(cbJsp.getText() + " 체크 해제됨!");
//				}
				
				// ItemListener 내의 ItemEvent 타입 객체 파라미터를 사용하여
				// getStateChange() 메서드를 호출해도 체크 여부 판별 가능
				// => 체크 : 1, 체크해제 : 2
				if(e.getStateChange() == 1) {
					System.out.println(cbJsp.getText() + " 체크됨!");
				} else if(e.getStateChange() == 2) {
					System.out.println(cbJsp.getText() + " 체크 해제됨!");
				}
				
			}
		});
		
		// ItemListener 대신 ActionListener 를 사용해도 체크 여부에 따른 동작 처리 가능
		cbAndroid.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				if(cbAndroid.isSelected()) {
					System.out.println(cbAndroid.getText() + " 체크됨!");
				} else if(!cbAndroid.isSelected()) {
					System.out.println(cbAndroid.getText() + " 체크 해제됨!");
				}
			}
		});
		
		
		// 라디오버튼 이벤트 처리
		// => 그룹화로 인해 ItemListener 의 itemStateChanged() 메서드가
		//    라디오버튼 상태가 변할 때 호출되는데
		//    하나가 선택되면서 다른 하나가 해제되므로 두 가지 모두 상태가 변한다
		//    => 따라서, 한 번의 동작으로 2번의 이벤트가 발생하게 되므로 중복 수행됨
		//       isSelected() 메서드 결과가 true 일 때만 동작하도록 하면 된다!
		// => 결론! 라디오버튼의 경우 ActionListener 를 사용하는 것이 편하다!
		//    (단점 : 선택 후 다시 클릭하더라도 중복으로 동작함)
//		rbMale.addItemListener(new ItemListener() {
//			
//			@Override
//			public void itemStateChanged(ItemEvent e) {
//				System.out.println("남 클릭!");
//			}
//		});
//		
//		rbFemale.addItemListener(new ItemListener() {
//			
//			@Override
//			public void itemStateChanged(ItemEvent e) {
//				System.out.println("여 클릭!");
//			}
//		});
		
		
		// ActionListener 를 사용하여 라디오버튼 이벤트 처리 - 4단계
		ActionListener listener = new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// if문을 사용하여 isSelected() 상태에 따라 라디오버튼 구별
				if(rbMale.isSelected()) {
					System.out.println("남 선택됨!");
				} else if(rbFemale.isSelected()) {
					System.out.println("여 선택됨!");
				}
			}
		};
		rbMale.addActionListener(listener);
		rbFemale.addActionListener(listener);
		
		
		
		// 버튼 패널
		JPanel p3 = new JPanel();
		getContentPane().add(p3);  
		
		JButton btnOk = new JButton("확인");
		p3.add(btnOk);
		
		JButton btnReset = new JButton("초기화");
		p3.add(btnReset);
				
		btnReset.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// 체크박스 및 라디오버튼 체크 초기화
				cbJava.setSelected(false);
				cbJsp.setSelected(false);
				cbAndroid.setSelected(false);
				rbMale.setSelected(false);
				rbFemale.setSelected(false);
			}
		});
		
		
		
		setVisible(true);
	}

	public static void main(String[] args) {
		new Ex6();
	}

}

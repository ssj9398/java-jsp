
public class Ex2 {

	public static void main(String[] args) {
		/*
		 * 주석(Comment)
		 * - 비실행문으로, 자바 프로그램 컴파일(번역) 대상에서 제외되는 문장(실행되지 않음)
		 * - 주 용도 : 프로그램 코드에 대한 설명문 등을 작성
		 * 
		 * 1. 단일 주석(한 줄 주석, 라인 주석) =>  // 기호 사용
		 *    - // 기호 뒤의 문장 한 줄을 주석으로 처리
		 *    - 주석 설정 단축키 : 주석 처리할 문장에 커서를 위치한 후 
		 *                         Ctrl + Shift + C 또는 Ctrl + /
		 *    - 주석 해제 단축키도 설정과 동일함
		 *    - 여러줄 주석 처리에도 활용 가능(여러 줄 블럭 지정 후 주석 처리)
		 *    
		 * 2. 범위 주석(블럭 주석) => /* */
		/*    - 주석 기호 사이에 오는 모든 문장을 주석 처리
		 *    - 여러줄에 걸쳐서 모든 범위를 지정할 수도 있다.
		 *    - 주석 설정 단축키 : 주석 처리할 블럭을 정확히 지정한 후
		 *                         Ctrl + Shift + /
		 *                         => 문장들 위치가 자동 조절되므로 단축키 사용 비추천!
		 *    - 주석 해제 단축키 : 주석 처리할 블럭을 정확히 지정한 후
		 *                         Ctrl + Shift + \
		 * 
		 */
		
		// 주석 연습
		System.out.println("1"); // 주석 처리가 되어 있지 않으므로 실행되는 문장
//		System.out.println("2"); // 주석 처리 되어 있으므로 실행되지 않는 문장
//		System.out.println("3");
		System.out.println("4");
		/*System.out.println("5");
		System.out.println("6");
		System.out.println("7");
		System.out.println("8");*/
		System.out.println("9");
		System.out.println("10");

	}

}

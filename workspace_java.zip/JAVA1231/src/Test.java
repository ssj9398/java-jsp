
public class Test {
	
	public static void main(String[] args) {
		System.out.println("이연태");
		System.out.println("901010");
	}
	
	
	
	
	
}


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

// static 메서드를 갖는 JdbcUtil 클래스에 대해 static import 수행할 경우
// JdbcUtil.XXX() 형식으로 메서드를 호출하지 않고, 바로 클래스명 없이 메서드만 호출 가능
//import static db.JdbcUtil.connectDb; // 특정 메서드만 지정하여 import
import static db.JdbcUtil.*; // db 패키지의 JdbcUtil 클래스 내의 모든 메서드 import


public class MemberDAO {
    // --------------------------------------------
    // 싱글톤 패턴을 활용한 MemberDAO 인스턴스 리턴
    private MemberDAO() {}
    
    private static MemberDAO instance = new MemberDAO();

    public static MemberDAO getInstance() {
        return instance;
    }
    // --------------------------------------------
    
    public int insert(MemberDTO dto) {
        Connection con = connectDb();
        PreparedStatement pstmt = null;
        
        try {
            String name = dto.getName();
            int age = dto.getAge();
            String email = dto.getEmail();
            String jumin = dto.getJumin();
            
            // 3단계. SQL 구문 작성 및 실행
            String sql = "INSERT INTO member VALUES (null,?,?,?,?)";
            pstmt = con.prepareStatement(sql);
            pstmt.setString(1, name);
            pstmt.setInt(2, age);
            pstmt.setString(3, email);
            pstmt.setString(4, jumin);
            
            // 4단계. SQL 구문 실행 결과 처리
            int result = pstmt.executeUpdate();
            
            return result; // 실행 결과 리턴
        } catch (SQLException e) {
            System.out.println("DB 연결 실패! 또는 SQL 구문 오류! - " + e.getMessage());
        } finally {
            close(pstmt);
            close(con);
        }
        
        return 0;
        
    }
    
    public int update(MemberDTO dto) {
        Connection con = connectDb();
        PreparedStatement pstmt = null;
        
        try {
            String name = dto.getName();
            String jumin = dto.getJumin();
            
            // 3단계. SQL 구문 실행
            String sql = "UPDATE member SET jumin=? WHERE name=?";
            
            pstmt = con.prepareStatement(sql);
            pstmt.setString(1, jumin);
            pstmt.setString(2, name);
            // 4단계. SQL 구문 실행 결과 처리
            int result = pstmt.executeUpdate();

            return result;
        } catch (SQLException e) {
            System.out.println("DB 연결 실패! 또는 SQL 구문 오류 발생! - " + e.getMessage());
        } finally {
            close(pstmt);
            close(con);
        }
        
        return 0;
        
    }
    
    public int delete(MemberDTO dto) {
        Connection con = connectDb();
        PreparedStatement pstmt = null;
        
        try {
            String name = dto.getName();
            String jumin = dto.getJumin();
            
            // 3단계. SQL 구문 실행
            String sql = "DELETE FROM member WHERE name=? AND jumin=?";
            
            pstmt = con.prepareStatement(sql);
            pstmt.setString(1, name);
            pstmt.setString(2, jumin);
            // 4단계. SQL 구문 실행 결과 처리
            int result = pstmt.executeUpdate();
            
            return result;
        } catch (SQLException e) {
            System.out.println("DB 연결 실패! 또는 SQL 구문 오류 발생! - " + e.getMessage());
        } finally {
            close(pstmt);
            close(con);
        }
        
        return 0;
        
    }
    
    public ArrayList<MemberDTO> select() {
        // member 테이블의 모든 레코드 조회 후 출력
        Connection con = connectDb();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        
        ArrayList<MemberDTO> memberList = null;
        
        try {
            // 3단계. SQL 구문 실행
            // 4단계. SQL 구문 실행 결과 처리
            String sql = "SELECT * FROM member";
            
            pstmt = con.prepareStatement(sql);
            rs = pstmt.executeQuery();
            
            memberList = new ArrayList<MemberDTO>();
            
            while(rs.next()) {
//                int idx = rs.getInt("idx"); // 인덱스 지정 방법
//                String name = rs.getString("name");
//                int age = rs.getInt("age");
//                String email = rs.getString("email");
//                String jumin = rs.getString("jumin");
                
                // MemberDTO 객체를 통해 1개 레코드 데이터를 모두 저장
                MemberDTO dto = new MemberDTO();
                dto.setIdx(rs.getInt("idx"));
                dto.setName(rs.getString("name"));
                dto.setAge(rs.getInt("age"));
                dto.setEmail(rs.getString("email"));
                dto.setJumin(rs.getString("jumin"));
                
                // MemberDTO 객체를 ArrayList 객체에 추가
                memberList.add(dto);
            }
            
            return memberList;
            
        } catch (SQLException e) {
            System.out.println("DB 연결 실패! 또는 SQL 구문 오류 발생! - " + e.getMessage());
        } finally {
            close(rs);
            close(pstmt);
            close(con);
        }
        
        return null;
        
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}

import java.util.ArrayList;

public class MemberInfo {

    public static void main(String[] args) {
        MemberInfo mi = new MemberInfo();
        
        mi.insert();
        mi.update();
        mi.delete();
        mi.select();
    }
    
    public void insert() {
        MemberDAO dao = MemberDAO.getInstance();
        
        int result = 0;
        
//        result = dao.insert("김태희", 30, "kimth@kim.com", "801010-2222222");
        
        // MemberDTO 객체를 사용하여 전달할 데이터 저장
        String name = "김태희";
        int age = 30;
        String email = "kimth@kim.com";
        String jumin = "801010-2222222";
        
        MemberDTO dto = new MemberDTO(0, name, age, email, jumin);
        result = dao.insert(dto);
        
        if(result > 0) {
            System.out.println("INSERT 작업 성공! (" + result + " 개 레코드)");
        } else {
            System.out.println("INSERT 작업 실패!");
        }
        
    }
    
    public void update() {
        MemberDAO dao = MemberDAO.getInstance();
        
        int result = 0;
        
//        result = dao.update("강감찬", "881122-1919191");
        
        String name = "강감찬";
        String jumin = "881122-1919191";
        
        MemberDTO dto = new MemberDTO(0, name, 0, null, jumin);
        result = dao.update(dto);
        
        if(result > 0) {
            System.out.println("UPDATE 작업 성공! (" + result + " 개 레코드)");
        } else {
            System.out.println("UPDATE 작업 실패!");
        }
    }
    
    public void delete() {
        MemberDAO dao = MemberDAO.getInstance();
        
        int result = 0;
        
//        result = dao.delete("강감찬", "881122-1919191");
        
        String name = "강감찬";
        String jumin = "881122-1919191";
        
        MemberDTO dto = new MemberDTO(0, name, 0, null, jumin);
        result = dao.delete(dto);
        
        if(result > 0) {
            System.out.println("DELETE 작업 성공! (" + result + " 개 레코드)");
        } else {
            System.out.println("DELETE 작업 실패!");
        }
    }
    
    public void select() {
        MemberDAO dao = MemberDAO.getInstance();
        
        // SELECT 구문을 실행하여 결과를 ArrayList 객체로 리턴받아 출력
        ArrayList<MemberDTO> memberList;
        memberList = dao.select();
        
        // ArrayList 객체가 null 일 경우 "조회 실패!" 출력
        // null 이 아닐 경우 저장된 모든 데이터 출력
//        for(int i = 0; i < memberList.size(); i++) {
//            MemberDTO dto = memberList.get(i);
//            
//            int idx = dto.getIdx();
//            String name = dto.getName();
//            int age = dto.getAge();
//            String email = dto.getEmail();
//            String jumin = dto.getJumin();
//            
//            System.out.println(idx + " " + name + " " + age + " " + email + " " + jumin);
//        }
        
        // 확장 for문을 사용하는 경우
        for(MemberDTO dto : memberList) {
            int idx = dto.getIdx();
            String name = dto.getName();
            int age = dto.getAge();
            String email = dto.getEmail();
            String jumin = dto.getJumin();
            
            System.out.println(idx + " " + name + " " + age + " " + email + " " + jumin);
        }
        
    }
    

}




















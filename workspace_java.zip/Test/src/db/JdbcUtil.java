package db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

// DB 접속 및 자원 반환에 대한 작업 처리
public class JdbcUtil {
    // DB 연결 수행 후 Connection 객체 리턴
    public static Connection connectDb() {
        // 1, 2단계에서 필요한 변수 4가지 선언
        String driver = "com.mysql.jdbc.Driver"; // 드라이버 클래스 위치
        String url = "jdbc:mysql://localhost:3306/java"; // DB 접속 URL
        String user = "root"; // 계정명
        String password = "1234"; // 패스워드
        
        Connection con = null;
        
        try {
            // 1단계. 드라이버 로드
            Class.forName(driver);
            System.out.println("드라이버 로드 성공!");
            
            // 2단계. DB 연결
            con = DriverManager.getConnection(url, user, password);
            System.out.println("DB 연결 성공!");
            
            return con;
        } catch (ClassNotFoundException e) {
            System.out.println("드라이버 로드 실패! - " + e.getMessage());
        } catch (SQLException e) {
            System.out.println("DB 연결 실패! - " + e.getMessage());
        }
        
        return null;
    }
    
    // 자원 반환 => Connection, PreparedStatement, ResultSet 객체를 구분하기 위해 오버로딩
    public static void close(Connection con) {
        try {
            con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public static void close(PreparedStatement pstmt) {
        try {
            pstmt.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public static void close(ResultSet rs) {
        try {
            rs.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
